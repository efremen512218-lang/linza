(()=>{var bt=o=>typeof o=="string"?o:"",Tt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:bt("https://efremen512218-lang.github.io/linza/"),telegram:bt("https://t.me/linza_odds")},qe=bt("https://185-72-145-3.sslip.io"),re={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var ae=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Lt(o){let r=String(o||"").toLowerCase();return ae.find(a=>a.hosts.some(t=>r===t||r.endsWith(`.${t}`)))||null}var xt={overlay:"picks",theme:"auto",mode:"own",model:re.model},Nt={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function G(o){let r=String(o??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let a=parseFloat(r.replace(",","."));return a>=1.001&&a<=1e3?a:null}var At=o=>o.reduce((r,a)=>r+1/a,0);function yt(o){let r=(o||[]).filter(t=>Number.isFinite(t)&&t>1);if(r.length<2||r.length!==(o||[]).length)return{kind:"partial",margin:null,fair:null};let a=At(r);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:r.map(t=>1/t/a)};if(r.length===3&&a>=1.97&&a<=2.4){let t=a/2;return{kind:"double",margin:t-1,fair:r.map(f=>Math.min(.995,1/f/t))}}return{kind:"partial",margin:null,fair:null}}function Ct(o){let r=(o||[]).map(u=>u||[]).filter(u=>u.length),a=r.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let t=u=>u.length>=2&&u.every(Boolean)&&yt(u.map(g=>g.odd)).kind!=="partial",f=u=>{let g=u.filter(L=>L.some(Boolean));if(!g.length)return null;let b=g.filter(t);if(b.length/g.length<.6)return null;let v=new Set(b.flat());return{sets:b,rest:a.filter(L=>!v.has(L))}},m=u=>{let g=[];for(let b=0;b<r.length;b+=u)g.push(r.slice(b,b+u).flat());return g},i=()=>{let u=[];for(let g=0;g+1<r.length;g+=2){let b=Math.max(r[g].length,r[g+1].length);for(let v=0;v<b;v+=1)u.push([r[g][v]??null,r[g+1][v]??null])}return u},c=[()=>m(1)];r.length>=2&&r.length%2===0&&c.push(i,()=>m(2)),r.length>=3&&r.length%3===0&&c.push(()=>m(3)),r.length>1&&c.push(()=>[r.flat()]);for(let u of c){let g=f(u());if(g)return g}return{sets:[],rest:a}}function Et(o,r=1.13){let a=c=>{let u=At(c.map(g=>g.odd));return u>=.995&&u<=r?!0:c.length===3&&u>=1.99&&u<=r*2},t=c=>Math.abs(c*4-Math.round(c*4))<1e-9,f=[],m=[],i=0;for(;i<o.length;){let c=o.slice(i,i+3),u=o.slice(i,i+2);c.length===3&&a(c)?(f.push(c),i+=3):u.length===2&&a(u)?(f.push(u),i+=2):o[i+2]&&t(o[i+1].odd)&&a([o[i],o[i+2]])?(f.push([o[i],o[i+2]]),m.push(o[i+1]),i+=3):(m.push(o[i]),i+=1)}return{sets:f,rest:m}}function Ot(o){let r=(o||[]).filter(f=>f&&f.odd>1&&f.fair>0&&f.fair<1);if(!r.length)return null;let a=r.reduce((f,m)=>f*m.odd,1),t=r.reduce((f,m)=>f*m.fair,1);return{legs:r.length,odd:a,chance:t,fairOdd:1/t,margin:1-a*t}}function qt(o,r){return o*r-1}function Z(o){return Number.isFinite(o)?o>=100?o.toFixed(0):o>=10?o.toFixed(1):o.toFixed(2):"—"}function tt(o,r=0){if(!Number.isFinite(o))return"—";let a=o*100;return a>0&&a<1&&r===0?"<1%":`${a.toFixed(r)}%`}function vt(o){return String(o??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zа-я0-9]/g,"")}var se=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Bt(o){return String(o??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!se.has(r))}function it(o,r){let a=vt(o),t=vt(r);if(a.length<2||t.length<2)return 0;if(a===t)return 1;let f=a.length<=t.length?a:t,m=f===a?t:a;if(f.length>=4&&m.includes(f))return .85;let i=Bt(o),c=Bt(r);if(i.length&&c.length){let b=i.filter(v=>c.some(L=>L===v||v.length>=5&&L.startsWith(v.slice(0,5)))).length/Math.max(i.length,c.length);if(b>=.5)return .6+.3*b}let u=0;for(;u<a.length&&u<t.length&&a[u]===t[u];)u+=1;return u>=5?Math.min(.8,.45+u*.04):0}function ie(o){let r=String(o??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&a.push("reserve"),/люб/.test(r)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&a.push("cyber"),a.join("+")}function et(o,r){let a=m=>{let i=vt(m),c=ie(m);return i.length<2?"":c?`${i}~${c}`:i},t=a(o),f=a(r);return!t||!f?"":[t,f].sort().join("|")}var _=o=>(o?.textContent||"").replace(/[ \s]+/g," ").trim(),wt=o=>o.offsetParent===null&&o.tagName!=="BODY";function le(o){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(o||"").trim())}function kt(o,r){let a=String(o||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фора|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?r===3?"1x2":r===2?"12":"other":"other"}var ce=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function dt(...o){let r=o.filter(Boolean).join(" ");for(let[a,t]of ce)if(a.test(r))return t;return""}function zt(o){if(!o)return null;let r=G(_(o));if(r)return r;let a=_(o).split(" ");return G(a[a.length-1])}var de=0;function nt({scope:o,title:r,period:a="",line:t="",kind:f,outcomes:m,event:i=null,anchor:c=null,eventKey:u=""}){let g=m.length;return{id:`${o}|${u}|${r}|${a}|${t}|${m.map(b=>b.label).join("/")}`,serial:de+=1,scope:o,title:r,period:a,line:t,kind:f||kt(r,g),main:le(a),outcomes:m,event:i,anchor:c||m[0]?.el||null}}var E=(o,r)=>[...o.querySelectorAll(r)];function It(o){return(String(o||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function _t(o){return o.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":o.querySelector(".card")?"list":"other"}var Ft={win:"В",loose:"П",lose:"П",draw:"Н"};function Pt(o){return E(o,".competitor-form__value").map(r=>Ft[[...r.classList].find(a=>Ft[a])]||_(r).slice(0,1)).filter(Boolean).join("")}function pe(o){let r=o.querySelector(".marketbook-header--live");if(r){let t=E(r,".game-scoring__item").map(i=>_(i)),f=E(r,".game-periods .period").map(i=>{let c=E(i,"span");return{label:_(i.querySelector("i")),home:_(c[0]),away:_(c[1])}}).filter(i=>i.home!==""&&i.away!==""),m=E(r,".game-specials > div").map(i=>{let c=E(i,"span"),u=i.querySelector("i"),g=u?.classList.contains("yellow-card")?"жёлтые":u?.classList.contains("red-card")?"красные":u?.classList.contains("penalty-card")?"угловые":"";return g?{kind:g,home:_(c[0]),away:_(c[1])}:null}).filter(Boolean);return{state:_(r.querySelector(".game-timing-state")),score:t.length===2?t:[],periods:f,extras:m}}let a=o.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let t=_(a.querySelector(".match-card__main-score")).replace(/\s/g,""),f=E(a,".match-card__score").map(i=>_(i)).filter(i=>/^\d{1,2}$/.test(i)),m=E(o,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(i=>_(i)).filter(i=>/\d\s*:\s*\d/.test(i)).slice(0,5);return{state:_(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(t)?t.split(":"):[],rounds:f.length>=2?f.slice(0,2):[],periods:m.map((i,c)=>({label:`${c+1} карта`,raw:i})),extras:[]}}return null}function Rt(o,r){if(_t(o)!=="match")return null;let a=E(o,".breadcrumbs .breadcrumbs__item").map(g=>_(g)).filter(Boolean),t=_(o.querySelector(".event-breadcrumbs")),f=E(o,".marketbook-header--prematch .competitor-name").map(g=>_(g));if(f.length<2&&(f=E(o,".marketbook-header--live .competitors-desc__name").map(g=>_(g))),f.length<2&&(f=E(o,".match-card .match-card__team-name").map(g=>_(g))),f.length<2||!f[0]||!f[1])return null;let m=dt(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],t),i=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||t.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[_(o.querySelector(".prematch-date")),_(o.querySelector(".prematch-time"))].filter(Boolean).join(" ")||_(o.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),u=pe(o);return{book:"Winline",id:It(r?.pathname),key:et(f[0],f[1]),home:f[0],away:f[1],sport:m,league:i,start:u?"":c,live:u,form:{home:Pt(o.querySelector(".competitor-form--left")||o.createElement("div")),away:Pt(o.querySelector(".competitor-form--right")||o.createElement("div"))},stats:be(xe(o),f[0],f[1]),url:r?.href||""}}function ue(o,r){let a=[];for(let t of E(o,".bet-line")){if(wt(t))continue;let f=_(t.querySelector(".bet-line__market-name")),m=_(t.querySelector(".bet-line__period")),i=E(t,".odd-btn"),c=i.map((g,b)=>{let v=_(g.querySelector(".odd-btn__label")),L=E(g,"span").map(A=>G(_(A))).find(Boolean)||null;return L?{el:g,odd:L,label:v||Mt(i.length,b,f),locked:!1}:null});if(c.length<2||c.some(g=>!g))continue;let u=_(t.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(nt({scope:"top",title:f,period:m,line:u,outcomes:c,anchor:t,eventKey:r}))}return a}function Mt(o,r,a){return/тотал/i.test(a)?["Меньше","Больше"][r]||"":o===3?["П1","Х","П2"][r]:o===2?["1","2"][r]:String(r+1)}function fe(o,r){let a=[];for(let t of E(o,".market")){let f=E(t,".market__row");if(!f.length)continue;let m=_(t.querySelector(".market-title")),i=f.map(u=>{let g=_(u.querySelector(".market__row-text"));return E(u,".market-row-btn").map(b=>{let v=G(_(b.querySelector(".market-row-btn__coef")));if(!v||b.hasAttribute("disabled"))return null;let L=b.getAttribute("title")||_(b.querySelector(".market-row-btn__text"));return{el:b,odd:v,label:L.replace(/\s+/g," ").trim(),rowLabel:g,locked:!1}})}),{sets:c}=Ct(i);for(let u of c){let g=[...new Set(u.map(A=>A.rowLabel).filter(Boolean))],b=g.length<=1,v=b?"":(u[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],L=u.map(A=>({el:A.el,odd:A.odd,label:b?A.label:A.rowLabel||A.label,locked:!1}));a.push(nt({scope:"board",title:m,period:b&&g[0]||"",line:v,kind:kt(m,L.length),outcomes:L,anchor:t,eventKey:r}))}}return a}var me=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function he(o){let r=E(o,".card__competitors .name .name, .half__names .name").map(t=>_(t));if(r.length<2)return null;let a=o.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:It(a),key:et(r[0],r[1]),home:r[0],away:r[1],href:a,live:/card--live/.test(o.className)||!!o.querySelector(".card__body-live"),time:_(o.querySelector(".header-left__time, .footer__time")),league:_(o.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:o}}function jt(o){let r=[];for(let a of E(o,".card")){if(wt(a))continue;let t=he(a);if(t){for(let f of E(a,".card__body")){let m=_(f.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(f.className)?"отрезок":"");for(let i of E(f,".card__market")){let c=E(i,".coefficient-button");if(c.length<2)continue;let u=(me.find(([b])=>b.test(c[0].className))||[])[1]||"other",g=c.map((b,v)=>{let L=/--is-blank/.test(b.className)?null:zt(b);return L?{el:b,odd:L,label:u==="total"?["Меньше","Больше"][v]:Mt(c.length,v,""),locked:/coefficient-button_locked/.test(b.className)}:null});g.some(b=>!b)||r.push(nt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[u]||"Рынок",period:/^матч$/i.test(m)?"":m,line:_(i.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:u,outcomes:g,event:t,anchor:a,eventKey:t.key}))}}for(let f of E(a,".half__coef-buttons")){let m=E(f,".coef-buttons__button"),i=m.map((c,u)=>{let g=zt(c.querySelector(".button__coef-title")||c);return g?{el:c,odd:g,label:Mt(m.length,u,""),locked:!1}:null});i.length<2||i.some(c=>!c)||r.push(nt({scope:"list",title:i.length===3?"Исход":"Победитель",kind:i.length===3?"1x2":"12",outcomes:i,event:t,anchor:a,eventKey:t.key}))}}}return r}function ge(o){if(!o?.body)return null;let r=u=>/^\d{1,3}\s?%$/.test(u),a=E(o,"h4").map(u=>{let g=[...u.nextElementSibling?.children||[]],b=_(g[0]),v=_(g[g.length-1]);return r(b)&&r(v)?{label:_(u),home:b.replace(/\s/g,""),away:v.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let t=(o.body.innerText||o.body.textContent||"").replace(/\s+/g," "),f=[...t.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(u=>Number(u[1])),i=[...(t.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(u=>u[1].replace(/\s/g,""));return{names:_(o.querySelector("h3")).split(/\s+vs\s+/i).map(u=>u.trim()).filter(Boolean),rows:a,samples:f.slice(0,2),form:i.length>=2?{home:i[0],away:i[1]}:null}}function be(o,r,a){if(!o||o.names.length<2)return o;let t=it(o.names[0],r)+it(o.names[1],a);return it(o.names[0],a)+it(o.names[1],r)<=t?o:{names:[o.names[1],o.names[0]],rows:o.rows.map(m=>({label:m.label,home:m.away,away:m.home})),samples:o.samples.slice().reverse(),form:o.form?{home:o.form.away,away:o.form.home}:null}}function xe(o){let r=o.querySelector("iframe.stats__iframe");if(!r)return null;try{return ge(r.contentDocument)}catch{return null}}function ye(o){let r=["one","two"].map(m=>o.querySelector(`.event-live-center__team-widget--${m}`));if(!r[0]||!r[1])return null;let a=m=>{let i=m;try{i=m.querySelector("iframe")?.contentDocument?.body||m}catch{i=m}let c=E(i,'[class*="player"]').filter(g=>!E(g,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(g.className)),u=[];for(let g of c){let b=_(g).split(" ").filter(Boolean),v=b.find(A=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(A)&&/[A-Za-z]/.test(A));if(!v||u.some(A=>A.nick===v))continue;let L=b.filter(A=>/^\d{1,3}$/.test(A)).map(Number);u.push({nick:v,numbers:L.slice(0,4)})}return u.slice(0,5)},t=a(r[0]),f=a(r[1]);return t.length<3||f.length<3?null:{home:t,away:f}}var Dt={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:_t,readMatch:Rt,readEsportsWidget:ye,observeTargets(o){try{let r=o.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(o,r){if(_t(o)==="match"){let f=Rt(o,r)?.key||"";return[...ue(o,f),...fe(o,f),...jt(o)]}return jt(o)}};var pt=(o,r)=>{try{return[...o.querySelectorAll(r)]}catch{return[]}};function Wt(o,r){let a=[o];if(r.shadow)for(let t of pt(o,r.shadow))t.shadowRoot&&a.push(t.shadowRoot);return a}var Zt=o=>(o.defaultView?.innerWidth||0)>0,ve='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function we(o){let r=[],a=o.ownerDocument.createTreeWalker(o,4);for(;a.nextNode();){let t=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(t&&r.push(...t.split(" ")),r.length>5)return null}return r}function ke(o,r){if(o.disabled||o.hasAttribute?.("disabled"))return null;let a=r.value&&o.querySelector(r.value)||o,t=we(a);if(!t||!t.length||t.join(" ").length>28)return null;let f=t[t.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(f))return null;let m=G(f);if(!m||m>500||t.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let i=t.slice(0,-1).join(" ");return/[+−]|^-/.test(i)?null:{odd:m,label:i}}function ze(o,r){let a=[],t=new Set,f=Wt(o,r).flatMap(m=>pt(m,r.outcome||ve));for(let m of f){if(t.has(m)||r.skip&&m.closest(r.skip)||m.closest("#lz-root, #lz-marks"))continue;let i=ke(m,r);if(i){if(!r.outcome&&Zt(o)){let c=m.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}t.add(m),a.push({el:m,odd:i.odd,label:i.label,locked:!1})}}return r.outcome?a:a.filter(m=>!a.some(i=>i.el!==m.el&&i.el.contains(m.el)))}function _e(o,r,a){if(r.row)return o.closest(r.row);let t=o.parentElement;for(let f=0;f<6&&t&&t!==t.ownerDocument.body;f+=1){let m=a(t);if(m>=2&&m<=16){if(!Zt(t.ownerDocument))return t;let i=t.getBoundingClientRect();if(i.height<=130&&i.width>=120)return t}if(m>16)break;t=t.parentElement}return null}var Me=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось)$/i;function Se(o,r){let a=r.length,t=o;for(let b=0;b<4;b+=1){let v=t.parentElement;if(!v||r.some(R=>!v.contains(R.el))||v.querySelectorAll("*").length>400||[...v.querySelectorAll('button, a, td, [role="button"]')].filter(R=>!r.some(C=>C.el===R||C.el.contains(R)||R.contains(C.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(_(R))).length>a)break;t=v}let f=r[0].el,m=[],i=t.ownerDocument.createTreeWalker(t,4);for(;i.nextNode();){let b=i.currentNode;if(f.contains(b))break;let v=b.textContent.replace(/[ \s]+/g," ").trim();v.length<2||v.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(v)||/\d{1,2}:\d{2}|^\d|['′]$/.test(v)||Me.test(v)||m.push(v)}let c=m.slice(-2),u=m.map(b=>b.split(/\s+[—–-]\s+/)).filter(b=>b.length===2).pop();if(u&&(c=u),c.length<2||c[0]===c[1])return null;let g=t.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:et(c[0],c[1]),home:c[0],away:c[1],href:g,live:!1,time:"",league:"",card:t}}function $e(o,r,a){if(!r.names)return Se(o,a);let t=r.event&&o.closest(r.event)||o,f=[...new Set(pt(t,r.names).map(c=>_(c)).filter(Boolean))],m=f;if(f.length===1&&(m=f[0].split(/\s+[—–-]\s+/)),m.length<2||!m[0]||!m[1])return null;let i=t.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:et(m[0],m[1]),home:m[0],away:m[1],href:i,live:!1,time:"",league:"",card:t}}function Te(o){let a=String(o.title||"").match(/^(.{2,40}?)\s+[—–-]\s+(.{2,40}?)(?:\s*[:,|.(]|\s+[—–-]\s|\s+ставки|\s+прогноз|$)/i);return a?[a[1].trim(),a[2].trim()]:null}function Kt(o,r={}){function a(i,c){return r.matchUrl&&r.matchUrl.test(c?.pathname||"")||r.matchPage&&i.querySelector(r.matchPage)?"match":"list"}function t(i,c){if(a(i,c)!=="match")return null;let u=r.matchNames?pt(i,r.matchNames).map(b=>_(b)).filter(Boolean):[];if(u.length===1&&(u=u[0].split(/\s+[—–-]\s+/)),u.length<2&&(u=Te(i)||[]),u.length<2)return null;let g=r.matchLeague?_(i.querySelector(r.matchLeague)):"";return{book:o.name,id:(String(c?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:et(u[0],u[1]),home:u[0],away:u[1],sport:dt(c?.pathname,g,i.title),league:g,start:"",live:null,form:{home:"",away:""},url:c?.href||""}}function f(i,c){let u=ze(i,r);if(u.length<2)return[];let g=new Set(u.map(C=>C.el)),b=C=>{let B=0;for(let W of g)C.contains(W)&&(B+=1);return B},v=new Map;for(let C of u){let B=_e(C.el,r,b);B&&(v.has(B)||v.set(B,[]),v.get(B).push(C))}let L=a(i,c),A=L==="match"?t(i,c):null,R=[];for(let[C,B]of v){let W=L==="match"?null:$e(C,r,B),{sets:V}=Et(B);V.forEach((H,Y)=>{let O=Y===0,$=H.length,N=$===3?["П1","Х","П2"]:["1","2"];R.push(nt({scope:L==="match"?"board":"list",title:O&&$===3?"Исход":O?"Победитель":`Рынок ${Y+1}`,kind:O?$===3?"1x2":"12":"other",outcomes:H.map((S,k)=>({...S,label:S.label||N[k]||String(k+1)})),event:W,anchor:C,eventKey:W?.key||A?.key||`row${R.length}`}))})}return R}let m=i=>Wt(i,r).slice(1);return{id:o.id,name:o.name,hosts:o.hosts,generic:!0,pageType:a,readMatch:t,collect:f,observeTargets:m,readEsportsWidget:()=>null}}var Xt={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]'},Vt={fonbet:Xt,pari:Xt,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd",row:".euv_event_home",names:".euv_event_name_team",integers:!0},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name"}};function Ht(o){let r=Lt(o);return r?r.id==="winline"?{adapter:Dt,book:r}:{adapter:Kt(r,Vt[r.id]||{}),book:r}:null}var ut=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var Yt=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}
`;function n(o,r,...a){let[t,...f]=o.split("."),m=document.createElement(t||"div");f.length&&(m.className=f.join(" "));for(let[i,c]of Object.entries(r||{}))if(!(c==null||c===!1))if(i==="class")m.className=[m.className,c].filter(Boolean).join(" ");else if(i==="style")m.style.cssText=c;else if(i==="text")m.textContent=c;else{if(i==="html")throw new Error("html запрещён");i.startsWith("data-")||i.startsWith("aria-")||i==="role"||i==="title"||i==="type"||i==="href"||i==="target"||i==="rel"||i==="placeholder"||i==="value"||i==="for"||i==="name"||i==="maxlength"||i==="autocomplete"||i==="spellcheck"||i==="tabindex"?m.setAttribute(i,c===!0?"":String(c)):i==="disabled"||i==="hidden"||i==="checked"||i==="selected"?m[i]=!!c:m[i]=c}return Ut(m,a),m}function Ut(o,r){for(let a of r)a==null||a===!1||(Array.isArray(a)?Ut(o,a):o.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var Gt="http://www.w3.org/2000/svg";function I(o,r=16){let a=document.createElementNS(Gt,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",r),a.setAttribute("height",r),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let t of Ae[o]||[]){let f=document.createElementNS(Gt,"path");f.setAttribute("d",t),a.appendChild(f)}return a}var Ae={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function Qt(){let o=document.createElement("div");o.id="lz-marks",o.style.cssText="position:absolute!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=o.attachShadow({mode:"open"});r.appendChild(n("style",{text:ut+Yt}));let a=n("div.layer"),t=n("div.tip");r.append(a,t);let f=new Map,m=new Set,i=0,c=null,u=null,g=new IntersectionObserver($=>{for(let N of $)N.isIntersecting?m.add(N.target):(m.delete(N.target),f.get(N.target)?.node.classList.remove("on"));v()},{rootMargin:"120px"});function b(){o.isConnected||document.documentElement.appendChild(o)}function v(){i||(i=requestAnimationFrame(()=>{i=0,R()}))}let L=($,N)=>{for(let S=N;S;S=S.parentNode||S.host)if(S===$)return!0;return!1};function A($,N){let S=N.left+N.width/2,k=N.top+N.height/2;if(S<0||k<0||S>window.innerWidth||k>window.innerHeight)return!1;let T=document.elementFromPoint(S,k);for(;T?.shadowRoot?.elementFromPoint;){let P=T.shadowRoot.elementFromPoint(S,k);if(!P||P===T)break;T=P}return!!T&&T!==$&&!L($,T)&&!L(T,$)}function R(){let $=window.scrollX,N=window.scrollY;for(let S of m){let k=f.get(S);if(!k)continue;if(!S.isConnected){C(S);continue}let T=S.getBoundingClientRect();if(T.width<6||T.height<6||A(S,T)){k.node.classList.remove("on");continue}let P=Math.round(T.left+$),F=Math.round(T.top+N),D=Math.round(T.width),j=Math.round(T.height);(k.x!==P||k.y!==F)&&(k.node.style.transform=`translate3d(${P}px, ${F}px, 0)`,k.x=P,k.y=F),(k.w!==D||k.h!==j)&&(k.node.style.width=`${D}px`,k.node.style.height=`${j}px`,k.w=D,k.h=j,k.node.classList.toggle("small",j<26)),k.node.classList.add("on")}c&&W()}function C($){let N=f.get($);N&&(g.unobserve($),m.delete($),N.node.remove(),f.delete($))}function B($){b();let N=new Map;for(let S of $)S.el?.isConnected&&N.set(S.el,S);for(let S of[...f.keys()])N.has(S)||C(S);for(let[S,k]of N){let T=f.get(S);if(!T){let F=n("div.mark"),D=parseFloat(getComputedStyle(S).borderTopLeftRadius);F.style.borderRadius=`${Number.isFinite(D)&&D>0?Math.min(D,16):6}px`;let j=n("span.chip");F.appendChild(j),a.appendChild(F),T={node:F,chip:j,sig:""},f.set(S,T),g.observe(S)}let P=`${k.frame?1:0}|${k.selected?1:0}|${k.tone||""}|${k.chip||""}`;P!==T.sig&&(T.sig=P,T.node.classList.toggle("frame",!!k.frame),T.node.classList.toggle("selected",!!k.selected),T.node.classList.toggle("pos",k.tone==="pos"&&!!k.frame),T.chip.hidden=!k.chip,T.chip.textContent=k.chip||"",T.chip.className=`chip${k.tone&&k.tone!=="accent"?" "+k.tone:""}`)}v()}function W(){if(!c?.isConnected)return H();let $=c.getBoundingClientRect(),N=264,S=t.offsetHeight||140,k=$.left+$.width/2-N/2;k=Math.max(8,Math.min(k,window.innerWidth-N-8)),u&&k+N>u.left-8&&k<u.right&&(k=Math.max(8,u.left-N-10));let T=$.bottom+10;T+S>window.innerHeight-8&&(T=$.top-S-10),T<8&&(T=8),t.style.transform=`translate3d(${Math.round(k+window.scrollX)}px, ${Math.round(T+window.scrollY)}px, 0)`}function V($,N){b(),c=$,t.replaceChildren(N),W(),t.classList.add("on")}function H(){c=null,t.classList.remove("on")}function Y($){u=$}function O($){o.setAttribute("data-theme",$)}return window.addEventListener("scroll",v,{capture:!0,passive:!0}),window.addEventListener("resize",v,{passive:!0}),setInterval(()=>{f.size&&!document.hidden&&v()},700),{set:B,schedule:v,showTip:V,hideTip:H,setTheme:O,setAvoid:Y,get tipTarget(){return c},count:()=>f.size}}var Jt=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 88px 44px;
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-faint);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var K=(o,r=0)=>tt(o,r),te=o=>`${o>0?"+":o<0?"−":""}${Math.abs(o).toFixed(1)}`;function ee({bus:o,actions:r,brand:a}){let t=document.createElement("div");t.id=o.rootId,t.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let f=t.attachShadow({mode:"open"});f.appendChild(n("style",{text:ut+Jt}));let m=n("span.dot"),i=n("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},I("lens",18),n("span",{text:a.name}),m),c=n("div.tabs",{role:"tablist"}),u=n("div.body"),g=n("div.foot"),b=n("small"),v=n("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),L=n("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),A=n("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},I("gear")),R=n("div.head",{},n("div.brand",{},n("span.logo",{},I("lens",15)),n("span",{text:a.name}),b),n("span.grow"),L,v,A,n("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},I("close"))),C=n("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},R,c,u,g);f.append(i,C);let B=()=>{t.isConnected||document.documentElement.appendChild(t)};B(),new MutationObserver(B).observe(document.documentElement,{childList:!0});let W="",V=null,H=new Map,Y=e=>{for(let l of e.composedPath()){if(l===t)break;if(l?.dataset?.act)return l}return null},O=null;o.on("ui:pointerdown",e=>{if(e.button!==0)return;let l=e.composedPath(),d=l.includes(i),y=l.includes(R)&&!l.some(M=>M?.dataset?.act);if(!d&&!y)return;let z=d?i:C,w=z.getBoundingClientRect();O={target:z,key:d?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:w.left,oy:w.top,moved:!1},o.setDragging(!0)}),o.on("drag:move",e=>{if(!O)return;let l=e.clientX-O.sx,d=e.clientY-O.sy;!O.moved&&Math.hypot(l,d)<5||(O.moved=!0,O.target.classList.add("dragging"),N(O.target,O.ox+l,O.oy+d))}),o.on("drag:end",()=>{if(O){if(o.setDragging(!1),O.target.classList.remove("dragging"),O.moved){let e=O.target.getBoundingClientRect();r.savePosition(O.key,{left:e.left,top:e.top}),$=!0,setTimeout(()=>{$=!1},60)}O=null}});let $=!1;function N(e,l,d){let y=e.offsetWidth||120,z=e.offsetHeight||40,w=Math.max(6,Math.min(l,window.innerWidth-y-6)),M=Math.max(6,Math.min(d,window.innerHeight-Math.min(z,60)-6));e.style.left=`${Math.round(w)}px`,e.style.top=`${Math.round(M)}px`,e.style.right="auto"}o.on("ui:click",e=>{if($)return;let l=Y(e);if(!l||l.disabled)return;e.preventDefault();let d=l.dataset.act;if(d==="toggle")return s();if(d==="close")return Q();let y=r[d];y&&y(l.dataset.arg,l,f)}),o.on("ui:keydown",e=>{if(e.key==="Escape"&&Q(),e.key==="Enter"){let l=e.composedPath()[0];l?.dataset?.enter&&r[l.dataset.enter]?.(l.value,l,f)}});let S=(e,l)=>n("span.form",{},[...String(e||"")].slice(0,5).map(d=>n(`i${d==="В"?".w":d==="П"?".l":""}`,{text:d,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[d]||""})),l);function k(e){let l=e.live,d=l?n("div.center",{},l.score?.length===2?n("span.score",{text:`${l.score[0]} : ${l.score[1]}`}):null,n("span.badge.live",{text:l.state||"Лайв"})):n("div.center",{},n("span",{text:e.start||"до матча"})),y=l?.periods?.length?n("div.periods",{text:l.periods.map(w=>w.raw?`${w.label} ${w.raw}`:`${/^\d+$/.test(w.label)?`${w.label}-й отрезок`:w.label} ${w.home}:${w.away}`).join(" · ")}):null,z=l?.extras?.length?n("div.periods",{text:l.extras.map(w=>`${w.kind} ${w.home}:${w.away}`).join(" · ")}):null;return n("div.card",{},n("div.league",{text:e.league||e.sportName||"",title:e.league||""}),n("div.teams",{},n("div.team",{},n("b",{text:e.home,title:e.home}),e.form?.home?S(e.form.home):null),d,n("div.team.away",{},n("b",{text:e.away,title:e.away}),e.form?.away?S(e.form.away):null)),y,z)}function T(e){let l=e.rows.some(d=>Number.isFinite(d.model));return n("div.card",{},n("div.kicker",{},n("span",{text:e.title}),Number.isFinite(e.margin)?n("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(e.margin,1)}`}):null),e.rows.map(d=>{let y=l&&Number.isFinite(d.model)?(d.model-d.fair)*100:null;return n("div.prob",{},n("span.name",{text:d.name,title:d.name}),n("span.odd",{text:Z(d.odd)}),n("span.track",{},n("i",{style:`width:${Math.round((d.fair||0)*100)}%`}),Number.isFinite(d.model)?n("u",{style:`left:${Math.round(d.model*100)}%`}):null),n("span.pct",{},K(l&&Number.isFinite(d.model)?d.model:d.fair),y!=null&&Math.abs(y)>=.05?n(`small${y>0?".pos":".neg"}`,{text:`${te(y)} п.п.`}):null))}),n("div.legend",{},n("span",{text:"шанс по линии без маржи"}),l?n("span.model",{text:"оценка модели"}):null))}function P(e){let l=e.analysis;if(l.status==="loading")return n("div.card",{},n("div.kicker",{},n("span",{text:"Разбор"}),n("span.badge.accent",{text:"собираю данные"})),n("div.steps",{},l.steps.map((M,q)=>n(`div.step${q===l.steps.length-1?".now":".done"}`,{},n("span.mark"),n("span",{text:M})))));if(l.status==="error")return n("div.card",{},n("div.note.warn",{},I("alert"),n("span",{text:l.error})),l.needKey?n("div.row",{style:"margin-top:10px"},n("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},I("gear"),"Открыть настройки")):null);if(l.status!=="done"||!l.result)return null;let d=l.result,y={home:e.match?.home,away:e.match?.away,draw:"ничья"}[d.lean],z=d.proposed?.lean&&d.proposed.lean!=="none"&&d.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[d.proposed.lean],by:Math.abs(d.proposed.shift[d.proposed.lean]||0)}:null,w=new Map((d.facts||[]).map(M=>[M.id,M]));return n("div.card",{},n("div.kicker",{},n("span",{text:"Разбор"}),n("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${d.confidence||"низкая"}`})),n("div.verdict",{text:y?`Данные сдвигают оценку в сторону: ${y}`:z?`Данные слегка склоняют в сторону: ${z.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),z?n("div.note",{style:"margin-bottom:10px"},I("info"),n("span",{text:`Модель предложила сдвиг на ${z.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,d.summary?n("p.summary",{text:d.summary}):null,d.factors?.length?n("ul.factors",{},d.factors.map(M=>n(`li.factor${M.side==="home"?".home":M.side==="away"?".away":""}`,{},n("div",{},n("p",{text:M.text}),n("div.src",{},(M.facts||[]).map(q=>w.get(q)).filter(Boolean).map(q=>n("span.tag",{text:`${q.id} · ${q.source}`,title:q.text}))))))):null,d.risks?.length?n("div.note",{style:"margin-top:10px"},I("info"),n("span",{text:`Что может сломать вывод: ${d.risks.join(" ")}`})):null,n("details",{"data-key":"facts",open:H.get("facts")||!1},n("summary",{text:`Данные, на которых стоит разбор (${d.facts?.length||0})`}),n("ul.facts",{},(d.facts||[]).map(M=>n("li",{},n("b",{text:M.id}),n("span",{},M.text," ",n("em",{text:`— ${M.source}`})))))),n("div.hint",{style:"margin-top:8px",text:d.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function F(e){if(e.status==="idle")return null;if(e.status==="loading")return n("div.card",{},n("div.kicker",{},n("span",{text:"Цены других контор"})),n("div.hint",{text:"Смотрю открытые линии…"}));let l=e.labels||[];if(!e.rows?.length)return n("div.card",{},n("div.kicker",{},n("span",{text:"Цены других контор"})),n("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let d=l.map((y,z)=>Math.max(...e.rows.map(w=>w.odds[z]||0)));return n("div.card",{},n("div.kicker",{},n("span",{text:"Цены других контор"}),n("span.badge",{text:"лучшая цена выделена"})),n("table",{},n("tr",{},n("th",{text:"Контора"}),l.map(y=>n("th",{text:y}))),e.rows.map(y=>n("tr",{},n("td.name",{text:y.name}),y.odds.map((z,w)=>n(`td${z&&z===d[w]&&e.rows.length>1?".best":""}`,{text:z?Z(z):"—"}))))),e.note?n("div.hint",{style:"margin-top:8px",text:e.note}):null)}function D(e){let l=[],d=(y,z,w)=>l.push(n("dt",{text:y}),n(`dd${w?"."+w:""}`,{text:z}));return Number.isFinite(e.fair)?(d("Шанс по линии без маржи",K(e.fair,1)),d("Кэф без маржи конторы",Z(e.fairOdd)),d("Маржа конторы в этом рынке",K(e.margin,1))):d("Заложено в кэфе (с маржой)",K(1/e.odd,1)),Number.isFinite(e.model)&&(d("Оценка модели",K(e.model,1)),d("Ожидание на рубль по модели",`${te(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&d(`Лучшая цена: ${e.best.name}`,Z(e.best.odd),e.best.odd>e.odd?"pos":""),n("div.card.accent",{},n("div.kicker",{},n("span",{text:e.market}),n("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},I("close",13))),n("div.pick-head",{},n("span.big",{text:Z(e.odd)}),n("span.what",{text:e.label,title:e.label})),n("dl.kv",{},l),e.note?n("div.hint",{style:"margin-top:8px",text:e.note}):null,n("div.row",{style:"margin-top:10px"},n("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},I("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")))}function j(e){let l=(d,y)=>n("div",{style:"min-width:0"},n("b",{text:d,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),y.map(z=>n("div",{style:"display:flex;justify-content:space-between;gap:8px"},n("span",{text:z.nick}),n("span",{style:"color:var(--lz-muted)",text:z.numbers.slice(0,2).join(" / ")}))));return n("div.card",{},n("div.kicker",{},n("span",{text:"Игроки сейчас"}),n("span.badge",{text:"с табло конторы"})),n("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},l(e.homeName,e.home),l(e.awayName,e.away)))}function at(e,l){return n("div.card",{},n("div.kicker",{},n("span",{text:"Статистика команд"}),n("span.badge",{text:"со страницы конторы"})),n("table",{},n("tr",{},n("th",{text:"Показатель"}),n("th",{text:l.home}),n("th",{text:l.away})),e.rows.map(d=>n("tr",{},n("td",{text:d.label}),n("td",{text:d.home}),n("td",{text:d.away})))),e.samples?.length===2?n("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function st(e){let l=[];if(e.pick&&l.push(D(e.pick)),!e.match)return l.push(n("div.empty",{},n("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),l;l.push(k(e.match)),e.esports&&l.push(j(e.esports)),e.match.stats?.rows?.length&&l.push(at(e.match.stats,e.match)),e.line&&l.push(T(e.line));let d=e.analysis.status==="loading";l.push(n("div.row",{},n("button.btn",{type:"button","data-act":"analyze",disabled:d},I("spark"),d?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),n("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},I("scale"),"Сравнить цены"))),e.quota&&l.push(n("div.hint.center-text",{text:e.quota}));let y=P(e);y&&l.push(y);let z=F(e.compare);return z&&l.push(z),l}function mt(e){let l=e.scan;return l?.rows?.length?[n("div.card",{},n("div.kicker",{},n("span",{text:l.title}),n("span.badge",{text:`средняя маржа ${K(l.average,1)}`})),n("table",{},n("tr",{},n("th",{text:l.first}),n("th",{text:"Фаворит"}),n("th",{text:"Маржа"})),l.rows.map(d=>n("tr.click",{"data-act":"scan-go","data-arg":String(d.index),title:"Показать на странице"},n("td.name",{},d.name,d.sub?n("span.sub",{text:d.sub}):null),n("td",{},d.fav,n("span.sub",{text:K(d.favPct)})),n(`td${d.low?".best":""}`,{text:K(d.margin,1)})))),n("div.hint",{style:"margin-top:8px",text:l.note}))]:[n("div.empty",{},n("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function ht(e){let l=e.express;if(!l.legs.length)return[n("div.empty",{},n("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let d=l.stats;return[n("div.card",{},n("div.kicker",{},n("span",{text:`Экспресс · ${l.legs.length}`}),n("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},I("trash",13),"Очистить")),l.legs.map(y=>n("div.leg",{},n("div.t",{},n("b",{text:y.label,title:y.label}),n("span",{text:y.title,title:y.title})),n("span.o",{text:Z(y.odd)}),n("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":y.id,title:"Убрать",style:"width:24px;height:24px"},I("close",13))))),d?n("div.card.soft",{},n("dl.kv",{},n("dt",{text:"Итоговый коэффициент"}),n("dd",{text:Z(d.odd)}),n("dt",{text:"Шанс, что зайдёт всё (по линии)"}),n("dd",{text:K(d.chance,1)}),n("dt",{text:"Кэф без маржи"}),n("dd",{text:Z(d.fairOdd)}),n("dt",{text:"Маржа конторы на всём экспрессе"}),n("dd.neg",{text:K(d.margin,1)})),n("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function lt(e){let l=e.settings,d=(y,z,w)=>n("div.seg",{},w.map(([M,q])=>n(`button${z===M?".on":""}`,{type:"button","data-act":y,"data-arg":M,text:q})));return[n("div.card",{},n("div.field",{},n("label",{text:"Отметки на странице"}),d("set-overlay",l.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),n("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),n("div.field",{},n("label",{text:"Тема"}),d("set-theme",l.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]]))),n("div.card",{},n("div.kicker",{},n("span",{text:"Разбор матчей"}),n(`span.badge${l.ready?".pos":""}`,{text:l.ready?"подключён":"не подключён"})),l.proxy?n("div.field",{},n("label",{text:"Доступ"}),d("set-mode",l.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,l.mode==="license"&&l.proxy?n("div.field",{},n("label",{for:"lz-license",text:"Лицензионный ключ"}),n("input",{type:"text",id:"lz-license",placeholder:l.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),n("div.row",{},n("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),l.licenseMask?n("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),n("div.hint",{text:[l.licenseMask?`Ключ ${l.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",l.plan,l.usage].filter(Boolean).join(" ")})):n("div.field",{},n("label",{for:"lz-key",text:"API-ключ Clodex"}),n("input",{type:"password",id:"lz-key",placeholder:l.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),n("div.row",{},n("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),l.hasKey?n("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),n("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${l.usage}`}))),n("div.card.soft",{},n("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function gt(e){V=e;let l=JSON.stringify(e);if(l===W)return;W=l;for(let w of u.querySelectorAll("details[data-key]"))H.set(w.dataset.key,w.open);let d=u.scrollTop;b.textContent=e.bookName?`· ${e.bookName}`:"",m.classList.toggle("off",e.settings.overlay==="off"),v.replaceChildren(I(e.theme==="dark"?"sun":"moon")),L.replaceChildren(I(e.settings.overlay==="off"?"eyeOff":"eye")),L.classList.toggle("on",e.settings.overlay!=="off"),A.classList.toggle("on",e.tab==="settings"),A.dataset.arg=e.tab==="settings"?e.backTab:"settings";let y=[["match","Матч"],["scan","Маржа"],["express","Экспресс"]];c.replaceChildren(...y.map(([w,M])=>n(`button.tab${e.tab===w?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":w},M,w==="express"&&e.express.legs.length?n("span.count",{text:String(e.express.legs.length)}):null)));let z=e.tab==="settings"?lt(e):e.tab==="scan"?mt(e):e.tab==="express"?ht(e):st(e);u.replaceChildren(...z.filter(Boolean)),u.scrollTop=d,g.replaceChildren(n("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function ct(e){t.setAttribute("data-theme",e)}function ot(){C.hidden=!1,r.opened?.()}function Q(){C.hidden=!0}function s(){C.hidden?ot():Q()}function p(e){e?.fab&&N(i,e.fab.left,e.fab.top),e?.panel&&N(C,e.panel.left,e.panel.top)}let h=0;function x(e){f.querySelector(".toast")?.remove();let l=n("div.toast",{text:e,role:"status"});f.appendChild(l),clearTimeout(h),h=setTimeout(()=>l.remove(),2600)}return{render:gt,setTheme:ct,open:ot,close:Q,toggle:s,restore:p,toast:x,shadow:f,rect:()=>C.hidden?null:C.getBoundingClientRect(),get isOpen(){return!C.hidden},get view(){return V}}}var ne="Расширение обновилось. Обновите эту вкладку (F5).";function U(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function X(o,r={}){if(!U())return{ok:!1,error:ne,code:"reload"};try{return await chrome.runtime.sendMessage({type:o,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let t=String(a?.message||a);return/context invalidated|message port closed|receiving end does not exist/i.test(t)||!U()?{ok:!1,error:ne,code:"reload"}:{ok:!1,error:t}}}function oe(o){if(U())try{chrome.runtime.onMessage.addListener(r=>{o(r)})}catch{}}async function St(o){if(!U())return{};try{return await chrome.storage.local.get(o)}catch{return{}}}function rt(o){if(U())try{chrome.storage.local.set(o)}catch{}}var ft=globalThis.__lzBus,$t=ft&&window.top===window?Ht(location.hostname):null;$t&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Ee($t.adapter,$t.book));async function Ee(o,r){let a=await St(["lz.settings","lz.positions","lz.express"]),t={settings:{...xt,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Oe(a["lz.express"]),analysis:new Map,compare:new Map,status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},f=new WeakMap,m=new WeakMap,i=Qt(),c=ee({bus:ft,brand:Tt,actions:ht()});c.restore(t.positions);function u(s){let p=s.outcomes.map(e=>e.odd).join("/"),h=f.get(s);if(h?.sig===p)return h.set;let x=yt(s.outcomes.map(e=>e.odd));return f.set(s,{sig:p,set:x}),x}function g(){return t.match?t.analysis.get(t.match.key):null}function b(s){let p=g()?.result;if(!p?.model||s.scope==="list"||!t.match||!Object.values(p.shift||{}).some(d=>Math.abs(d)>=.5))return null;let{home:h,draw:x,away:e}=p.model,l=s.outcomes.length;if(s.kind==="1x2"&&s.main&&l===3)return[h,x,e];if(s.kind==="12"&&s.main&&l===2&&x<.005)return[h,e];if(s.kind==="dc"&&s.main&&l===3)return[h+x,h+e,x+e];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&l===2){let d=s.period===t.match.home?h:s.period===t.match.away?e:null;if(d!=null)return[d,1-d]}return null}function v(){let s=t.markets.filter(p=>p.scope!=="list"&&p.main&&(p.kind==="1x2"||p.kind==="12"));return s.find(p=>p.scope==="top")||s[0]||null}function L(s,p){let h=s.outcomes[p].label;return s.scope==="list"?!s.event||!s.main?h:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][p]||h:s.kind==="12"&&[s.event.home,s.event.away][p]||h:t.match?s.kind==="1x2"?[t.match.home,"Ничья",t.match.away][p]||h:s.kind==="12"&&[t.match.home,t.match.away][p]||h:h}function A(){let s=t.settings.overlay,p=[];for(let x of t.markets){if(x.outcomes.forEach((M,q)=>m.set(M.el,{market:x,index:q})),s==="off")continue;let e=u(x);if(e.kind==="partial")continue;let l=b(x),d=l||e.fair,y=0;for(let M=1;M<e.fair.length;M+=1)e.fair[M]>e.fair[y]&&(y=M);let z="accent";if(l){let M=0;for(let q=1;q<l.length;q+=1)l[q]-e.fair[q]>l[M]-e.fair[M]&&(M=q);l[M]-e.fair[M]>=.015&&(y=M,z="pos")}let w=x.scope!=="list"||x.main&&(x.kind==="1x2"||x.kind==="12");x.outcomes.forEach((M,q)=>{let J=q===y&&w;!J&&s!=="all"||p.push({el:M.el,frame:J,chip:tt(d[q]),tone:J?z:"quiet"})})}let h=R();if(h){let x=p.find(e=>e.el===h.item.el);x?x.selected=!0:p.push({el:h.item.el,frame:!1,selected:!0,chip:null})}i.set(p)}function R(){if(!t.selected)return null;let s=t.markets.find(h=>h.id===t.selected.id),p=s?.outcomes[t.selected.index];return p?.el?.isConnected?{market:s,item:p,index:t.selected.index}:null}function C(){if(t.settings.theme!=="auto")return t.settings.theme;for(let s of[document.body,document.documentElement]){let h=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!h||h[4]==="0")continue;return(.2126*h[1]+.7152*h[2]+.0722*h[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function B(){location.href!==t.url&&(t.url=location.href,t.selected=null,i.hideTip());let s="other",p=[],h=null;try{s=o.pageType(document,location),p=o.collect(document,location),h=o.readMatch(document,location)}catch(e){console.error("[Линза] страница не прочитана",e)}s!==t.pageType&&(t.pageType=s,t.tab!=="settings"&&t.tab!=="express"&&(t.tab=s==="match"?"match":"scan")),t.markets=p,t.match=h;let x=C();x!==t.theme&&(t.theme=x),i.setTheme(t.theme),c.setTheme(t.theme),A(),st(),H(),c.isOpen&&c.render(P())}let W=new Set,V=null;function H(){if(o.observeTargets)for(let s of o.observeTargets(document))W.has(s)||(W.add(s),V=V||new MutationObserver($),V.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let Y=0,O=0;function $(){let s=Date.now();O||(O=s),clearTimeout(Y);let p=s-O>900?0:220;Y=setTimeout(()=>{O=0,!document.hidden&&B()},p)}function N(){let s=v();if(!s)return null;let p=u(s);if(p.kind!=="full")return null;let h=b(s);return{title:"Что заложено в цене",margin:p.margin,rows:s.outcomes.map((x,e)=>({name:L(s,e),odd:x.odd,fair:p.fair[e],model:h?h[e]:null}))}}function S(){let s=R();if(!s)return null;let{market:p,item:h,index:x}=s,e=u(p),l=b(p),d=e.fair?e.fair[x]:null,y=p.event?`${p.event.home} — ${p.event.away}`:t.match?`${t.match.home} — ${t.match.away}`:"",z=t.match?t.compare.get(t.match.key):null,w=null;if(z?.rows?.length&&p.main&&(p.kind==="1x2"||p.kind==="12")&&p.scope!=="list")for(let q of z.rows){let J=q.odds[x];J&&(!w||J>w.odd)&&(w={name:q.name,odd:J})}let M=`${p.id}#${x}`;return{market:[p.title,p.period,p.line].filter(Boolean).join(" · "),label:[L(p,x),y].filter(Boolean).join(" · "),odd:h.odd,fair:d,margin:e.margin,fairOdd:d?1/d:null,model:l?l[x]:null,ev:l?qt(l[x],h.odd):null,best:w,canAdd:Number.isFinite(d)&&!t.express.some(q=>q.id===M),inExpress:t.express.some(q=>q.id===M),note:e.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":l?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function k(){let s=[];if(t.pageType==="match"?t.markets.forEach((e,l)=>{if(e.scope==="list")return;let d=u(e);if(d.kind!=="full")return;let y=0;for(let z=1;z<d.fair.length;z+=1)d.fair[z]>d.fair[y]&&(y=z);s.push({index:l,name:e.title,sub:[e.period,e.line].filter(Boolean).join(" · "),margin:d.margin,fav:e.outcomes[y].label,favPct:d.fair[y]})}):t.markets.forEach((e,l)=>{if(!e.event||!e.main||e.kind!=="1x2"&&e.kind!=="12")return;let d=u(e);if(d.kind!=="full")return;let y=0;for(let w=1;w<d.fair.length;w+=1)d.fair[w]>d.fair[y]&&(y=w);let z=e.kind==="1x2"?[e.event.home,"Ничья",e.event.away][y]:[e.event.home,e.event.away][y];s.push({index:l,name:`${e.event.home} — ${e.event.away}`,sub:e.event.league||e.event.time,margin:d.margin,fav:z,favPct:d.fair[y]})}),!s.length)return null;let p=new Set;for(let e=s.length-1;e>=0;e-=1){let l=`${s[e].name}|${s[e].sub}`;p.has(l)?s.splice(e,1):p.add(l)}let h=s.reduce((e,l)=>e+l.margin,0)/s.length;s.sort((e,l)=>e.margin-l.margin);let x=s.slice(0,16);return x.forEach(e=>{e.low=e.margin<=h*.8}),{title:t.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:t.pageType==="match"?"Рынок":"Матч",average:h,rows:x,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${x.length} из ${s.length}, сначала самые дешёвые.`}}function T(){let s=t.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function P(){let s=t.match?.key,p=s&&t.analysis.get(s)||{status:"idle",steps:[]},h=s&&t.compare.get(s)||{status:"idle"},x=t.match?.live&&o.readEsportsWidget?o.readEsportsWidget(document):null,e=t.status;return{tab:t.tab,backTab:t.backTab,theme:t.theme,bookName:r.name,pageType:t.pageType,match:t.match?{...t.match,sportName:Nt[t.match.sport]||""}:null,esports:x?{...x,homeName:t.match.home,awayName:t.match.away}:null,line:N(),analysis:{status:p.status,steps:p.steps||[],result:p.result||null,error:p.error||"",needKey:!!p.needKey},compare:h,pick:S(),scan:t.tab==="scan"?k():null,express:{legs:t.express,stats:Ot(t.express)},quota:T(),settings:{overlay:t.settings.overlay,theme:t.settings.theme,mode:e.mode,proxy:e.proxy,ready:e.ready,hasKey:e.hasKey,keyMask:e.keyMask,licenseMask:e.licenseMask,plan:e.plan==="free"||!e.plan?"":`Тариф «${e.plan==="max"?"Макс":"Про"}»${e.until?` до ${e.until.split("-").reverse().join(".")}`:""}.`,usage:e.limit?`Сегодня разборов: ${e.used} из ${e.limit}.`:""}}}let F=()=>{c.isOpen&&c.render(P())};function D(s){Object.assign(t.settings,s),rt({"lz.settings":t.settings}),B(),c.render(P())}async function j(){let s=await X("lz:status");s.ok&&(t.status=s.data),F()}function at(){let s=v(),p=s?u(s):null;return{book:r.name,match:t.match,market:s&&p?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((h,x)=>L(s,x)),odds:s.outcomes.map(h=>h.odd)}:null}}function st(){if(!t.match||!U())return;let s=at();if(!s.market)return;let p=`${t.match.key}|${s.market.odds.join("/")}`;p!==st.last&&(st.last=p,X("lz:quote",s))}async function mt(){let s=t.match;if(!s||t.analysis.has(s.key))return;let p=await X("lz:cached",{match:s});!p.ok||!p.data||t.analysis.has(s.key)||(t.analysis.set(s.key,{status:"done",steps:[],result:p.data}),B(),F())}function ht(){return{opened(){j(),B(),mt(),c.render(P())},tab(s){s==="settings"&&(t.backTab=t.tab==="settings"?t.backTab:t.tab),t.tab=s||"match",c.render(P())},theme(){D({theme:t.theme==="dark"?"light":"dark"})},"overlay-toggle"(){D({overlay:t.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){D({overlay:s})},"set-theme"(s){D({theme:s})},async"set-mode"(s){await X("lz:settings",{mode:s}),j()},async"save-key"(s,p,h){let x=h.getElementById("lz-key"),e=(x?.value||"").trim();if(e.length<8)return c.toast("Вставьте ключ целиком");let l=await X("lz:settings",{apiKey:e});c.toast(l.ok?"Ключ сохранён":l.error),x&&(x.value=""),j()},async"clear-key"(){await X("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),j()},async"save-license"(s,p,h){let x=h.getElementById("lz-license"),e=(x?.value||"").trim();if(e.length<6)return c.toast("Вставьте ключ целиком");let l=await X("lz:settings",{licenseKey:e});c.toast(l.ok?"Ключ принят":l.error),x&&(x.value=""),j()},async"clear-license"(){await X("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),j()},savePosition(s,p){t.positions[s]=p,St(["lz.positions"]).then(h=>{let x=h["lz.positions"]||{};x[location.hostname]=t.positions,rt({"lz.positions":x})})},async analyze(){if(!t.match)return;let s=t.match.key,p={status:"loading",steps:[`${t.match.home} — ${t.match.away}`]};t.analysis.set(s,p),F();let h=await X("lz:analyze",{...at(),force:!0});h.ok?t.analysis.set(s,{status:"done",steps:p.steps,result:h.data}):t.analysis.set(s,{status:"error",steps:p.steps,error:h.error,needKey:h.code==="no-access"}),j(),B(),c.render(P())},async compare(){if(!t.match)return;let s=t.match.key;t.compare.set(s,{status:"loading"}),F();let p=await X("lz:compare",at());t.compare.set(s,p.ok?{status:"done",...p.data}:{status:"done",rows:[],labels:[],note:p.error}),F()},"pick-clear"(){t.selected=null,A(),F()},"leg-add"(){let s=S(),p=R();!s?.canAdd||!p||(t.express.push({id:`${p.market.id}#${p.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),rt({"lz.express":t.express}),c.toast("Добавлено в расчёт экспресса"),F())},"leg-remove"(s){t.express=t.express.filter(p=>p.id!==s),rt({"lz.express":t.express}),F()},"leg-clear"(){t.express=[],rt({"lz.express":t.express}),F()},"scan-go"(s){let p=t.markets[Number(s)],h=p?.outcomes[0]?.el;h?.isConnected&&(h.scrollIntoView({behavior:"smooth",block:"center"}),t.selected={id:p.id,index:0},setTimeout(A,400))}}}function lt(s){let p=s.composedPath();for(let h=0;h<Math.min(p.length,6);h+=1){let x=p[h]instanceof Element?m.get(p[h]):null;if(x&&x.market.outcomes[x.index]?.el===p[h])return x}return null}function gt({market:s,index:p}){let h=u(s),x=b(s),e=s.event?`${s.event.home} — ${s.event.away}`:"",l=s.outcomes.map((y,z)=>{let w=h.fair?h.fair[z]:1/y.odd;return n(`div.tip-row${z===p?".hot":""}`,{},n("span",{text:L(s,z)}),n("span.odd",{text:Z(y.odd)}),n("span.pct",{text:tt(w,w<.1?1:0)}),n("span.tip-bar",{},n("i",{style:`width:${Math.round(w*100)}%`})))}),d=h.kind==="partial"?n("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):n("div.tip-foot",{},"Маржа конторы ",n("b",{text:tt(h.margin,1)}),x?n("span",{}," · модель: ",n("b",{text:tt(x[p],1)})):null);return n("div",{},n("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),e?n("div.tip-sub",{text:e}):n("div.tip-sub",{text:"Шанс по линии без маржи"}),l.slice(0,8),d)}let ct=0,ot=null;ft.on("page:pointerover",s=>{if(t.settings.overlay==="off")return;let p=lt(s),h=p?p.market.outcomes[p.index].el:null;if(h!==ot){if(ot=h,clearTimeout(ct),!p)return i.hideTip();ct=setTimeout(()=>{ot!==h||!h.isConnected||(i.setAvoid(c.rect()),i.showTip(h,gt(p)))},280)}}),ft.on("page:click",s=>{let p=lt(s);p&&(t.selected={id:p.market.id,index:p.index},A(),F())}),oe(s=>{if(s.type!=="lz:progress")return;let p=t.analysis.get(s.key);!p||p.status!=="loading"||(p.steps=[...p.steps,s.text].slice(-7),F())});let Q=()=>{B(),new MutationObserver($).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||B()}),setInterval(()=>{!document.hidden&&location.href!==t.url&&B()},600),setInterval(()=>{!document.hidden&&c.isOpen&&$()},4e3),U()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(t.settings={...xt,...s["lz.settings"].newValue||{}},B())}),j()};document.body?Q():document.addEventListener("DOMContentLoaded",Q,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:t,view:P,refresh:B,overlay:i,panel:c}}function Oe(o){let r=Date.now()-432e5;return(Array.isArray(o)?o:[]).filter(a=>a&&a.at>r&&a.odd>1)}})();
