(()=>{var dt=n=>typeof n=="string"?n:"",Lt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:dt("https://efremen512218-lang.github.io/linza/"),telegram:dt("https://t.me/linza_odds"),bot:dt("https://t.me/linza_keys_bot")},qe=dt("https://185-72-145-3.sslip.io"),re={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var ae=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Nt(n){let o=String(n||"").toLowerCase();return ae.find(a=>a.hosts.some(e=>o===e||o.endsWith(`.${e}`)))||null}var yt={overlay:"picks",theme:"auto",mode:"own",model:re.model},Ct={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function G(n){let o=String(n??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(o))return null;let a=parseFloat(o.replace(",","."));return a>=1.001&&a<=1e3?a:null}var At=n=>n.reduce((o,a)=>o+1/a,0);function vt(n){let o=(n||[]).filter(e=>Number.isFinite(e)&&e>1);if(o.length<2||o.length!==(n||[]).length)return{kind:"partial",margin:null,fair:null};let a=At(o);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:o.map(e=>1/e/a)};if(o.length===3&&a>=1.97&&a<=2.4){let e=a/2;return{kind:"double",margin:e-1,fair:o.map(f=>Math.min(.995,1/f/e))}}return{kind:"partial",margin:null,fair:null}}function Et(n){let o=(n||[]).map(u=>u||[]).filter(u=>u.length),a=o.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let e=u=>u.length>=2&&u.every(Boolean)&&vt(u.map(b=>b.odd)).kind!=="partial",f=u=>{let b=u.filter(N=>N.some(Boolean));if(!b.length)return null;let x=b.filter(e);if(x.length/b.length<.6)return null;let k=new Set(x.flat());return{sets:x,rest:a.filter(N=>!k.has(N))}},m=u=>{let b=[];for(let x=0;x<o.length;x+=u)b.push(o.slice(x,x+u).flat());return b},l=()=>{let u=[];for(let b=0;b+1<o.length;b+=2){let x=Math.max(o[b].length,o[b+1].length);for(let k=0;k<x;k+=1)u.push([o[b][k]??null,o[b+1][k]??null])}return u},c=[()=>m(1)];o.length>=2&&o.length%2===0&&c.push(l,()=>m(2)),o.length>=3&&o.length%3===0&&c.push(()=>m(3)),o.length>1&&c.push(()=>[o.flat()]);for(let u of c){let b=f(u());if(b)return b}return{sets:[],rest:a}}function Ot(n,o=1.13){let a=c=>{let u=At(c.map(b=>b.odd));return u>=.995&&u<=o?!0:c.length===3&&u>=1.99&&u<=o*2},e=c=>Math.abs(c*4-Math.round(c*4))<1e-9,f=[],m=[],l=0;for(;l<n.length;){let c=n.slice(l,l+3),u=n.slice(l,l+2);c.length===3&&a(c)?(f.push(c),l+=3):u.length===2&&a(u)?(f.push(u),l+=2):n[l+2]&&e(n[l+1].odd)&&a([n[l],n[l+2]])?(f.push([n[l],n[l+2]]),m.push(n[l+1]),l+=3):(m.push(n[l]),l+=1)}return{sets:f,rest:m}}function qt(n){let o=(n||[]).filter(f=>f&&f.odd>1&&f.fair>0&&f.fair<1);if(!o.length)return null;let a=o.reduce((f,m)=>f*m.odd,1),e=o.reduce((f,m)=>f*m.fair,1);return{legs:o.length,odd:a,chance:e,fairOdd:1/e,margin:1-a*e}}function Bt(n,o){return n*o-1}function W(n){return Number.isFinite(n)?n>=100?n.toFixed(0):n>=10?n.toFixed(1):n.toFixed(2):"—"}function J(n,o=0){if(!Number.isFinite(n))return"—";let a=n*100;return a>0&&a<1&&o===0?"<1%":`${a.toFixed(o)}%`}function wt(n){return String(n??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zа-я0-9]/g,"")}var se=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Ft(n){return String(n??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").split(/[^a-zа-я0-9]+/).filter(o=>o.length>=2&&!se.has(o))}function it(n,o){let a=wt(n),e=wt(o);if(a.length<2||e.length<2)return 0;if(a===e)return 1;let f=a.length<=e.length?a:e,m=f===a?e:a;if(f.length>=4&&m.includes(f))return .85;let l=Ft(n),c=Ft(o);if(l.length&&c.length){let x=l.filter(k=>c.some(N=>N===k||k.length>=5&&N.startsWith(k.slice(0,5)))).length/Math.max(l.length,c.length);if(x>=.5)return .6+.3*x}let u=0;for(;u<a.length&&u<e.length&&a[u]===e[u];)u+=1;return u>=5?Math.min(.8,.45+u*.04):0}function ie(n){let o=String(n??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(o)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(o)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(o)&&a.push("reserve"),/люб/.test(o)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(o)&&a.push("cyber"),a.join("+")}function tt(n,o){let a=m=>{let l=wt(m),c=ie(m);return l.length<2?"":c?`${l}~${c}`:l},e=a(n),f=a(o);return!e||!f?"":[e,f].sort().join("|")}var M=n=>(n?.textContent||"").replace(/[ \s]+/g," ").trim(),kt=n=>n.offsetParent===null&&n.tagName!=="BODY";function le(n){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(n||"").trim())}function zt(n,o){let a=String(n||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фора|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?o===3?"1x2":o===2?"12":"other":"other"}var ce=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function pt(...n){let o=n.filter(Boolean).join(" ");for(let[a,e]of ce)if(a.test(o))return e;return""}function _t(n){if(!n)return null;let o=G(M(n));if(o)return o;let a=M(n).split(" ");return G(a[a.length-1])}var de=0;function et({scope:n,title:o,period:a="",line:e="",kind:f,outcomes:m,event:l=null,anchor:c=null,eventKey:u=""}){let b=m.length;return{id:`${n}|${u}|${o}|${a}|${e}|${m.map(x=>x.label).join("/")}`,serial:de+=1,scope:n,title:o,period:a,line:e,kind:f||zt(o,b),main:le(a),outcomes:m,event:l,anchor:c||m[0]?.el||null}}var O=(n,o)=>[...n.querySelectorAll(o)];function It(n){return(String(n||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function Mt(n){return n.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":n.querySelector(".card")?"list":"other"}var Pt={win:"В",loose:"П",lose:"П",draw:"Н"};function Rt(n){return O(n,".competitor-form__value").map(o=>Pt[[...o.classList].find(a=>Pt[a])]||M(o).slice(0,1)).filter(Boolean).join("")}function pe(n){let o=n.querySelector(".marketbook-header--live");if(o){let e=O(o,".game-scoring__item").map(l=>M(l)),f=O(o,".game-periods .period").map(l=>{let c=O(l,"span");return{label:M(l.querySelector("i")),home:M(c[0]),away:M(c[1])}}).filter(l=>l.home!==""&&l.away!==""),m=O(o,".game-specials > div").map(l=>{let c=O(l,"span"),u=l.querySelector("i"),b=u?.classList.contains("yellow-card")?"жёлтые":u?.classList.contains("red-card")?"красные":u?.classList.contains("penalty-card")?"угловые":"";return b?{kind:b,home:M(c[0]),away:M(c[1])}:null}).filter(Boolean);return{state:M(o.querySelector(".game-timing-state")),score:e.length===2?e:[],periods:f,extras:m}}let a=n.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let e=M(a.querySelector(".match-card__main-score")).replace(/\s/g,""),f=O(a,".match-card__score").map(l=>M(l)).filter(l=>/^\d{1,2}$/.test(l)),m=O(n,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(l=>M(l)).filter(l=>/\d\s*:\s*\d/.test(l)).slice(0,5);return{state:M(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(e)?e.split(":"):[],rounds:f.length>=2?f.slice(0,2):[],periods:m.map((l,c)=>({label:`${c+1} карта`,raw:l})),extras:[]}}return null}function jt(n,o){if(Mt(n)!=="match")return null;let a=O(n,".breadcrumbs .breadcrumbs__item").map(b=>M(b)).filter(Boolean),e=M(n.querySelector(".event-breadcrumbs")),f=O(n,".marketbook-header--prematch .competitor-name").map(b=>M(b));if(f.length<2&&(f=O(n,".marketbook-header--live .competitors-desc__name").map(b=>M(b))),f.length<2&&(f=O(n,".match-card .match-card__team-name").map(b=>M(b))),f.length<2||!f[0]||!f[1])return null;let m=pt(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],e),l=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||e.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[M(n.querySelector(".prematch-date")),M(n.querySelector(".prematch-time"))].filter(Boolean).join(" ")||M(n.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),u=pe(n);return{book:"Winline",id:It(o?.pathname),key:tt(f[0],f[1]),home:f[0],away:f[1],sport:m,league:l,start:u?"":c,live:u,form:{home:Rt(n.querySelector(".competitor-form--left")||n.createElement("div")),away:Rt(n.querySelector(".competitor-form--right")||n.createElement("div"))},stats:be(xe(n),f[0],f[1]),url:o?.href||""}}function ue(n,o){let a=[];for(let e of O(n,".bet-line")){if(kt(e))continue;let f=M(e.querySelector(".bet-line__market-name")),m=M(e.querySelector(".bet-line__period")),l=O(e,".odd-btn"),c=l.map((b,x)=>{let k=M(b.querySelector(".odd-btn__label")),N=O(b,"span").map(A=>G(M(A))).find(Boolean)||null;return N?{el:b,odd:N,label:k||$t(l.length,x,f),locked:!1}:null});if(c.length<2||c.some(b=>!b))continue;let u=M(e.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(et({scope:"top",title:f,period:m,line:u,outcomes:c,anchor:e,eventKey:o}))}return a}function $t(n,o,a){return/тотал/i.test(a)?["Меньше","Больше"][o]||"":n===3?["П1","Х","П2"][o]:n===2?["1","2"][o]:String(o+1)}function fe(n,o){let a=[];for(let e of O(n,".market")){let f=O(e,".market__row");if(!f.length)continue;let m=M(e.querySelector(".market-title")),l=f.map(u=>{let b=M(u.querySelector(".market__row-text"));return O(u,".market-row-btn").map(x=>{let k=G(M(x.querySelector(".market-row-btn__coef")));if(!k||x.hasAttribute("disabled"))return null;let N=x.getAttribute("title")||M(x.querySelector(".market-row-btn__text"));return{el:x,odd:k,label:N.replace(/\s+/g," ").trim(),rowLabel:b,locked:!1}})}),{sets:c}=Et(l);for(let u of c){let b=[...new Set(u.map(A=>A.rowLabel).filter(Boolean))],x=b.length<=1,k=x?"":(u[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],N=u.map(A=>({el:A.el,odd:A.odd,label:x?A.label:A.rowLabel||A.label,locked:!1}));a.push(et({scope:"board",title:m,period:x&&b[0]||"",line:k,kind:zt(m,N.length),outcomes:N,anchor:e,eventKey:o}))}}return a}var me=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function he(n){let o=O(n,".card__competitors .name .name, .half__names .name").map(e=>M(e));if(o.length<2)return null;let a=n.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:It(a),key:tt(o[0],o[1]),home:o[0],away:o[1],href:a,live:/card--live/.test(n.className)||!!n.querySelector(".card__body-live"),time:M(n.querySelector(".header-left__time, .footer__time")),league:M(n.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:n}}function Dt(n){let o=[];for(let a of O(n,".card")){if(kt(a))continue;let e=he(a);if(e){for(let f of O(a,".card__body")){let m=M(f.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(f.className)?"отрезок":"");for(let l of O(f,".card__market")){let c=O(l,".coefficient-button");if(c.length<2)continue;let u=(me.find(([x])=>x.test(c[0].className))||[])[1]||"other",b=c.map((x,k)=>{let N=/--is-blank/.test(x.className)?null:_t(x);return N?{el:x,odd:N,label:u==="total"?["Меньше","Больше"][k]:$t(c.length,k,""),locked:/coefficient-button_locked/.test(x.className)}:null});b.some(x=>!x)||o.push(et({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[u]||"Рынок",period:/^матч$/i.test(m)?"":m,line:M(l.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:u,outcomes:b,event:e,anchor:a,eventKey:e.key}))}}for(let f of O(a,".half__coef-buttons")){let m=O(f,".coef-buttons__button"),l=m.map((c,u)=>{let b=_t(c.querySelector(".button__coef-title")||c);return b?{el:c,odd:b,label:$t(m.length,u,""),locked:!1}:null});l.length<2||l.some(c=>!c)||o.push(et({scope:"list",title:l.length===3?"Исход":"Победитель",kind:l.length===3?"1x2":"12",outcomes:l,event:e,anchor:a,eventKey:e.key}))}}}return o}function ge(n){if(!n?.body)return null;let o=u=>/^\d{1,3}\s?%$/.test(u),a=O(n,"h4").map(u=>{let b=[...u.nextElementSibling?.children||[]],x=M(b[0]),k=M(b[b.length-1]);return o(x)&&o(k)?{label:M(u),home:x.replace(/\s/g,""),away:k.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let e=(n.body.innerText||n.body.textContent||"").replace(/\s+/g," "),f=[...e.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(u=>Number(u[1])),l=[...(e.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(u=>u[1].replace(/\s/g,""));return{names:M(n.querySelector("h3")).split(/\s+vs\s+/i).map(u=>u.trim()).filter(Boolean),rows:a,samples:f.slice(0,2),form:l.length>=2?{home:l[0],away:l[1]}:null}}function be(n,o,a){if(!n||n.names.length<2)return n;let e=it(n.names[0],o)+it(n.names[1],a);return it(n.names[0],a)+it(n.names[1],o)<=e?n:{names:[n.names[1],n.names[0]],rows:n.rows.map(m=>({label:m.label,home:m.away,away:m.home})),samples:n.samples.slice().reverse(),form:n.form?{home:n.form.away,away:n.form.home}:null}}function xe(n){let o=n.querySelector("iframe.stats__iframe");if(!o)return null;try{return ge(o.contentDocument)}catch{return null}}function ye(n){let o=["one","two"].map(m=>n.querySelector(`.event-live-center__team-widget--${m}`));if(!o[0]||!o[1])return null;let a=m=>{let l=m;try{l=m.querySelector("iframe")?.contentDocument?.body||m}catch{l=m}let c=O(l,'[class*="player"]').filter(b=>!O(b,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(b.className)),u=[];for(let b of c){let x=M(b).split(" ").filter(Boolean),k=x.find(A=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(A)&&/[A-Za-z]/.test(A));if(!k||u.some(A=>A.nick===k))continue;let N=x.filter(A=>/^\d{1,3}$/.test(A)).map(Number);u.push({nick:k,numbers:N.slice(0,4)})}return u.slice(0,5)},e=a(o[0]),f=a(o[1]);return e.length<3||f.length<3?null:{home:e,away:f}}var Zt={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:Mt,readMatch:jt,readEsportsWidget:ye,observeTargets(n){try{let o=n.querySelector("iframe.stats__iframe")?.contentDocument?.body;return o?[o]:[]}catch{return[]}},collect(n,o){if(Mt(n)==="match"){let f=jt(n,o)?.key||"";return[...ue(n,f),...fe(n,f),...Dt(n)]}return Dt(n)}};var ut=(n,o)=>{try{return[...n.querySelectorAll(o)]}catch{return[]}};function Wt(n,o){let a=[n];if(o.shadow)for(let e of ut(n,o.shadow))e.shadowRoot&&a.push(e.shadowRoot);return a}var Kt=n=>(n.defaultView?.innerWidth||0)>0,ve='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function we(n){let o=[],a=n.ownerDocument.createTreeWalker(n,4);for(;a.nextNode();){let e=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(e&&o.push(...e.split(" ")),o.length>5)return null}return o}function ke(n,o){if(n.disabled||n.hasAttribute?.("disabled"))return null;let a=o.value&&n.querySelector(o.value)||n,e=we(a);if(!e||!e.length||e.join(" ").length>28)return null;let f=e[e.length-1];if(!(o.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(f))return null;let m=G(f);if(!m||m>500||e.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let l=e.slice(0,-1).join(" ");return/[+−]|^-/.test(l)?null:{odd:m,label:l}}function ze(n,o){let a=[],e=new Set,f=Wt(n,o).flatMap(m=>ut(m,o.outcome||ve));for(let m of f){if(e.has(m)||o.skip&&m.closest(o.skip)||m.closest("#lz-root, #lz-marks"))continue;let l=ke(m,o);if(l){if(!o.outcome&&Kt(n)){let c=m.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}e.add(m),a.push({el:m,odd:l.odd,label:l.label,locked:!1})}}return o.outcome?a:a.filter(m=>!a.some(l=>l.el!==m.el&&l.el.contains(m.el)))}function _e(n,o,a){if(o.row)return n.closest(o.row);let e=n.parentElement;for(let f=0;f<6&&e&&e!==e.ownerDocument.body;f+=1){let m=a(e);if(m>=2&&m<=16){if(!Kt(e.ownerDocument))return e;let l=e.getBoundingClientRect();if(l.height<=130&&l.width>=120)return e}if(m>16)break;e=e.parentElement}return null}var Me=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось)$/i;function $e(n,o){let a=o.length,e=n;for(let x=0;x<4;x+=1){let k=e.parentElement;if(!k||o.some(j=>!k.contains(j.el))||k.querySelectorAll("*").length>400||[...k.querySelectorAll('button, a, td, [role="button"]')].filter(j=>!o.some(E=>E.el===j||E.el.contains(j)||j.contains(E.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(M(j))).length>a)break;e=k}let f=o[0].el,m=[],l=e.ownerDocument.createTreeWalker(e,4);for(;l.nextNode();){let x=l.currentNode;if(f.contains(x))break;let k=x.textContent.replace(/[ \s]+/g," ").trim();k.length<2||k.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(k)||/\d{1,2}:\d{2}|^\d|['′]$/.test(k)||Me.test(k)||m.push(k)}let c=m.slice(-2),u=m.map(x=>x.split(/\s+[—–-]\s+/)).filter(x=>x.length===2).pop();if(u&&(c=u),c.length<2||c[0]===c[1])return null;let b=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:tt(c[0],c[1]),home:c[0],away:c[1],href:b,live:!1,time:"",league:"",card:e}}function Se(n,o,a){if(!o.names)return $e(n,a);let e=o.event&&n.closest(o.event)||n,f=[...new Set(ut(e,o.names).map(c=>M(c)).filter(Boolean))],m=f;if(f.length===1&&(m=f[0].split(/\s+[—–-]\s+/)),m.length<2||!m[0]||!m[1])return null;let l=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:tt(m[0],m[1]),home:m[0],away:m[1],href:l,live:!1,time:"",league:"",card:e}}function Te(n){let a=String(n.title||"").match(/^(.{2,40}?)\s+[—–-]\s+(.{2,40}?)(?:\s*[:,|.(]|\s+[—–-]\s|\s+ставки|\s+прогноз|$)/i);return a?[a[1].trim(),a[2].trim()]:null}function Xt(n,o={}){function a(l,c){return o.matchUrl&&o.matchUrl.test(c?.pathname||"")||o.matchPage&&l.querySelector(o.matchPage)?"match":"list"}function e(l,c){if(a(l,c)!=="match")return null;let u=o.matchNames?ut(l,o.matchNames).map(x=>M(x)).filter(Boolean):[];if(u.length===1&&(u=u[0].split(/\s+[—–-]\s+/)),u.length<2&&(u=Te(l)||[]),u.length<2)return null;let b=o.matchLeague?M(l.querySelector(o.matchLeague)):"";return{book:n.name,id:(String(c?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:tt(u[0],u[1]),home:u[0],away:u[1],sport:pt(c?.pathname,b,l.title),league:b,start:"",live:null,form:{home:"",away:""},url:c?.href||""}}function f(l,c){let u=ze(l,o);if(u.length<2)return[];let b=new Set(u.map(E=>E.el)),x=E=>{let B=0;for(let K of b)E.contains(K)&&(B+=1);return B},k=new Map;for(let E of u){let B=_e(E.el,o,x);B&&(k.has(B)||k.set(B,[]),k.get(B).push(E))}let N=a(l,c),A=N==="match"?e(l,c):null,j=[];for(let[E,B]of k){let K=N==="match"?null:Se(E,o,B),{sets:H}=Ot(B);H.forEach((U,Y)=>{let q=Y===0,T=U.length,C=T===3?["П1","Х","П2"]:["1","2"];j.push(et({scope:N==="match"?"board":"list",title:q&&T===3?"Исход":q?"Победитель":`Рынок ${Y+1}`,kind:q?T===3?"1x2":"12":"other",outcomes:U.map((S,z)=>({...S,label:S.label||C[z]||String(z+1)})),event:K,anchor:E,eventKey:K?.key||A?.key||`row${j.length}`}))})}return j}let m=l=>Wt(l,o).slice(1);return{id:n.id,name:n.name,hosts:n.hosts,generic:!0,pageType:a,readMatch:e,collect:f,observeTargets:m,readEsportsWidget:()=>null}}var Vt={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]'},Ht={fonbet:Vt,pari:Vt,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd",row:".euv_event_home",names:".euv_event_name_team",integers:!0},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name"}};function Ut(n){let o=Nt(n);return o?o.id==="winline"?{adapter:Zt,book:o}:{adapter:Xt(o,Ht[o.id]||{}),book:o}:null}var ft=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var Yt=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}
`;function t(n,o,...a){let[e,...f]=n.split("."),m=document.createElement(e||"div");f.length&&(m.className=f.join(" "));for(let[l,c]of Object.entries(o||{}))if(!(c==null||c===!1))if(l==="class")m.className=[m.className,c].filter(Boolean).join(" ");else if(l==="style")m.style.cssText=c;else if(l==="text")m.textContent=c;else{if(l==="html")throw new Error("html запрещён");l.startsWith("data-")||l.startsWith("aria-")||l==="role"||l==="title"||l==="type"||l==="href"||l==="target"||l==="rel"||l==="placeholder"||l==="value"||l==="for"||l==="name"||l==="maxlength"||l==="autocomplete"||l==="spellcheck"||l==="tabindex"?m.setAttribute(l,c===!0?"":String(c)):l==="disabled"||l==="hidden"||l==="checked"||l==="selected"?m[l]=!!c:m[l]=c}return Qt(m,a),m}function Qt(n,o){for(let a of o)a==null||a===!1||(Array.isArray(a)?Qt(n,a):n.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var Gt="http://www.w3.org/2000/svg";function I(n,o=16){let a=document.createElementNS(Gt,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",o),a.setAttribute("height",o),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let e of Ce[n]||[]){let f=document.createElementNS(Gt,"path");f.setAttribute("d",e),a.appendChild(f)}return a}var Ce={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function Jt(){let n=document.createElement("div");n.id="lz-marks",n.style.cssText="position:absolute!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let o=n.attachShadow({mode:"open"});o.appendChild(t("style",{text:ft+Yt}));let a=t("div.layer"),e=t("div.tip");o.append(a,e);let f=new Map,m=new Set,l=0,c=null,u=null,b=new IntersectionObserver(T=>{for(let C of T)C.isIntersecting?m.add(C.target):(m.delete(C.target),f.get(C.target)?.node.classList.remove("on"));k()},{rootMargin:"120px"});function x(){n.isConnected||document.documentElement.appendChild(n)}function k(){l||(l=requestAnimationFrame(()=>{l=0,j()}))}let N=(T,C)=>{for(let S=C;S;S=S.parentNode||S.host)if(S===T)return!0;return!1};function A(T,C){let S=C.left+C.width/2,z=C.top+C.height/2;if(S<0||z<0||S>window.innerWidth||z>window.innerHeight)return!1;let L=document.elementFromPoint(S,z);for(;L?.shadowRoot?.elementFromPoint;){let R=L.shadowRoot.elementFromPoint(S,z);if(!R||R===L)break;L=R}return!!L&&L!==T&&!N(T,L)&&!N(L,T)}function j(){let T=window.scrollX,C=window.scrollY;for(let S of m){let z=f.get(S);if(!z)continue;if(!S.isConnected){E(S);continue}let L=S.getBoundingClientRect();if(L.width<6||L.height<6||A(S,L)){z.node.classList.remove("on");continue}let R=Math.round(L.left+T),F=Math.round(L.top+C),Z=Math.round(L.width),D=Math.round(L.height);(z.x!==R||z.y!==F)&&(z.node.style.transform=`translate3d(${R}px, ${F}px, 0)`,z.x=R,z.y=F),(z.w!==Z||z.h!==D)&&(z.node.style.width=`${Z}px`,z.node.style.height=`${D}px`,z.w=Z,z.h=D,z.node.classList.toggle("small",D<26)),z.node.classList.add("on")}c&&K()}function E(T){let C=f.get(T);C&&(b.unobserve(T),m.delete(T),C.node.remove(),f.delete(T))}function B(T){x();let C=new Map;for(let S of T)S.el?.isConnected&&C.set(S.el,S);for(let S of[...f.keys()])C.has(S)||E(S);for(let[S,z]of C){let L=f.get(S);if(!L){let F=t("div.mark"),Z=parseFloat(getComputedStyle(S).borderTopLeftRadius);F.style.borderRadius=`${Number.isFinite(Z)&&Z>0?Math.min(Z,16):6}px`;let D=t("span.chip");F.appendChild(D),a.appendChild(F),L={node:F,chip:D,sig:""},f.set(S,L),b.observe(S)}let R=`${z.frame?1:0}|${z.selected?1:0}|${z.tone||""}|${z.chip||""}`;R!==L.sig&&(L.sig=R,L.node.classList.toggle("frame",!!z.frame),L.node.classList.toggle("selected",!!z.selected),L.node.classList.toggle("pos",z.tone==="pos"&&!!z.frame),L.chip.hidden=!z.chip,L.chip.textContent=z.chip||"",L.chip.className=`chip${z.tone&&z.tone!=="accent"?" "+z.tone:""}`)}k()}function K(){if(!c?.isConnected)return U();let T=c.getBoundingClientRect(),C=264,S=e.offsetHeight||140,z=T.left+T.width/2-C/2;z=Math.max(8,Math.min(z,window.innerWidth-C-8)),u&&z+C>u.left-8&&z<u.right&&(z=Math.max(8,u.left-C-10));let L=T.bottom+10;L+S>window.innerHeight-8&&(L=T.top-S-10),L<8&&(L=8),e.style.transform=`translate3d(${Math.round(z+window.scrollX)}px, ${Math.round(L+window.scrollY)}px, 0)`}function H(T,C){x(),c=T,e.replaceChildren(C),K(),e.classList.add("on")}function U(){c=null,e.classList.remove("on")}function Y(T){u=T}function q(T){n.setAttribute("data-theme",T)}return window.addEventListener("scroll",k,{capture:!0,passive:!0}),window.addEventListener("resize",k,{passive:!0}),setInterval(()=>{f.size&&!document.hidden&&k()},700),{set:B,schedule:k,showTip:H,hideTip:U,setTheme:q,setAvoid:Y,get tipTarget(){return c},count:()=>f.size}}var te=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 88px 44px;
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-faint);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var X=(n,o=0)=>J(n,o),mt=n=>`${n>0?"+":n<0?"−":""}${Math.abs(n).toFixed(1)}`;function ee({bus:n,actions:o,brand:a}){let e=document.createElement("div");e.id=n.rootId,e.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let f=e.attachShadow({mode:"open"});f.appendChild(t("style",{text:ft+te}));let m=t("span.dot"),l=t("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},I("lens",18),t("span",{text:a.name}),m),c=t("div.tabs",{role:"tablist"}),u=t("div.body"),b=t("div.foot"),x=t("small"),k=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),N=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),A=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},I("gear")),j=t("div.head",{},t("div.brand",{},t("span.logo",{},I("lens",15)),t("span",{text:a.name}),x),t("span.grow"),N,k,A,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},I("close"))),E=t("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},j,c,u,b);f.append(l,E);let B=()=>{e.isConnected||document.documentElement.appendChild(e)};B(),new MutationObserver(B).observe(document.documentElement,{childList:!0});let K="",H=null,U=new Map,Y=r=>{for(let i of r.composedPath()){if(i===e)break;if(i?.dataset?.act)return i}return null},q=null;n.on("ui:pointerdown",r=>{if(r.button!==0)return;let i=r.composedPath(),p=i.includes(l),y=i.includes(j)&&!i.some($=>$?.dataset?.act);if(!p&&!y)return;let _=p?l:E,w=_.getBoundingClientRect();q={target:_,key:p?"fab":"panel",sx:r.clientX,sy:r.clientY,ox:w.left,oy:w.top,moved:!1},n.setDragging(!0)}),n.on("drag:move",r=>{if(!q)return;let i=r.clientX-q.sx,p=r.clientY-q.sy;!q.moved&&Math.hypot(i,p)<5||(q.moved=!0,q.target.classList.add("dragging"),C(q.target,q.ox+i,q.oy+p))}),n.on("drag:end",()=>{if(q){if(n.setDragging(!1),q.target.classList.remove("dragging"),q.moved){let r=q.target.getBoundingClientRect();o.savePosition(q.key,{left:r.left,top:r.top}),T=!0,setTimeout(()=>{T=!1},60)}q=null}});let T=!1;function C(r,i,p){let y=r.offsetWidth||120,_=r.offsetHeight||40,w=Math.max(6,Math.min(i,window.innerWidth-y-6)),$=Math.max(6,Math.min(p,window.innerHeight-Math.min(_,60)-6));r.style.left=`${Math.round(w)}px`,r.style.top=`${Math.round($)}px`,r.style.right="auto"}n.on("ui:click",r=>{if(T)return;let i=Y(r);if(!i||i.disabled)return;r.preventDefault();let p=i.dataset.act;if(p==="toggle")return d();if(p==="close")return s();let y=o[p];y&&y(i.dataset.arg,i,f)}),n.on("ui:keydown",r=>{if(r.key==="Escape"&&s(),r.key==="Enter"){let i=r.composedPath()[0];i?.dataset?.enter&&o[i.dataset.enter]?.(i.value,i,f)}});let S=(r,i)=>t("span.form",{},[...String(r||"")].slice(0,5).map(p=>t(`i${p==="В"?".w":p==="П"?".l":""}`,{text:p,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[p]||""})),i);function z(r){let i=r.live,p=i?t("div.center",{},i.score?.length===2?t("span.score",{text:`${i.score[0]} : ${i.score[1]}`}):null,t("span.badge.live",{text:i.state||"Лайв"})):t("div.center",{},t("span",{text:r.start||"до матча"})),y=i?.periods?.length?t("div.periods",{text:i.periods.map(w=>w.raw?`${w.label} ${w.raw}`:`${/^\d+$/.test(w.label)?`${w.label}-й отрезок`:w.label} ${w.home}:${w.away}`).join(" · ")}):null,_=i?.extras?.length?t("div.periods",{text:i.extras.map(w=>`${w.kind} ${w.home}:${w.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:r.league||r.sportName||"",title:r.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:r.home,title:r.home}),r.form?.home?S(r.form.home):null),p,t("div.team.away",{},t("b",{text:r.away,title:r.away}),r.form?.away?S(r.form.away):null)),y,_)}function L(r){let i=r.rows.some(p=>Number.isFinite(p.model));return t("div.card",{},t("div.kicker",{},t("span",{text:r.title}),Number.isFinite(r.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${X(r.margin,1)}`}):null),r.rows.map(p=>{let y=i&&Number.isFinite(p.model)?(p.model-p.fair)*100:null;return t("div.prob",{},t("span.name",{text:p.name,title:p.name}),t("span.odd",{text:W(p.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((p.fair||0)*100)}%`}),Number.isFinite(p.model)?t("u",{style:`left:${Math.round(p.model*100)}%`}):null),t("span.pct",{},X(i&&Number.isFinite(p.model)?p.model:p.fair),y!=null&&Math.abs(y)>=.05?t(`small${y>0?".pos":".neg"}`,{text:`${mt(y)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),i?t("span.model",{text:"оценка модели"}):null))}function R(r){let i=r.analysis;if(i.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},i.steps.map(($,P)=>t(`div.step${P===i.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:$})))));if(i.status==="error")return t("div.card",{},t("div.note.warn",{},I("alert"),t("span",{text:i.error})),i.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},I("gear"),"Открыть настройки")):null);if(i.status!=="done"||!i.result)return null;let p=i.result,y={home:r.match?.home,away:r.match?.away,draw:"ничья"}[p.lean],_=p.proposed?.lean&&p.proposed.lean!=="none"&&p.lean==="none"?{name:{home:r.match?.home,away:r.match?.away,draw:"ничью"}[p.proposed.lean],by:Math.abs(p.proposed.shift[p.proposed.lean]||0)}:null,w=new Map((p.facts||[]).map($=>[$.id,$]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${p.confidence||"низкая"}`})),t("div.verdict",{text:y?`Данные сдвигают оценку в сторону: ${y}`:_?`Данные слегка склоняют в сторону: ${_.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),_?t("div.note",{style:"margin-bottom:10px"},I("info"),t("span",{text:`Модель предложила сдвиг на ${_.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,p.summary?t("p.summary",{text:p.summary}):null,p.factors?.length?t("ul.factors",{},p.factors.map($=>t(`li.factor${$.side==="home"?".home":$.side==="away"?".away":""}`,{},t("div",{},t("p",{text:$.text}),t("div.src",{},($.facts||[]).map(P=>w.get(P)).filter(Boolean).map(P=>t("span.tag",{text:`${P.id} · ${P.source}`,title:P.text}))))))):null,p.risks?.length?t("div.note",{style:"margin-top:10px"},I("info"),t("span",{text:`Что может сломать вывод: ${p.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:U.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${p.facts?.length||0})`}),t("ul.facts",{},(p.facts||[]).map($=>t("li",{},t("b",{text:$.id}),t("span",{},$.text," ",t("em",{text:`— ${$.source}`})))))),t("div.hint",{style:"margin-top:8px",text:p.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function F(r){let i=r.compare?.consensus||r.analysis?.result?.consensus;if(!i?.consensus||!r.line?.rows?.length||r.line.rows.length!==i.consensus.length)return null;let p=i.updated?new Date(i.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Прогноз рынка"}),t("span.badge",{text:`${i.count} контор`})),r.line.rows.map((y,_)=>{let w=i.consensus[_],$=y.odd*w-1,P=Number.isFinite(y.fair)?(y.fair-w)*100:0;return t("div.prob",{},t("span.name",{text:y.name,title:y.name}),t("span.odd",{text:W(1/w),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(w*100)}%`}),t("u",{style:`left:${Math.round((y.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},X(w),$>.005?t("small.pos",{text:`кэф выше рынка ${mt($*100)}%`}):Math.abs(P)>=2?t(`small${P>0?".neg":""}`,{text:`${mt(P)} п.п. к рынку`,title:P>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),t("span.model",{text:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${i.pinnacle?`Pinnacle ${i.pinnacle.map(W).join(" / ")}. `:""}${i.betfair?`Betfair ${i.betfair.map(W).join(" / ")}. `:""}Цены ${i.count} контор без маржи${p?`, обновлено в ${p}`:""}${i.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}function Z(r){if(r.status==="idle")return null;if(r.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let i=r.labels||[];if(!r.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:r.note||"В открытых линиях этой пары нет."}));let p=i.map((y,_)=>Math.max(...r.rows.map(w=>w.odds[_]||0)));return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),i.map(y=>t("th",{text:y}))),r.rows.map(y=>t("tr",{},t("td.name",{text:y.name,title:y.sharp?"Цена с мирового рынка, для сравнения":""}),y.odds.map((_,w)=>t(`td${_&&_===p[w]&&r.rows.length>1?".best":""}`,{text:_?W(_):"—"}))))),r.note?t("div.hint",{style:"margin-top:8px",text:r.note}):null)}function D(r){let i=[],p=(y,_,w)=>i.push(t("dt",{text:y}),t(`dd${w?"."+w:""}`,{text:_}));return Number.isFinite(r.fair)?(p("Шанс по линии без маржи",X(r.fair,1)),p("Кэф без маржи конторы",W(r.fairOdd)),p("Маржа конторы в этом рынке",X(r.margin,1))):p("Заложено в кэфе (с маржой)",X(1/r.odd,1)),Number.isFinite(r.model)&&(p("Оценка модели",X(r.model,1)),p("Ожидание на рубль по модели",`${mt(r.ev*100)}%`,r.ev>.005?"pos":r.ev<-.005?"neg":"")),r.best&&p(`Лучшая цена: ${r.best.name}`,W(r.best.odd),r.best.odd>r.odd?"pos":""),t("div.card.accent",{},t("div.kicker",{},t("span",{text:r.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},I("close",13))),t("div.pick-head",{},t("span.big",{text:W(r.odd)}),t("span.what",{text:r.label,title:r.label})),t("dl.kv",{},i),r.note?t("div.hint",{style:"margin-top:8px",text:r.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!r.canAdd,title:r.canAdd?"":"Нужен рынок с полным набором исходов"},I("plus",14),r.inExpress?"Уже в экспрессе":"В расчёт экспресса")))}function ot(r){let i=(p,y)=>t("div",{style:"min-width:0"},t("b",{text:p,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),y.map(_=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:_.nick}),t("span",{style:"color:var(--lz-muted)",text:_.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},i(r.homeName,r.home),i(r.awayName,r.away)))}function rt(r,i){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:i.home}),t("th",{text:i.away})),r.rows.map(p=>t("tr",{},t("td",{text:p.label}),t("td",{text:p.home}),t("td",{text:p.away})))),r.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${r.samples[0]} и ${r.samples[1]} карт.`}):null)}function gt(r){let i=[];if(r.pick&&i.push(D(r.pick)),!r.match)return i.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),i;i.push(z(r.match)),r.esports&&i.push(ot(r.esports)),r.match.stats?.rows?.length&&i.push(rt(r.match.stats,r.match)),r.line&&i.push(L(r.line));let p=F(r);p&&i.push(p);let y=r.analysis.status==="loading";i.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:y},I("spark"),y?"Разбираю…":r.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:r.compare.status==="loading"},I("scale"),"Сравнить цены"))),r.quota&&i.push(t("div.hint.center-text",{text:r.quota}));let _=R(r);_&&i.push(_);let w=Z(r.compare);return w&&i.push(w),i}function bt(r){let i=r.scan;return i?.rows?.length?[t("div.card",{},t("div.kicker",{},t("span",{text:i.title}),t("span.badge",{text:`средняя маржа ${X(i.average,1)}`})),t("table",{},t("tr",{},t("th",{text:i.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),i.rows.map(p=>t("tr.click",{"data-act":"scan-go","data-arg":String(p.index),title:"Показать на странице"},t("td.name",{},p.name,p.sub?t("span.sub",{text:p.sub}):null),t("td",{},p.fav,t("span.sub",{text:X(p.favPct)})),t(`td${p.low?".best":""}`,{text:X(p.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:i.note}))]:[t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function lt(r){let i=r.express;if(!i.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let p=i.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${i.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},I("trash",13),"Очистить")),i.legs.map(y=>t("div.leg",{},t("div.t",{},t("b",{text:y.label,title:y.label}),t("span",{text:y.title,title:y.title})),t("span.o",{text:W(y.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":y.id,title:"Убрать",style:"width:24px;height:24px"},I("close",13))))),p?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:W(p.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:X(p.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:W(p.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:X(p.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function xt(r){let i=r.settings,p=(y,_,w)=>t("div.seg",{},w.map(([$,P])=>t(`button${_===$?".on":""}`,{type:"button","data-act":y,"data-arg":$,text:P})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),p("set-overlay",i.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),p("set-theme",i.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]]))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${i.ready?".pos":""}`,{text:i.ready?"подключён":"не подключён"})),i.proxy?t("div.field",{},t("label",{text:"Доступ"}),p("set-mode",i.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,i.mode==="license"&&i.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:i.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),i.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[i.licenseMask?`Ключ ${i.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",i.plan,i.usage].filter(Boolean).join(" "),a.bot&&!i.licenseMask?[" ",t("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:i.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),i.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${i.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function ct(r){H=r;let i=JSON.stringify(r);if(i===K)return;K=i;for(let w of u.querySelectorAll("details[data-key]"))U.set(w.dataset.key,w.open);let p=u.scrollTop;x.textContent=r.bookName?`· ${r.bookName}`:"",m.classList.toggle("off",r.settings.overlay==="off"),k.replaceChildren(I(r.theme==="dark"?"sun":"moon")),N.replaceChildren(I(r.settings.overlay==="off"?"eyeOff":"eye")),N.classList.toggle("on",r.settings.overlay!=="off"),A.classList.toggle("on",r.tab==="settings"),A.dataset.arg=r.tab==="settings"?r.backTab:"settings";let y=[["match","Матч"],["scan","Маржа"],["express","Экспресс"]];c.replaceChildren(...y.map(([w,$])=>t(`button.tab${r.tab===w?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":w},$,w==="express"&&r.express.legs.length?t("span.count",{text:String(r.express.legs.length)}):null)));let _=r.tab==="settings"?xt(r):r.tab==="scan"?bt(r):r.tab==="express"?lt(r):gt(r);u.replaceChildren(..._.filter(Boolean)),u.scrollTop=p,b.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function at(r){e.setAttribute("data-theme",r)}function st(){E.hidden=!1,o.opened?.()}function s(){E.hidden=!0}function d(){E.hidden?st():s()}function g(r){r?.fab&&C(l,r.fab.left,r.fab.top),r?.panel&&C(E,r.panel.left,r.panel.top)}let v=0;function h(r){f.querySelector(".toast")?.remove();let i=t("div.toast",{text:r,role:"status"});f.appendChild(i),clearTimeout(v),v=setTimeout(()=>i.remove(),2600)}return{render:ct,setTheme:at,open:st,close:s,toggle:d,restore:g,toast:h,shadow:f,rect:()=>E.hidden?null:E.getBoundingClientRect(),get isOpen(){return!E.hidden},get view(){return H}}}var ne="Расширение обновилось. Обновите эту вкладку (F5).";function Q(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function V(n,o={}){if(!Q())return{ok:!1,error:ne,code:"reload"};try{return await chrome.runtime.sendMessage({type:n,...o})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let e=String(a?.message||a);return/context invalidated|message port closed|receiving end does not exist/i.test(e)||!Q()?{ok:!1,error:ne,code:"reload"}:{ok:!1,error:e}}}function oe(n){if(Q())try{chrome.runtime.onMessage.addListener(o=>{n(o)})}catch{}}async function St(n){if(!Q())return{};try{return await chrome.storage.local.get(n)}catch{return{}}}function nt(n){if(Q())try{chrome.storage.local.set(n)}catch{}}var ht=globalThis.__lzBus,Tt=ht&&window.top===window?Ut(location.hostname):null;Tt&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Ee(Tt.adapter,Tt.book));async function Ee(n,o){let a=await St(["lz.settings","lz.positions","lz.express"]),e={settings:{...yt,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Oe(a["lz.express"]),analysis:new Map,compare:new Map,status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},f=new WeakMap,m=new WeakMap,l=Jt(),c=ee({bus:ht,brand:Lt,actions:bt()});c.restore(e.positions);function u(s){let d=s.outcomes.map(h=>h.odd).join("/"),g=f.get(s);if(g?.sig===d)return g.set;let v=vt(s.outcomes.map(h=>h.odd));return f.set(s,{sig:d,set:v}),v}function b(){return e.match?e.analysis.get(e.match.key):null}function x(s){let d=b()?.result;if(!d?.model||s.scope==="list"||!e.match||!Object.values(d.shift||{}).some(i=>Math.abs(i)>=.5))return null;let{home:g,draw:v,away:h}=d.model,r=s.outcomes.length;if(s.kind==="1x2"&&s.main&&r===3)return[g,v,h];if(s.kind==="12"&&s.main&&r===2&&v<.005)return[g,h];if(s.kind==="dc"&&s.main&&r===3)return[g+v,g+h,v+h];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&r===2){let i=s.period===e.match.home?g:s.period===e.match.away?h:null;if(i!=null)return[i,1-i]}return null}function k(){let s=e.markets.filter(d=>d.scope!=="list"&&d.main&&(d.kind==="1x2"||d.kind==="12"));return s.find(d=>d.scope==="top")||s[0]||null}function N(s,d){let g=s.outcomes[d].label;return s.scope==="list"?!s.event||!s.main?g:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][d]||g:s.kind==="12"&&[s.event.home,s.event.away][d]||g:e.match?s.kind==="1x2"?[e.match.home,"Ничья",e.match.away][d]||g:s.kind==="12"&&[e.match.home,e.match.away][d]||g:g}function A(){let s=e.settings.overlay,d=[];for(let v of e.markets){if(v.outcomes.forEach((w,$)=>m.set(w.el,{market:v,index:$})),s==="off")continue;let h=u(v);if(h.kind==="partial")continue;let r=x(v),i=r||h.fair,p=0;for(let w=1;w<h.fair.length;w+=1)h.fair[w]>h.fair[p]&&(p=w);let y="accent";if(r){let w=0;for(let $=1;$<r.length;$+=1)r[$]-h.fair[$]>r[w]-h.fair[w]&&(w=$);r[w]-h.fair[w]>=.015&&(p=w,y="pos")}let _=v.scope!=="list"||v.main&&(v.kind==="1x2"||v.kind==="12");v.outcomes.forEach((w,$)=>{let P=$===p&&_;!P&&s!=="all"||d.push({el:w.el,frame:P,chip:J(i[$]),tone:P?y:"quiet"})})}let g=j();if(g){let v=d.find(h=>h.el===g.item.el);v?v.selected=!0:d.push({el:g.item.el,frame:!1,selected:!0,chip:null})}l.set(d)}function j(){if(!e.selected)return null;let s=e.markets.find(g=>g.id===e.selected.id),d=s?.outcomes[e.selected.index];return d?.el?.isConnected?{market:s,item:d,index:e.selected.index}:null}function E(){if(e.settings.theme!=="auto")return e.settings.theme;for(let s of[document.body,document.documentElement]){let g=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!g||g[4]==="0")continue;return(.2126*g[1]+.7152*g[2]+.0722*g[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function B(){location.href!==e.url&&(e.url=location.href,e.selected=null,l.hideTip());let s="other",d=[],g=null;try{s=n.pageType(document,location),d=n.collect(document,location),g=n.readMatch(document,location)}catch(h){console.error("[Линза] страница не прочитана",h)}s!==e.pageType&&(e.pageType=s,e.tab!=="settings"&&e.tab!=="express"&&(e.tab=s==="match"?"match":"scan")),e.markets=d,e.match=g;let v=E();v!==e.theme&&(e.theme=v),l.setTheme(e.theme),c.setTheme(e.theme),A(),rt(),U(),c.isOpen&&c.render(R())}let K=new Set,H=null;function U(){if(n.observeTargets)for(let s of n.observeTargets(document))K.has(s)||(K.add(s),H=H||new MutationObserver(T),H.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let Y=0,q=0;function T(){let s=Date.now();q||(q=s),clearTimeout(Y);let d=s-q>900?0:220;Y=setTimeout(()=>{q=0,!document.hidden&&B()},d)}function C(){let s=k();if(!s)return null;let d=u(s);if(d.kind!=="full")return null;let g=x(s);return{title:"Что заложено в цене",margin:d.margin,rows:s.outcomes.map((v,h)=>({name:N(s,h),odd:v.odd,fair:d.fair[h],model:g?g[h]:null}))}}function S(){let s=j();if(!s)return null;let{market:d,item:g,index:v}=s,h=u(d),r=x(d),i=h.fair?h.fair[v]:null,p=d.event?`${d.event.home} — ${d.event.away}`:e.match?`${e.match.home} — ${e.match.away}`:"",y=e.match?e.compare.get(e.match.key):null,_=null;if(y?.rows?.length&&d.main&&(d.kind==="1x2"||d.kind==="12")&&d.scope!=="list")for(let $ of y.rows){let P=$.odds[v];P&&(!_||P>_.odd)&&(_={name:$.name,odd:P})}let w=`${d.id}#${v}`;return{market:[d.title,d.period,d.line].filter(Boolean).join(" · "),label:[N(d,v),p].filter(Boolean).join(" · "),odd:g.odd,fair:i,margin:h.margin,fairOdd:i?1/i:null,model:r?r[v]:null,ev:r?Bt(r[v],g.odd):null,best:_,canAdd:Number.isFinite(i)&&!e.express.some($=>$.id===w),inExpress:e.express.some($=>$.id===w),note:h.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":r?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function z(){let s=[];if(e.pageType==="match"?e.markets.forEach((h,r)=>{if(h.scope==="list")return;let i=u(h);if(i.kind!=="full")return;let p=0;for(let y=1;y<i.fair.length;y+=1)i.fair[y]>i.fair[p]&&(p=y);s.push({index:r,name:h.title,sub:[h.period,h.line].filter(Boolean).join(" · "),margin:i.margin,fav:h.outcomes[p].label,favPct:i.fair[p]})}):e.markets.forEach((h,r)=>{if(!h.event||!h.main||h.kind!=="1x2"&&h.kind!=="12")return;let i=u(h);if(i.kind!=="full")return;let p=0;for(let _=1;_<i.fair.length;_+=1)i.fair[_]>i.fair[p]&&(p=_);let y=h.kind==="1x2"?[h.event.home,"Ничья",h.event.away][p]:[h.event.home,h.event.away][p];s.push({index:r,name:`${h.event.home} — ${h.event.away}`,sub:h.event.league||h.event.time,margin:i.margin,fav:y,favPct:i.fair[p]})}),!s.length)return null;let d=new Set;for(let h=s.length-1;h>=0;h-=1){let r=`${s[h].name}|${s[h].sub}`;d.has(r)?s.splice(h,1):d.add(r)}let g=s.reduce((h,r)=>h+r.margin,0)/s.length;s.sort((h,r)=>h.margin-r.margin);let v=s.slice(0,16);return v.forEach(h=>{h.low=h.margin<=g*.8}),{title:e.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:e.pageType==="match"?"Рынок":"Матч",average:g,rows:v,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${v.length} из ${s.length}, сначала самые дешёвые.`}}function L(){let s=e.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function R(){let s=e.match?.key,d=s&&e.analysis.get(s)||{status:"idle",steps:[]},g=s&&e.compare.get(s)||{status:"idle"},v=e.match?.live&&n.readEsportsWidget?n.readEsportsWidget(document):null,h=e.status;return{tab:e.tab,backTab:e.backTab,theme:e.theme,bookName:o.name,pageType:e.pageType,match:e.match?{...e.match,sportName:Ct[e.match.sport]||""}:null,esports:v?{...v,homeName:e.match.home,awayName:e.match.away}:null,line:C(),analysis:{status:d.status,steps:d.steps||[],result:d.result||null,error:d.error||"",needKey:!!d.needKey},compare:g,pick:S(),scan:e.tab==="scan"?z():null,express:{legs:e.express,stats:qt(e.express)},quota:L(),settings:{overlay:e.settings.overlay,theme:e.settings.theme,mode:h.mode,proxy:h.proxy,ready:h.ready,hasKey:h.hasKey,keyMask:h.keyMask,licenseMask:h.licenseMask,plan:h.plan==="free"||!h.plan?"":`Тариф «${h.plan==="max"?"Макс":"Про"}»${h.until?` до ${h.until.split("-").reverse().join(".")}`:""}.`,usage:h.limit?`Сегодня разборов: ${h.used} из ${h.limit}.`:""}}}let F=()=>{c.isOpen&&c.render(R())};function Z(s){Object.assign(e.settings,s),nt({"lz.settings":e.settings}),B(),c.render(R())}async function D(){let s=await V("lz:status");s.ok&&(e.status=s.data),F()}function ot(){let s=k(),d=s?u(s):null;return{book:o.name,match:e.match,market:s&&d?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((g,v)=>N(s,v)),odds:s.outcomes.map(g=>g.odd)}:null}}function rt(){if(!e.match||!Q())return;let s=ot();if(!s.market)return;let d=`${e.match.key}|${s.market.odds.join("/")}`;d!==rt.last&&(rt.last=d,V("lz:quote",s))}async function gt(){let s=e.match;if(!s||e.analysis.has(s.key))return;let d=await V("lz:cached",{match:s});!d.ok||!d.data||e.analysis.has(s.key)||(e.analysis.set(s.key,{status:"done",steps:[],result:d.data}),B(),F())}function bt(){return{opened(){D(),B(),gt(),c.render(R())},tab(s){s==="settings"&&(e.backTab=e.tab==="settings"?e.backTab:e.tab),e.tab=s||"match",c.render(R())},theme(){Z({theme:e.theme==="dark"?"light":"dark"})},"overlay-toggle"(){Z({overlay:e.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){Z({overlay:s})},"set-theme"(s){Z({theme:s})},async"set-mode"(s){await V("lz:settings",{mode:s}),D()},async"save-key"(s,d,g){let v=g.getElementById("lz-key"),h=(v?.value||"").trim();if(h.length<8)return c.toast("Вставьте ключ целиком");let r=await V("lz:settings",{apiKey:h});c.toast(r.ok?"Ключ сохранён":r.error),v&&(v.value=""),D()},async"clear-key"(){await V("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),D()},async"save-license"(s,d,g){let v=g.getElementById("lz-license"),h=(v?.value||"").trim();if(h.length<6)return c.toast("Вставьте ключ целиком");let r=await V("lz:settings",{licenseKey:h});c.toast(r.ok?"Ключ принят":r.error),v&&(v.value=""),D()},async"clear-license"(){await V("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),D()},savePosition(s,d){e.positions[s]=d,St(["lz.positions"]).then(g=>{let v=g["lz.positions"]||{};v[location.hostname]=e.positions,nt({"lz.positions":v})})},async analyze(){if(!e.match)return;let s=e.match.key,d={status:"loading",steps:[`${e.match.home} — ${e.match.away}`]};e.analysis.set(s,d),F();let g=await V("lz:analyze",{...ot(),force:!0});g.ok?e.analysis.set(s,{status:"done",steps:d.steps,result:g.data}):e.analysis.set(s,{status:"error",steps:d.steps,error:g.error,needKey:g.code==="no-access"}),D(),B(),c.render(R())},async compare(){if(!e.match)return;let s=e.match.key;e.compare.set(s,{status:"loading"}),F();let d=await V("lz:compare",ot());e.compare.set(s,d.ok?{status:"done",...d.data}:{status:"done",rows:[],labels:[],note:d.error}),F()},"pick-clear"(){e.selected=null,A(),F()},"leg-add"(){let s=S(),d=j();!s?.canAdd||!d||(e.express.push({id:`${d.market.id}#${d.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),nt({"lz.express":e.express}),c.toast("Добавлено в расчёт экспресса"),F())},"leg-remove"(s){e.express=e.express.filter(d=>d.id!==s),nt({"lz.express":e.express}),F()},"leg-clear"(){e.express=[],nt({"lz.express":e.express}),F()},"scan-go"(s){let d=e.markets[Number(s)],g=d?.outcomes[0]?.el;g?.isConnected&&(g.scrollIntoView({behavior:"smooth",block:"center"}),e.selected={id:d.id,index:0},setTimeout(A,400))}}}function lt(s){let d=s.composedPath();for(let g=0;g<Math.min(d.length,6);g+=1){let v=d[g]instanceof Element?m.get(d[g]):null;if(v&&v.market.outcomes[v.index]?.el===d[g])return v}return null}function xt({market:s,index:d}){let g=u(s),v=x(s),h=s.event?`${s.event.home} — ${s.event.away}`:"",r=s.outcomes.map((p,y)=>{let _=g.fair?g.fair[y]:1/p.odd;return t(`div.tip-row${y===d?".hot":""}`,{},t("span",{text:N(s,y)}),t("span.odd",{text:W(p.odd)}),t("span.pct",{text:J(_,_<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(_*100)}%`})))}),i=g.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:J(g.margin,1)}),v?t("span",{}," · модель: ",t("b",{text:J(v[d],1)})):null);return t("div",{},t("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),h?t("div.tip-sub",{text:h}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),r.slice(0,8),i)}let ct=0,at=null;ht.on("page:pointerover",s=>{if(e.settings.overlay==="off")return;let d=lt(s),g=d?d.market.outcomes[d.index].el:null;if(g!==at){if(at=g,clearTimeout(ct),!d)return l.hideTip();ct=setTimeout(()=>{at!==g||!g.isConnected||(l.setAvoid(c.rect()),l.showTip(g,xt(d)))},280)}}),ht.on("page:click",s=>{let d=lt(s);d&&(e.selected={id:d.market.id,index:d.index},A(),F())}),oe(s=>{if(s.type!=="lz:progress")return;let d=e.analysis.get(s.key);!d||d.status!=="loading"||(d.steps=[...d.steps,s.text].slice(-7),F())});let st=()=>{B(),new MutationObserver(T).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||B()}),setInterval(()=>{!document.hidden&&location.href!==e.url&&B()},600),setInterval(()=>{!document.hidden&&c.isOpen&&T()},4e3),Q()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(e.settings={...yt,...s["lz.settings"].newValue||{}},B())}),D()};document.body?st():document.addEventListener("DOMContentLoaded",st,{once:!0}),document.documentElement.setAttribute("data-lz",o.id),globalThis.__lz={state:e,view:R,refresh:B,overlay:l,panel:c}}function Oe(n){let o=Date.now()-432e5;return(Array.isArray(n)?n:[]).filter(a=>a&&a.at>o&&a.odd>1)}})();
