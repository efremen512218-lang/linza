(()=>{var Bt=a=>typeof a=="string"?a:"",Pt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Bt("https://efremen512218-lang.github.io/linza/"),telegram:Bt("https://t.me/linza_odds"),bot:Bt("https://t.me/linza_keys_bot?start=ext")},Pn=Bt("https://185-72-145-3.sslip.io"),Ge={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Ye=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function de(a){let r=String(a||"").toLowerCase();return Ye.find(i=>i.hosts.some(e=>r===e||r.endsWith(`.${e}`)))||null}var ee={overlay:"picks",theme:"auto",mode:"own",model:Ge.model,stake:1e3},ue={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function mt(a){let r=String(a??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let i=parseFloat(r.replace(",","."));return i>=1.001&&i<=1e3?i:null}var pe=a=>a.reduce((r,i)=>r+1/i,0);function St(a){let r=(a||[]).filter(e=>Number.isFinite(e)&&e>1);if(r.length<2||r.length!==(a||[]).length)return{kind:"partial",margin:null,fair:null};let i=pe(r);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:r.map(e=>1/e/i)};if(r.length===3&&i>=1.97&&i<=2.4){let e=i/2;return{kind:"double",margin:e-1,fair:r.map(f=>Math.min(.995,1/f/e))}}return{kind:"partial",margin:null,fair:null}}function fe(a){let r=(a||[]).map(g=>g||[]).filter(g=>g.length),i=r.flat().filter(Boolean);if(i.length<2)return{sets:[],rest:i};let e=g=>g.length>=2&&g.every(Boolean)&&St(g.map(k=>k.odd)).kind!=="partial",f=g=>{let k=g.filter(z=>z.some(Boolean));if(!k.length)return null;let $=k.filter(e);if($.length/k.length<.6)return null;let S=new Set($.flat());return{sets:$,rest:i.filter(z=>!S.has(z))}},p=g=>{let k=[];for(let $=0;$<r.length;$+=g)k.push(r.slice($,$+g).flat());return k},l=()=>{let g=[];for(let k=0;k+1<r.length;k+=2){let $=Math.max(r[k].length,r[k+1].length);for(let S=0;S<$;S+=1)g.push([r[k][S]??null,r[k+1][S]??null])}return g},u=[()=>p(1)];r.length>=2&&r.length%2===0&&u.push(l,()=>p(2)),r.length>=3&&r.length%3===0&&u.push(()=>p(3)),r.length>1&&u.push(()=>[r.flat()]);for(let g of u){let k=f(g());if(k)return k}return{sets:[],rest:i}}function me(a,r=1.13){let i=u=>{let g=pe(u.map(k=>k.odd));return g>=.995&&g<=r?!0:u.length===3&&g>=1.99&&g<=r*2},e=u=>Math.abs(u*4-Math.round(u*4))<1e-9,f=[],p=[],l=0;for(;l<a.length;){let u=a.slice(l,l+3),g=a.slice(l,l+2);u.length===3&&i(u)?(f.push(u),l+=3):g.length===2&&i(g)?(f.push(g),l+=2):a[l+2]&&e(a[l+1].odd)&&i([a[l],a[l+2]])?(f.push([a[l],a[l+2]]),p.push(a[l+1]),l+=3):(p.push(a[l]),l+=1)}return{sets:f,rest:p}}function he(a){let r=(a||[]).filter(f=>f&&f.odd>1&&f.fair>0&&f.fair<1);if(!r.length)return null;let i=r.reduce((f,p)=>f*p.odd,1),e=r.reduce((f,p)=>f*p.fair,1);return{legs:r.length,odd:i,chance:e,fairOdd:1/e,margin:1-i*e}}function ge(a,r){return a*r-1}function V(a){return Number.isFinite(a)?a>=100?a.toFixed(0):a>=10?a.toFixed(1):a.toFixed(2):"—"}function ht(a,r=0){if(!Number.isFinite(a))return"—";let i=a*100;return i>0&&i<1&&r===0?"<1%":`${i.toFixed(r)}%`}function ne(a){return String(a??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var Je=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function be(a){return String(a??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!Je.has(r))}function _t(a,r){let i=ne(a),e=ne(r);if(i.length<2||e.length<2)return 0;if(i===e)return 1;let f=i.length<=e.length?i:e,p=f===i?e:i;if(f.length>=4&&p.includes(f))return .85;let l=be(a),u=be(r);if(l.length&&u.length){let $=l.filter(S=>u.some(z=>z===S||S.length>=5&&z.startsWith(S.slice(0,5)))).length/Math.max(l.length,u.length);if($>=.5)return .6+.3*$}let g=0;for(;g<i.length&&g<e.length&&i[g]===e[g];)g+=1;return g>=5?Math.min(.8,.45+g*.04):0}function Qe(a){let r=String(a??"").toLowerCase(),i=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&i.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&i.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&i.push("reserve"),/люб/.test(r)&&i.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&i.push("cyber"),i.join("+")}function yt(a,r){let i=p=>{let l=ne(p),u=Qe(p);return l.length<2?"":u?`${l}~${u}`:l},e=i(a),f=i(r);return!e||!f?"":[e,f].sort().join("|")}var N=a=>(a?.textContent||"").replace(/[ \s]+/g," ").trim(),oe=a=>a.offsetParent===null&&a.tagName!=="BODY";function tn(a){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(a||"").trim())}function en(a){let r=String(a||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return r?r[0]:""}function Tt(a,r){let i=String(a||"").toLowerCase();return/двойной шанс/.test(i)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(i)?"other":/фор[аы]|гандикап/.test(i)?"handicap":/тотал/.test(i)?"total":/обе забьют/.test(i)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(i)?r===3?"1x2":r===2?"12":"other":"other"}var nn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function zt(...a){let r=a.filter(Boolean).join(" ");for(let[i,e]of nn)if(i.test(r))return e;return""}function ae(a){if(!a)return null;let r=mt(N(a));if(r)return r;let i=N(a).split(" ");return mt(i[i.length-1])}var on=0;function vt({scope:a,title:r,period:i="",line:e="",kind:f,outcomes:p,event:l=null,anchor:u=null,eventKey:g=""}){let k=p.length;return{id:`${a}|${g}|${r}|${i}|${e}|${p.map($=>$.label).join("/")}`,serial:on+=1,scope:a,title:r,period:i,line:e,kind:f||Tt(r,k),main:tn(i)&&!en(r),outcomes:p,event:l,anchor:u||p[0]?.el||null}}var j=(a,r)=>[...a.querySelectorAll(r)];function we(a){return(String(a||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function re(a){return a.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":a.querySelector(".card")?"list":"other"}var xe={win:"В",loose:"П",lose:"П",draw:"Н"};function ye(a){return j(a,".competitor-form__value").map(r=>xe[[...r.classList].find(i=>xe[i])]||N(r).slice(0,1)).filter(Boolean).join("")}function an(a){let r=a.querySelector(".marketbook-header--live");if(r){let e=j(r,".game-scoring__item").map(l=>N(l)),f=j(r,".game-periods .period").map(l=>{let u=j(l,"span");return{label:N(l.querySelector("i")),home:N(u[0]),away:N(u[1])}}).filter(l=>l.home!==""&&l.away!==""),p=j(r,".game-specials > div").map(l=>{let u=j(l,"span"),g=l.querySelector("i"),k=g?.classList.contains("yellow-card")?"жёлтые":g?.classList.contains("red-card")?"красные":g?.classList.contains("penalty-card")?"угловые":"";return k?{kind:k,home:N(u[0]),away:N(u[1])}:null}).filter(Boolean);return{state:N(r.querySelector(".game-timing-state")),score:e.length===2?e:[],periods:f,extras:p}}let i=a.querySelector(".match-card");if(i&&!i.querySelector(".match-card__timer--prematch")){let e=N(i.querySelector(".match-card__main-score")).replace(/\s/g,""),f=j(i,".match-card__score").map(l=>N(l)).filter(l=>/^\d{1,2}$/.test(l)),p=j(a,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(l=>N(l)).filter(l=>/\d\s*:\s*\d/.test(l)).slice(0,5);return{state:N(i.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(e)?e.split(":"):[],rounds:f.length>=2?f.slice(0,2):[],periods:p.map((l,u)=>({label:`${u+1} карта`,raw:l})),extras:[]}}return null}function ve(a,r){if(re(a)!=="match")return null;let i=j(a,".breadcrumbs .breadcrumbs__item").map(k=>N(k)).filter(Boolean),e=N(a.querySelector(".event-breadcrumbs")),f=j(a,".marketbook-header--prematch .competitor-name").map(k=>N(k));if(f.length<2&&(f=j(a,".marketbook-header--live .competitors-desc__name").map(k=>N(k))),f.length<2&&(f=j(a,".match-card .match-card__team-name").map(k=>N(k))),f.length<2||!f[0]||!f[1])return null;let p=zt(i[1]&&/киберспорт/i.test(i[0])?i[1]:"",i[0],e),l=/киберспорт/i.test(i[0]||"")?i.slice(2).join(", ")||e.split(",").slice(1).join(",").trim():i.slice(1).join(", "),u=[N(a.querySelector(".prematch-date")),N(a.querySelector(".prematch-time"))].filter(Boolean).join(" ")||N(a.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),g=an(a);return{book:"Winline",id:we(r?.pathname),key:yt(f[0],f[1]),home:f[0],away:f[1],sport:p,league:l,start:g?"":u,live:g,form:{home:ye(a.querySelector(".competitor-form--left")||a.createElement("div")),away:ye(a.querySelector(".competitor-form--right")||a.createElement("div"))},stats:un(pn(a),f[0],f[1]),url:r?.href||""}}function rn(a,r){let i=[];for(let e of j(a,".bet-line")){if(oe(e))continue;let f=N(e.querySelector(".bet-line__market-name")),p=N(e.querySelector(".bet-line__period")),l=j(e,".odd-btn"),u=l.map((k,$)=>{let S=N(k.querySelector(".odd-btn__label")),z=j(k,"span").map(_=>mt(N(_))).find(Boolean)||null;return z?{el:k,odd:z,label:S||se(l.length,$,f),locked:!1}:null});if(u.length<2||u.some(k=>!k))continue;let g=N(e.querySelector(".coef-btn")).replace(/\s+/g," ");i.push(vt({scope:"top",title:f,period:p,line:g,outcomes:u,anchor:e,eventKey:r}))}return i}function se(a,r,i){return/тотал/i.test(i)?["Меньше","Больше"][r]||"":a===3?["П1","Х","П2"][r]:a===2?["1","2"][r]:String(r+1)}function sn(a,r){let i=[];for(let e of j(a,".market")){let f=j(e,".market__row");if(!f.length)continue;let p=N(e.querySelector(".market-title")),l=f.map(g=>{let k=N(g.querySelector(".market__row-text"));return j(g,".market-row-btn").map($=>{let S=mt(N($.querySelector(".market-row-btn__coef")));if(!S||$.hasAttribute("disabled"))return null;let z=$.getAttribute("title")||N($.querySelector(".market-row-btn__text"));return{el:$,odd:S,label:z.replace(/\s+/g," ").trim(),rowLabel:k,locked:!1}})}),{sets:u}=fe(l);for(let g of u){let k=[...new Set(g.map(_=>_.rowLabel).filter(Boolean))],$=k.length<=1,S=$?"":(g[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],z=g.map(_=>({el:_.el,odd:_.odd,label:$?_.label:_.rowLabel||_.label,locked:!1}));i.push(vt({scope:"board",title:p,period:$&&k[0]||"",line:S,kind:Tt(p,z.length),outcomes:z,anchor:e,eventKey:r}))}}return i}var ln=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function cn(a){let r=j(a,".card__competitors .name .name, .half__names .name").map(e=>N(e));if(r.length<2)return null;let i=a.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:we(i),key:yt(r[0],r[1]),home:r[0],away:r[1],href:i,live:/card--live/.test(a.className)||!!a.querySelector(".card__body-live"),time:N(a.querySelector(".header-left__time, .footer__time")),league:N(a.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:a}}function ke(a){let r=[];for(let i of j(a,".card")){if(oe(i))continue;let e=cn(i);if(e){for(let f of j(i,".card__body")){let p=N(f.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(f.className)?"отрезок":"");for(let l of j(f,".card__market")){let u=j(l,".coefficient-button");if(u.length<2)continue;let g=(ln.find(([$])=>$.test(u[0].className))||[])[1]||"other",k=u.map(($,S)=>{let z=/--is-blank/.test($.className)?null:ae($);return z?{el:$,odd:z,label:g==="total"?["Меньше","Больше"][S]:se(u.length,S,""),locked:/coefficient-button_locked/.test($.className)}:null});k.some($=>!$)||r.push(vt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[g]||"Рынок",period:/^матч$/i.test(p)?"":p,line:N(l.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:g,outcomes:k,event:e,anchor:i,eventKey:e.key}))}}for(let f of j(i,".half__coef-buttons")){let p=j(f,".coef-buttons__button"),l=p.map((u,g)=>{let k=ae(u.querySelector(".button__coef-title")||u);return k?{el:u,odd:k,label:se(p.length,g,""),locked:!1}:null});l.length<2||l.some(u=>!u)||r.push(vt({scope:"list",title:l.length===3?"Исход":"Победитель",kind:l.length===3?"1x2":"12",outcomes:l,event:e,anchor:i,eventKey:e.key}))}}}return r}function dn(a){if(!a?.body)return null;let r=g=>/^\d{1,3}\s?%$/.test(g),i=j(a,"h4").map(g=>{let k=[...g.nextElementSibling?.children||[]],$=N(k[0]),S=N(k[k.length-1]);return r($)&&r(S)?{label:N(g),home:$.replace(/\s/g,""),away:S.replace(/\s/g,"")}:null}).filter(Boolean);if(!i.length)return null;let e=(a.body.innerText||a.body.textContent||"").replace(/\s+/g," "),f=[...e.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(g=>Number(g[1])),l=[...(e.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(g=>g[1].replace(/\s/g,""));return{names:N(a.querySelector("h3")).split(/\s+vs\s+/i).map(g=>g.trim()).filter(Boolean),rows:i,samples:f.slice(0,2),form:l.length>=2?{home:l[0],away:l[1]}:null}}function un(a,r,i){if(!a||a.names.length<2)return a;let e=_t(a.names[0],r)+_t(a.names[1],i);return _t(a.names[0],i)+_t(a.names[1],r)<=e?a:{names:[a.names[1],a.names[0]],rows:a.rows.map(p=>({label:p.label,home:p.away,away:p.home})),samples:a.samples.slice().reverse(),form:a.form?{home:a.form.away,away:a.form.home}:null}}function pn(a){let r=a.querySelector("iframe.stats__iframe");if(!r)return null;try{return dn(r.contentDocument)}catch{return null}}function fn(a){let r=["one","two"].map(p=>a.querySelector(`.event-live-center__team-widget--${p}`));if(!r[0]||!r[1])return null;let i=p=>{let l=p;try{l=p.querySelector("iframe")?.contentDocument?.body||p}catch{l=p}let u=j(l,'[class*="player"]').filter(k=>!j(k,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(k.className)),g=[];for(let k of u){let $=N(k).split(" ").filter(Boolean),S=$.find(_=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(_)&&/[A-Za-z]/.test(_));if(!S||g.some(_=>_.nick===S))continue;let z=$.filter(_=>/^\d{1,3}$/.test(_)).map(Number);g.push({nick:S,numbers:z.slice(0,4)})}return g.slice(0,5)},e=i(r[0]),f=i(r[1]);return e.length<3||f.length<3?null:{home:e,away:f}}var ze={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:re,readMatch:ve,readEsportsWidget:fn,observeTargets(a){try{let r=a.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(a,r){if(re(a)==="match"){let f=ve(a,r)?.key||"";return[...rn(a,f),...sn(a,f),...ke(a)]}return ke(a)}};var Rt=(a,r)=>{try{return[...a.querySelectorAll(r)]}catch{return[]}};function $e(a,r){let i=[a];if(r.shadow)for(let e of Rt(a,r.shadow))e.shadowRoot&&i.push(e.shadowRoot);return i}var jt=a=>(a.defaultView?.innerWidth||0)>0,mn='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function hn(a){let r=[],i=a.ownerDocument.createTreeWalker(a,4);for(;i.nextNode();){let e=i.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(e&&r.push(...e.split(" ")),r.length>5)return null}return r}function gn(a,r){if(r.label){let i=a.querySelector(r.label),e=i?i.textContent.replace(/[ \s]+/g," ").trim():"";if(e&&!/^\d{1,3}[.,]\d{1,3}$/.test(e))return e}if(r.cell&&r.headerRow){let i=a.closest(r.cell),e=i?.parentElement,f=e?.parentElement?.querySelector(r.headerRow);if(f&&f!==e){let p=[...e.children].indexOf(i),l=f.children[p]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(l)return l.charAt(0).toUpperCase()+l.slice(1).toLowerCase()}}return""}function bn(a,r){if(!r.cell||!r.lineCell)return"";let i=a.closest(r.cell);for(;i&&(i=i.previousElementSibling);){if(!i.matches?.(r.lineCell))continue;let e=i.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return e?e[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function xn(a,r){if(a.disabled||a.hasAttribute?.("disabled"))return null;let i=r.value&&a.querySelector(r.value)||a,e=hn(i);if(!e||!e.length||e.join(" ").length>28)return null;let f=e[e.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(f))return null;let p=mt(f);if(!p||p>500||e.slice(0,-1).some(u=>/^\d{1,3}[.,]\d{1,3}$/.test(u)))return null;let l=e.slice(0,-1).join(" ");return!r.outcome&&/[+−]|^-/.test(l)?null:{odd:p,label:l}}function yn(a,r){let i=[],e=new Set,f=$e(a,r).flatMap(p=>Rt(p,r.outcome||mn));for(let p of f){if(e.has(p)||r.skip&&p.closest(r.skip)||p.closest("#lz-root, #lz-marks"))continue;let l=xn(p,r);if(l){if(!r.outcome&&jt(a)){let u=p.getBoundingClientRect();if(u.width<26||u.width>320||u.height<16||u.height>90)continue}e.add(p),i.push({el:p,odd:l.odd,label:l.label||gn(p,r),line:bn(p,r),locked:!1})}}return r.outcome?i:i.filter(p=>!i.some(l=>l.el!==p.el&&l.el.contains(p.el)))}function vn(a,r,i){if(r.row)return a.closest(r.row);let e=a.parentElement;for(let f=0;f<6&&e&&e!==e.ownerDocument.body;f+=1){let p=i(e);if(p>=2&&p<=16){if(!jt(e.ownerDocument))return e;let l=e.getBoundingClientRect();if(l.height<=130&&l.width>=120)return e}if(p>16)break;e=e.parentElement}return null}var Me=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function kn(a,r){let i=r.length,e=a;for(let $=0;$<7;$+=1){let S=e.parentElement;if(!S||r.some(F=>!S.contains(F.el))||S.querySelectorAll("*").length>400||[...S.querySelectorAll('button, a, td, [role="button"]')].filter(F=>!r.some(C=>C.el===F||C.el.contains(F)||F.contains(C.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(N(F))).length>i)break;e=S}let f=r[0].el,p=[],l=e.ownerDocument.createTreeWalker(e,4);for(;l.nextNode();){let $=l.currentNode;if(f.contains($))break;let S=$.textContent.replace(/[ \s]+/g," ").trim();S.length<2||S.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(S)||/\d{1,2}:\d{2}|^\d|['′]$/.test(S)||Me.test(S)||p.push(S)}let u=p.slice(-2),g=p.map($=>$.split(/\s+[—–-]\s+/)).filter($=>$.length===2).pop();if(g&&(u=g),u.length<2||u[0]===u[1])return null;let k=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:yt(u[0],u[1]),home:u[0],away:u[1],href:k,live:!1,time:"",league:"",card:e}}function wn(a,r,i){if(!r.names)return kn(a,i);let e=r.event&&a.closest(r.event)||a,f=[...new Set(Rt(e,r.names).map(u=>N(u)).filter(Boolean))],p=f;if(f.length===1&&(p=f[0].split(/\s+[—–-]\s+/)),p.length<2||!p[0]||!p[1])return null;let l=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:yt(p[0],p[1]),home:p[0],away:p[1],href:l,live:!1,time:"",league:"",card:e}}function zn(a){let i=String(a.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!i)return null;let e=[i[1].trim(),i[2].trim()];return e.some(f=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(f))?null:e}function Se(a,r={}){function i(z,_){return r.matchUrl&&r.matchUrl.test(_?.pathname||"")||r.matchPage&&z.querySelector(r.matchPage)?"match":"list"}function e(z){let _=z.defaultView;if(!_||!jt(z))return[];let F=[];for(let C of z.querySelectorAll("h1, h2, h3, div, span, p, a")){if(C.children.length)continue;let q=N(C);if(q.length<3||q.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(q)||/\d{1,2}[:.]\d{2}/.test(q)||Me.test(q))continue;let R=C.getBoundingClientRect();if(!(R.top<60||R.top>450||R.width<30||parseFloat(_.getComputedStyle(C).fontSize)<15)&&(F.includes(q)||F.push(q),F.length===2))break}return F}function f(z,_){if(i(z,_)!=="match")return null;let F=r.matchNames?Rt(z,r.matchNames).map(q=>N(q)).filter(Boolean):[];if(F.length===1&&(F=F[0].split(/\s+[—–-]\s+/)),F.length<2&&(F=zn(z)||[]),F.length<2&&(F=e(z)),F.length<2)return null;let C=r.matchLeague?N(z.querySelector(r.matchLeague)):"";return{book:a.name,id:(String(_?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:yt(F[0],F[1]),home:F[0],away:F[1],sport:zt(_?.pathname,C,z.title,N(z.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:C,start:"",live:/(^|\/)live(\/|$)/i.test(_?.pathname||"")?!0:null,form:{home:"",away:""},url:_?.href||""}}function p(z,_){return!z||!_?"":_.startsWith("attr:")?String(z.getAttribute(_.slice(5))||"").trim():N(z.querySelector(_))}function l(z,_){if(!jt(_))return[z];let F=z.map(q=>{let R=q.el.getBoundingClientRect();return{cell:q,top:R.top,left:R.left}}).sort((q,R)=>Math.abs(q.top-R.top)>8?q.top-R.top:q.left-R.left),C=[];for(let q of F){let R=C[C.length-1];R&&Math.abs(R.top-q.top)<=8?R.cells.push(q.cell):C.push({top:q.top,cells:[q.cell]})}return C.map(q=>q.cells)}let u=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],g=z=>(u.find(([_])=>_.test(z.join("/").toLowerCase()))||[])[1]||"other";function k(z,_){let F=i(z,_),C=F==="match"&&r.match?{...r,...r.match}:r;return $(z,_,F,C)}function $(z,_,F,C){let q=yn(z,C);if(q.length<2)return[];let R=new Set(q.map(L=>L.el)),dt=L=>{let M=0;for(let A of R)L.contains(A)&&(M+=1);return M},D=new Map;for(let L of q){let M=vn(L.el,C,dt);M&&(D.has(M)||D.set(M,[]),D.get(M).push(L))}let ut=F==="match"?f(z,_):null,I=[];for(let[L,M]of D){let A=F==="match"?null:wn(L,C,M),B=C.group?L.closest(C.group):null,E=p(B,C.groupTitle),Q=p(B,C.groupPeriod),tt=C.visualRows?l(M,z):[M],rt=0;for(let at of tt)for(let st of me(at).sets){let H=rt===0,Z=st.length,it=Z===3?["П1","Х","П2"]:["1","2"],xt=st.map((J,et)=>({...J,label:J.label||it[et]||String(et+1)})),pt=H&&Z===3?"Исход":H?"Победитель":`Рынок ${rt+1}`,ot=H?Z===3?"1x2":"12":"other";E&&(pt=E,ot=Tt(E,Z),ot==="other"&&(ot=g(xt.map(J=>J.label)))),Z===3&&xt.every(J=>/\sили\s/i.test(J.label))&&(ot="dc"),I.push(vt({scope:F==="match"?"board":"list",title:pt,period:Q,line:st[0].line&&st.every(J=>J.line===st[0].line)?st[0].line:"",kind:ot,outcomes:xt,event:A,anchor:L,eventKey:A?.key||ut?.key||`row${I.length}`})),rt+=1}}return I}let S=z=>$e(z,r).slice(1);return{id:a.id,name:a.name,hosts:a.hosts,generic:!0,pageType:i,readMatch:f,collect:k,observeTargets:S,readEsportsWidget:()=>null}}var _e={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},Te={fonbet:_e,pari:_e,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function Ne(a){let r=de(a);return r?r.id==="winline"?{adapter:ze,book:r}:{adapter:Se(r,Te[r.id]||{}),book:r}:null}var It=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var Le=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(a,r,...i){let[e,...f]=a.split("."),p=document.createElement(e||"div");f.length&&(p.className=f.join(" "));for(let[l,u]of Object.entries(r||{}))if(!(u==null||u===!1))if(l==="class")p.className=[p.className,u].filter(Boolean).join(" ");else if(l==="style")p.style.cssText=u;else if(l==="text")p.textContent=u;else{if(l==="html")throw new Error("html запрещён");l.startsWith("data-")||l.startsWith("aria-")||l==="role"||l==="title"||l==="type"||l==="href"||l==="target"||l==="rel"||l==="placeholder"||l==="value"||l==="for"||l==="name"||l==="maxlength"||l==="autocomplete"||l==="spellcheck"||l==="tabindex"?p.setAttribute(l,u===!0?"":String(u)):l==="disabled"||l==="hidden"||l==="checked"||l==="selected"?p[l]=!!u:p[l]=u}return Ae(p,i),p}function Ae(a,r){for(let i of r)i==null||i===!1||(Array.isArray(i)?Ae(a,i):a.appendChild(i instanceof Node?i:document.createTextNode(String(i))))}var Ce="http://www.w3.org/2000/svg";function G(a,r=16){let i=document.createElementNS(Ce,"svg");i.setAttribute("viewBox","0 0 20 20"),i.setAttribute("width",r),i.setAttribute("height",r),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.7"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("aria-hidden","true");for(let e of Sn[a]||[]){let f=document.createElementNS(Ce,"path");f.setAttribute("d",e),i.appendChild(f)}return i}var Sn={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function Oe(){let a=document.createElement("div");a.id="lz-marks",a.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=a.attachShadow({mode:"open"});r.appendChild(t("style",{text:It+Le}));let i=t("div.layer"),e=t("div.tip");r.append(i,e);let f=new Map,p=new Set,l=0,u=null,g=null,k=new IntersectionObserver(L=>{for(let M of L)M.isIntersecting?p.add(M.target):(p.delete(M.target),f.get(M.target)?.node.classList.remove("on"));S()},{rootMargin:"120px"});function $(){a.isConnected||document.documentElement.appendChild(a)}function S(){l||(l=requestAnimationFrame(()=>{l=0,F()}))}let z=(L,M)=>{for(let A=M;A;A=A.parentNode||A.host)if(A===L)return!0;return!1};function _(L,M){let A=M.left+M.width/2,B=M.top+M.height/2;if(A<0||B<0||A>window.innerWidth||B>window.innerHeight)return!1;let E=document.elementFromPoint(A,B);for(;E?.shadowRoot?.elementFromPoint;){let Q=E.shadowRoot.elementFromPoint(A,B);if(!Q||Q===E)break;E=Q}return!!E&&E!==L&&!z(L,E)&&!z(E,L)}function F(){for(let L of p){let M=f.get(L);if(!M)continue;if(!L.isConnected){C(L);continue}let A=L.getBoundingClientRect();if(A.width<6||A.height<6||_(L,A)){M.node.classList.remove("on");continue}let B=Math.round(A.left),E=Math.round(A.top),Q=Math.round(A.width),tt=Math.round(A.height);(M.x!==B||M.y!==E)&&(M.node.style.transform=`translate3d(${B}px, ${E}px, 0)`,M.x=B,M.y=E),(M.w!==Q||M.h!==tt)&&(M.node.style.width=`${Q}px`,M.node.style.height=`${tt}px`,M.w=Q,M.h=tt,M.node.classList.toggle("small",tt<26)),M.node.classList.add("on")}u&&R()}function C(L){let M=f.get(L);M&&(k.unobserve(L),p.delete(L),M.node.remove(),f.delete(L))}function q(L){$();let M=new Map;for(let A of L)A.el?.isConnected&&M.set(A.el,A);for(let A of[...f.keys()])M.has(A)||C(A);for(let[A,B]of M){let E=f.get(A);if(!E){let tt=t("div.mark"),rt=parseFloat(getComputedStyle(A).borderTopLeftRadius);tt.style.borderRadius=`${Number.isFinite(rt)&&rt>0?Math.min(rt,16):6}px`;let at=t("span.chip");tt.appendChild(at),i.appendChild(tt),E={node:tt,chip:at,sig:""},f.set(A,E),k.observe(A)}let Q=`${B.frame?1:0}|${B.selected?1:0}|${B.tone||""}|${B.chip||""}`;Q!==E.sig&&(E.sig=Q,E.node.classList.toggle("frame",!!B.frame),E.node.classList.toggle("selected",!!B.selected),E.node.classList.toggle("pos",B.tone==="pos"&&!!B.frame),E.chip.hidden=!B.chip,E.chip.textContent=B.chip||"",E.chip.className=`chip${B.tone&&B.tone!=="accent"?" "+B.tone:""}`)}S()}function R(){if(!u?.isConnected)return D();let L=u.getBoundingClientRect(),M=264,A=e.offsetHeight||140,B=L.left+L.width/2-M/2;B=Math.max(8,Math.min(B,window.innerWidth-M-8)),g&&B+M>g.left-8&&B<g.right&&(B=Math.max(8,g.left-M-10));let E=L.bottom+10;E+A>window.innerHeight-8&&(E=L.top-A-10),E<8&&(E=8),e.style.transform=`translate3d(${Math.round(B)}px, ${Math.round(E)}px, 0)`}function dt(L,M){$(),u=L,e.replaceChildren(M),R(),e.classList.add("on")}function D(){u=null,e.classList.remove("on")}function ut(L){g=L}function I(L){a.setAttribute("data-theme",L)}return window.addEventListener("scroll",S,{capture:!0,passive:!0}),window.addEventListener("resize",S,{passive:!0}),setInterval(()=>{f.size&&!document.hidden&&S()},700),{set:q,schedule:S,showTip:dt,hideTip:D,setTheme:I,setAvoid:ut,get tipTarget(){return u},count:()=>f.size}}var Fe=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var Kt=a=>Math.min(.999,Math.max(.001,a));function ie(a,r,i=0,e=0){let f=Math.ceil(r/2),p=new Map,l=(u,g)=>{if(u>=f)return 1;if(g>=f)return 0;let k=u*16+g;return p.has(k)||p.set(k,a*l(u+1,g)+(1-a)*l(u,g+1)),p.get(k)};return l(i,e)}function Zt(a,r){let i=.001,e=.999;for(let f=0;f<50;f++){let p=(i+e)/2;a(p)<r?i=p:e=p}return(i+e)/2}function Tn(a,r){let i=Kt(a);return Math.ceil(r/2)<=1?i:Zt(e=>ie(e,r),i)}function Wt(a,r,i,e=new Map){if(r>=4)return[1,0];if(i>=4)return[0,0];if(r===3&&i===3)return[0,1];let f=r*8+i;if(!e.has(f)){let[p,l]=Wt(a,r+1,i,e),[u,g]=Wt(a,r,i+1,e);e.set(f,[a*p+(1-a)*u,a*l+(1-a)*g])}return e.get(f)}function Ee(a){let[r,i]=Wt(a,0,0);return r/(1-i)}function Dt(a,r,i){if(r=Math.max(0,Math.floor(r)),i=Math.max(0,Math.floor(i)),Math.min(r,i)>=12){let p=Math.floor((Math.min(r,i)-12)/3),l=r-12-3*p,u=i-12-3*p,[g,k]=Wt(a,l,u);return g+k*Ee(a)}let e=new Map,f=(p,l)=>{if(p>=13)return 1;if(l>=13)return 0;if(p===12&&l===12)return Ee(a);let u=p*32+l;return e.has(u)||e.set(u,a*f(p+1,l)+(1-a)*f(p,l+1)),e.get(u)};return f(r,i)}function Nn(a){return Zt(r=>Dt(r,0,0),Kt(a))}var Ln=24,Vt=Array.from({length:101},(a,r)=>(r+.5)/101),qe=null;function Be(a,r){let i=Vt.map(l=>(a-1)*Math.log(l)+(r-1)*Math.log(1-l)),e=Math.max(...i),f=i.map(l=>Math.exp(l-e)),p=f.reduce((l,u)=>l+u,0);return f.map(l=>l/p)}function Pe(a,r,i=0,e=0){if(!Number.isFinite(r))return Dt(a,i,e);let f=Be(a*r+i,(1-a)*r+e);return!i&&!e?(qe||=Vt.map(p=>Dt(p,0,0)),f.reduce((p,l,u)=>p+l*qe[u],0)):f.reduce((p,l,u)=>p+l*Dt(Vt[u],i,e),0)}function Cn(a,r){return Number.isFinite(r)?Zt(i=>Pe(i,r),Kt(a)):Nn(a)}var An={cs:8,dota:1/0};function je(a,r,i,e=0,f=0){return Number.isFinite(r)?Be(a*r+e,(1-a)*r+f).reduce((l,u,g)=>l+u*ie(Vt[g],i,e,f),0):ie(a,i,e,f)}function On(a,r,i){return Number.isFinite(i)?Zt(e=>je(e,i,r),Kt(a)):Tn(a,r)}function Fn(a,r){let i=Math.max(a,r),e=Math.min(a,r);return e<12?i>=13:i-12-3*Math.floor((e-12)/3)>=4}function Re({pre:a,bo:r=3,maps:i=[0,0],rounds:e=null,game:f="cs",kappa:p=Ln,kappaMap:l=An[f]??1/0}){let u=Math.ceil(r/2),[g,k]=(i||[0,0]).map(q=>Math.max(0,Number(q)||0));if(g>=u)return{p:1,map:null};if(k>=u)return{p:0,map:null};let $=On(a,r,l),S=(q,R)=>je($,l,r,q,R),[z,_]=Array.isArray(e)&&e.length===2?e.map(Number):[NaN,NaN];if(!Number.isFinite(z)||!Number.isFinite(_)||z===0&&_===0||Fn(z,_))return{p:S(g,k),map:null};let F=Number.isFinite(l)?($*l+g)/(l+g+k):$,C=Pe(Cn(F,p),p,z,_);return{p:C*S(g+1,k)+(1-C)*S(g,k+1),map:C}}var K=(a,r=0)=>ht(a,r),kt=a=>`${a>0?"+":a<0?"−":""}${Math.abs(a).toFixed(1)}`;function Ie({bus:a,actions:r,brand:i}){let e=document.createElement("div");e.id=a.rootId,e.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let f=e.attachShadow({mode:"open"});f.appendChild(t("style",{text:It+Fe}));let p=t("span.dot"),l=t("button.fab",{type:"button","data-act":"toggle",title:`${i.name}: открыть панель`,"aria-label":`${i.name}: открыть панель`},G("lens",18),t("span",{text:i.name}),p),u=t("div.tabs",{role:"tablist"}),g=t("div.body"),k=t("div.foot"),$=t("small"),S=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),z=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),_=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},G("gear")),F=t("div.head",{},t("div.brand",{},t("span.logo",{},G("lens",15)),t("span",{text:i.name}),$),t("span.grow"),z,S,_,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},G("close"))),C=t("section.panel",{hidden:!0,role:"dialog","aria-label":i.name},F,u,g,k);f.append(l,C);let q=()=>{e.isConnected||document.documentElement.appendChild(e)};q(),new MutationObserver(q).observe(document.documentElement,{childList:!0});let R="",dt=null,D=new Map,ut=o=>{for(let n of o.composedPath()){if(n===e)break;if(n?.dataset?.act)return n}return null},I=null;a.on("ui:pointerdown",o=>{if(o.button!==0)return;let n=o.composedPath(),c=n.includes(l),h=n.includes(F)&&!n.some(b=>b?.dataset?.act);if(!c&&!h)return;let y=c?l:C,x=y.getBoundingClientRect();I={target:y,key:c?"fab":"panel",sx:o.clientX,sy:o.clientY,ox:x.left,oy:x.top,moved:!1},a.setDragging(!0)}),a.on("drag:move",o=>{if(!I)return;let n=o.clientX-I.sx,c=o.clientY-I.sy;!I.moved&&Math.hypot(n,c)<5||(I.moved=!0,I.target.classList.add("dragging"),M(I.target,I.ox+n,I.oy+c))}),a.on("drag:end",()=>{if(I){if(a.setDragging(!1),I.target.classList.remove("dragging"),I.moved){let o=I.target.getBoundingClientRect();r.savePosition(I.key,{left:o.left,top:o.top}),L=!0,setTimeout(()=>{L=!1},60)}I=null}});let L=!1;function M(o,n,c){let h=o.offsetWidth||120,y=o.offsetHeight||40,x=Math.max(6,Math.min(n,window.innerWidth-h-6)),b=Math.max(6,Math.min(c,window.innerHeight-Math.min(y,60)-6));o.style.left=`${Math.round(x)}px`,o.style.top=`${Math.round(b)}px`,o.style.right="auto"}a.on("ui:click",o=>{if(L)return;let n=ut(o);if(!n||n.disabled)return;o.preventDefault();let c=n.dataset.act;if(c==="toggle")return Mt();if(c==="close")return ct();let h=r[c];h&&h(n.dataset.arg,n,f)}),a.on("ui:keydown",o=>{if(o.key==="Escape"&&ct(),o.key==="Enter"){let n=o.composedPath()[0];n?.dataset?.enter&&r[n.dataset.enter]?.(n.value,n,f)}});let A=(o,n)=>t("span.form",{},[...String(o||"")].slice(0,5).map(c=>t(`i${c==="В"?".w":c==="П"?".l":""}`,{text:c,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[c]||""})),n);function B(o){let n=o.live,c=n?t("div.center",{},n.score?.length===2?t("span.score",{text:`${n.score[0]} : ${n.score[1]}`}):null,t("span.badge.live",{text:n.state||"Лайв"})):t("div.center",{},t("span",{text:o.start||"до матча"})),h=n?.periods?.length?t("div.periods",{text:n.periods.map(x=>x.raw?`${x.label} ${x.raw}`:`${/^\d+$/.test(x.label)?`${x.label}-й отрезок`:x.label} ${x.home}:${x.away}`).join(" · ")}):null,y=n?.extras?.length?t("div.periods",{text:n.extras.map(x=>`${x.kind} ${x.home}:${x.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:o.league||o.sportName||"",title:o.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:o.home,title:o.home}),o.form?.home?A(o.form.home):null),c,t("div.team.away",{},t("b",{text:o.away,title:o.away}),o.form?.away?A(o.form.away):null)),h,y)}function E(o){let n=o.rows.some(c=>Number.isFinite(c.model));return t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),Number.isFinite(o.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(o.margin,1)}`}):null),o.rows.map(c=>{let h=n&&Number.isFinite(c.model)?(c.model-c.fair)*100:null;return t("div.prob",{},t("span.name",{text:c.name,title:c.name}),t("span.odd",{text:V(c.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((c.fair||0)*100)}%`}),Number.isFinite(c.model)?t("u",{style:`left:${Math.round(c.model*100)}%`}):null),t("span.pct",{},K(n&&Number.isFinite(c.model)?c.model:c.fair),h!=null&&Math.abs(h)>=.05?t(`small${h>0?".pos":".neg"}`,{text:`${kt(h)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),n?t("span.model",{text:"оценка модели"}):null))}function Q(o){let n=o.analysis;if(n.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},n.steps.map((b,v)=>t(`div.step${v===n.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:b})))));if(n.status==="error")return t("div.card",{},t("div.note.warn",{},G("alert"),t("span",{text:n.error})),n.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},G("gear"),"Открыть настройки")):null);if(n.status!=="done"||!n.result)return null;let c=n.result,h={home:o.match?.home,away:o.match?.away,draw:"ничья"}[c.lean],y=c.proposed?.lean&&c.proposed.lean!=="none"&&c.lean==="none"?{name:{home:o.match?.home,away:o.match?.away,draw:"ничью"}[c.proposed.lean],by:Math.abs(c.proposed.shift[c.proposed.lean]||0)}:null,x=new Map((c.facts||[]).map(b=>[b.id,b]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${c.confidence||"низкая"}`})),t("div.verdict",{text:h?`Данные сдвигают оценку в сторону: ${h}`:y?`Данные слегка склоняют в сторону: ${y.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),y?t("div.note",{style:"margin-bottom:10px"},G("info"),t("span",{text:`Модель предложила сдвиг на ${y.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,c.summary?t("p.summary",{text:c.summary}):null,c.factors?.length?t("ul.factors",{},c.factors.map(b=>t(`li.factor${b.side==="home"?".home":b.side==="away"?".away":""}`,{},t("div",{},t("p",{text:b.text}),t("div.src",{},(b.facts||[]).map(v=>x.get(v)).filter(Boolean).map(v=>t("span.tag",{text:`${v.id} · ${v.source}`,title:v.text}))))))):null,c.risks?.length?t("div.note",{style:"margin-top:10px"},G("info"),t("span",{text:`Что может сломать вывод: ${c.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:D.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${c.facts?.length||0})`}),t("ul.facts",{},(c.facts||[]).map(b=>t("li",{},t("b",{text:b.id}),t("span",{},b.text," ",t("em",{text:`— ${b.source}`})))))),tt(c.research),t("div.hint",{style:"margin-top:8px",text:c.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function tt(o){return o?o.skipped==="plan"?t("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):o.sources?.length?t("div.hint",{style:"margin-top:8px"},`${o.note} Прочитано: `,o.sources.map((n,c)=>[c?", ":"",t("a",{href:n.url,target:"_blank",rel:"noopener",text:n.domain})])):o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null:null}function rt(o){let n=o.compare?.consensus||o.analysis?.result?.consensus||o.consensus;if(!n?.consensus||!o.line?.rows?.length)return null;let c=n.consensus.length===2&&o.line.rows.length===3;if(!c&&o.line.rows.length!==n.consensus.length)return null;let h=c?o.line.overtime:null,y=h?h.rows:c?[o.line.rows[0],o.line.rows[2]].map(b=>({...b,odd:null,fair:null})):o.line.rows,x=n.updated?new Date(n.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:c?"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${n.count} контор`})),y.map((b,v)=>{let w=n.consensus[v],O=b.odd?b.odd*w-1:0,W=Number.isFinite(b.fair)?(b.fair-w)*100:0;return t("div.prob",{},t("span.name",{text:b.name,title:b.name}),t("span.odd",{text:V(1/w),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(w*100)}%`}),t("u",{style:`left:${Math.round((b.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},K(w),O>.005?t("small.pos",{text:`кэф выше рынка ${kt(O*100)}%`}):Math.abs(W)>=2?t(`small${W>0?".neg":""}`,{text:`${kt(W)} п.п. к рынку`,title:W>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),c&&!h?null:t("span.model",{text:h?`шанс по рынку «${h.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${c?h?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${n.pinnacle?`Pinnacle ${n.pinnacle.map(V).join(" / ")}. `:""}${n.betfair?`Betfair ${n.betfair.map(V).join(" / ")}. `:""}Цены ${n.count} контор без маржи${x?`, обновлено в ${x}`:""}${n.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let at=new Map;function st(o,n){let c=o.match?.live;if(!c||!["cs","dota"].includes(n.game)||c.score?.length!==2)return null;let h=c.score.map(Number),y=Number(n.bo)||3;if(h.some(v=>!Number.isFinite(v)||v<0)||Math.max(...h)>=Math.ceil(y/2))return null;let x=n.game==="cs"&&c.rounds?.length===2&&c.rounds.every(v=>/^[0-9]{1,2}$/.test(String(v)))?c.rounds.map(Number):null,b=`${n.p1}|${y}|${h}|${x}`;return at.has(b)||(at.size>50&&at.clear(),at.set(b,{...Re({pre:n.p1,bo:y,maps:h,rounds:x,game:n.game}),bo:y,maps:h,rounds:x})),at.get(b)}function H(o){let n=o.compare?.model||o.analysis?.result?.model||o.model;if(!n?.p1||!o.line?.rows?.length)return null;let c=o.line.rows.length===3&&n.overtime;if(!c&&o.line.rows.length!==2)return null;let h=c?o.line.overtime:null,y=h?h.rows:c?[o.line.rows[0],o.line.rows[2]].map(P=>({...P,fair:null})):o.line.rows,x=st(o,n),b=x?[x.p,1-x.p]:[n.p1,n.p2],v=n.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${n.samples} матчей у менее опытного игрока)`:n.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${n.samples} игр у менее опытной команды)`:n.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${n.samples} ${J(n.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${n.samples} ${J(n.samples,"карта","карты","карт")} у менее опытной команды)`,w=n.backtest,O=(w?.calibration||[]).filter(P=>[60,70,80].includes(P.threshold)),W=w?.labels?.[n.confidence],T=(W?`С подписью «${n.confidence}» на проверке сбывалось ${K(W.hit/100,1)} (${W.n} ${J(W.n,"матч","матча","матчей")}). `:"")+(O.length?`На проверке ${w.test} сыгранных матчей: ${O.map(P=>`при уверенности ≥${P.threshold}% сбывалось ${P.hit}%`).join(", ")}`:w?`На проверке ${w.test} матчей угадано ${Math.round(w.acc*100)}%`:"Точность ещё измеряется");return t("div.card",{},t("div.kicker",{},t("span",{text:x?`Модель по счёту · bo${x.bo}`:c?"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:x?`до матча: ${n.confidence}`:`уверенность: ${n.confidence}`})),y.map((P,U)=>{let X=b[U],nt=Number.isFinite(P.fair)?(X-P.fair)*100:0;return t("div.prob",{},t("span.name",{text:P.name,title:P.name}),t("span.odd",{text:V(1/X),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(X*100)}%`}),t("u",{style:`left:${Math.round((P.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},K(X),Math.abs(nt)>=3?t(`small${nt>0?".pos":".neg"}`,{text:`${kt(nt)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:x?"шанс серии по счёту":"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),x?t("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${x.maps.join(":")}${x.rounds?`, на карте ${x.rounds.join(":")} — шанс текущей карты ${K(x.map??.5)}`:""}. До матча модель давала ${K(n.p1)} / ${K(n.p2)}.`}):null,n.factors?.length?t("ul.facts",{style:"margin-top:8px"},n.factors.slice(0,4).map(P=>t("li",{},t("span",{text:P})))):null,t("div.hint",{style:"margin-top:8px",text:x?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${n.game==="cs"?" и раунды":""} уточняют силу команд. ${n.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${v}. ${T}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function Z(o,n,c,h){let y=o.bookLines;if(!y)return null;let x=v=>v>0?`+${v}`:`${v}`,b=(v,w,O,W)=>t("li",{},t("span",{text:`${v}: Fonbet ${w.map(V).join(" / ")}, честно ${O.map(T=>T?V(T):"—").join(" / ")}`}),h&&Math.abs(W)>=5?t(`small${W>0?".pos":".neg"}`,{text:` ${kt(W)} п.п. к первой стороне`}):null);return t("ul.facts",{style:"margin-top:8px"},y.handicap?b(`Фора ${n} ${x(y.handicap.line)} / ${c} ${x(-y.handicap.line)}`,y.handicap.odds,y.handicap.fair,y.handicap.gap):null,y.total?b(`Тотал ${y.total.line} больше / меньше`,y.total.odds,y.total.fair,y.total.gap):null)}function it(o){let n=o.live;if(!n)return null;if(n.error)return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"})),t("div.hint",{text:n.error}));let[c,h]=n.names,y=T=>T?V(T):"—",x=n.book&&(n.prior.source==="line"||n.prior.source==="model"),b=n.left>0?`${n.period>n.format.periods?"ОТ":`${n.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(n.left))} мин`:"конец игры",v=(T,P,U,X,nt,te)=>P.length?t("details",{"data-key":`live-${T}`,open:D.get(`live-${T}`)||!1},t("summary",{text:T}),t("ul.facts",{},P.map(qt=>t("li",{},t("span",{text:`${nt(qt)} — ${y(qt[U])} · ${te(qt)} — ${y(qt[X])}`}))))):null,w=T=>T>0?`+${T}`:`${T}`,O=n.quarter,W=O&&O.left>0?`${O.index}-я четверть (${O.score.join(":")}, осталось ≈${Math.max(1,Math.round(O.left))} мин): ${c} ${y(O.probs[0]?1/O.probs[0]:null)} · ничья ${y(O.draw?1/O.draw:null)} · ${h} ${y(O.probs[1]?1/O.probs[1]:null)}; разница ${O.expMargin>=0?c:h} ${Math.abs(O.expMargin).toFixed(1)}, тотал четверти ≈${O.projTotal}.`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${n.score.join(":")} · ${b}`})),n.names.map((T,P)=>{let U=n.probs[P],X=n.book?n.book[P]:null,nt=x&&Number.isFinite(X)?(U-X)*100:0;return t("div.prob",{},t("span.name",{text:T,title:T}),t("span.odd",{text:V(1/U),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(U*100)}%`}),Number.isFinite(X)?t("u",{style:`left:${Math.round(X*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(U),Math.abs(nt)>=3?t(`small${nt>0?".pos":".neg"}`,{text:`${kt(nt)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (с ОТ)"}),n.book?t("span.model",{text:"шанс по цене этой конторы"}):null),Z(n,c,h,x),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Ожидаемая итоговая разница: ${n.expMargin>=0?c:h} ${Math.abs(n.expMargin).toFixed(1)} (разброс ±${n.sd}). Тотал ≈${n.projTotal} (±${n.sdTotal}).`})),W?t("li",{},t("span",{text:W})):null),v("Фора — честные кэфы",n.handicap,"home","away",T=>`${c} ${w(T.line)}`,T=>`${h} ${w(-T.line)}`),v("Тотал матча — честные кэфы",n.total,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),v("Тотал четверти — честные кэфы",n.quarterTotal,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),t("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${n.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${n.prior.note}.${x?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function xt(o){let c=((o.compare?.model||o.analysis?.result?.model||o.model)?.profiles||[]).filter(h=>h?.lines?.length);return c.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Профили"}),t("span.badge",{text:"модель Линзы"})),c.map((h,y)=>t("details",{"data-key":`profile-${y}`,open:D.get(`profile-${y}`)??y===0},t("summary",{text:h.name}),t("ul.facts",{},h.lines.map(x=>t("li",{},t("span",{text:x})))))),t("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function pt(o){let n=o.facts;if(!n?.facts?.length)return null;let c=n.facts.filter(b=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(b.text)),h=n.facts.filter(b=>!c.includes(b)&&/состав|стартов/i.test(b.text)),y=n.facts.filter(b=>!c.includes(b)&&!h.includes(b)),x=(b,v,w)=>v.length?t("details",{"data-key":`facts-${b}`,open:w||D.get(`facts-${b}`)||!1},t("summary",{text:`${b} (${v.length})`}),t("ul.facts",{},v.map(O=>t("li",{},t("span",{text:O.text}))))):null;return t("div.card",{},t("div.kicker",{},t("span",{text:"Составы, травмы, форма"}),t("span.badge",{text:n.source||n.facts[0].source||"источник"})),x("Травмы и отсутствующие",c,!0),x("Составы",h,!0),x("Форма, таблица, очные встречи",y,!c.length&&!h.length),t("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",n.url?t("a",{href:n.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let ot=o=>`${Math.round(o).toLocaleString("ru-RU")} ₽`,J=(o,n,c,h)=>{let y=o%100,x=o%10;return y>10&&y<20?h:x===1?n:x>=2&&x<=4?c:h},et=o=>(o.erid?["Реклама",o.legal,`erid ${o.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",o.legal].filter(Boolean).join(" · "))+" · 18+",lt=(o,n)=>t("a.btn.ghost.small",{href:o.go?`${o.go}?s=panel`:o.url,target:"_blank",rel:"noopener sponsored"},G("link",13),n||`Открыть у ${o.name}`),ft=o=>o.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":o.code,title:o.bonus||"Скопировать промокод"},`Промокод ${o.code}`):null;function Nt(o){let n=(o.partners||[]).filter(c=>c.url||c.code);return n.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:n.length===1?`Промокод ${n[0].name}`:"Промокоды контор"})),n.map(c=>t("div.partner",{},t("div.partner-text",{},t("b",{text:c.name}),c.bonus?t("span",{text:` — ${c.bonus}`}):null),t("div.partner-links",{},ft(c),c.url?lt(c):null),t("div.hint",{text:et(c)})))):null}function Lt(o,n={}){if(o.status==="idle")return null;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let c=o.labels||[];if(!o.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:o.note||"В открытых линиях этой пары нет."}));let h=c.map((T,P)=>Math.max(...o.rows.map(U=>U.odds[P]||0))),y=Object.fromEntries((n.partners||[]).map(T=>[T.id,T])),x=T=>T.book&&T.book!==n.bookId&&!T.sharp&&y[T.book]||null,b=n.stake||1e3,v=o.rows.find(T=>T.here)||o.rows[0],O=c.map((T,P)=>{let U=v?.odds?.[P],X=o.rows.filter(nt=>nt!==v&&!nt.sharp&&nt.odds[P]).sort((nt,te)=>te.odds[P]-nt.odds[P])[0];return!U||!X||X.odds[P]<=U?null:{label:T,row:X,odd:X.odds[P],mine:U,gain:(X.odds[P]-U)*b}}).filter(Boolean).sort((T,P)=>P.gain-T.gain)[0],W=o.rows.map(x).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),c.map(T=>t("th",{text:T}))),o.rows.map(T=>{let P=x(T);return t("tr",{},t("td.name",{title:T.sharp?"Цена с мирового рынка, для сравнения":""},T.name,P?t("div.partner-links",{},P.url?lt(P):null,ft(P)):null),T.odds.map((U,X)=>t(`td${U&&U===h[X]&&o.rows.length>1?".best":""}`,{text:U?V(U):"—"})))})),O&&O.gain>=1?t("div.gain",{},`На «${O.label}» у ${O.row.name} кэф ${V(O.odd)} против ${V(O.mine)} здесь: со ставки ${ot(b)} выигрыш больше на `,t("b",{text:ot(O.gain)}),"."):null,W.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(W.map(et))].join(" ")}):null,o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null)}function Xt(o){let n=[],c=(y,x,b)=>n.push(t("dt",{text:y}),t(`dd${b?"."+b:""}`,{text:x}));Number.isFinite(o.fair)?(c("Шанс по линии без маржи",K(o.fair,1)),c("Кэф без маржи конторы",V(o.fairOdd)),c("Маржа конторы в этом рынке",K(o.margin,1))):c("Заложено в кэфе (с маржой)",K(1/o.odd,1)),Number.isFinite(o.model)&&(c("Оценка модели",K(o.model,1)),c("Ожидание на рубль по модели",`${kt(o.ev*100)}%`,o.ev>.005?"pos":o.ev<-.005?"neg":"")),o.best&&c(`Лучшая цена: ${o.best.name}`,V(o.best.odd),o.best.odd>o.odd?"pos":"");let h=o.best?.partner&&(o.best.partner.url||o.best.partner.code)?o.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:o.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},G("close",13))),t("div.pick-head",{},t("span.big",{text:V(o.odd)}),t("span.what",{text:o.label,title:o.label})),t("dl.kv",{},n),o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!o.canAdd,title:o.canAdd?"":"Нужен рынок с полным набором исходов"},G("plus",14),o.inExpress?"Уже в экспрессе":"В расчёт экспресса")),h?t("div.partner",{style:"margin-top:10px"},o.best.gain>=1?t("div.gain",{},`У ${h.name} этот кэф выше: со ставки ${ot(o.stake||1e3)} выигрыш больше на `,t("b",{text:ot(o.best.gain)}),"."):null,t("div.partner-links",{},h.url?lt(h):null,ft(h)),t("div.hint",{text:et(h)})):null)}function Ct(o){let n=(c,h)=>t("div",{style:"min-width:0"},t("b",{text:c,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),h.map(y=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:y.nick}),t("span",{style:"color:var(--lz-muted)",text:y.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},n(o.homeName,o.home),n(o.awayName,o.away)))}function At(o,n){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:n.home}),t("th",{text:n.away})),o.rows.map(c=>t("tr",{},t("td",{text:c.label}),t("td",{text:c.home}),t("td",{text:c.away})))),o.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${o.samples[0]} и ${o.samples[1]} карт.`}):null)}function Ot(o){let n=[];if(o.pick&&n.push(Xt({...o.pick,stake:o.stake})),!o.match)return n.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),n;n.push(B(o.match)),o.esports&&n.push(Ct(o.esports)),o.match.stats?.rows?.length&&n.push(At(o.match.stats,o.match)),o.line&&n.push(E(o.line));let c=rt(o);c&&n.push(c);let h=it(o);h&&n.push(h);let y=H(o);y&&n.push(y);let x=xt(o);x&&n.push(x);let b=pt(o);b&&n.push(b);let v=o.analysis.status==="loading";n.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:v},G("spark"),v?"Разбираю…":o.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:o.compare.status==="loading"},G("scale"),"Сравнить цены"))),o.quota&&n.push(t("div.hint.center-text",{text:o.quota}));let w=Nt(o);w&&n.push(w);let O=Q(o);O&&n.push(O);let W=Lt(o.compare,o);return W&&n.push(W),n}function Gt(o){let n=o.margins;if(!n)return null;let c=[t("div",{},`Сегодня вы открыли ${n.n} ${J(n.n,"матч","матча","матчей")} до начала: в основной исход ${o.bookName||"контора"} закладывает в среднем `,t("b",{text:K(n.here,1)})," маржи.")];return n.best?(c.push(t("div",{style:"margin-top:6px"},`На тех же ${n.best.n} ${J(n.best.n,"матче","матчах","матчах")} у ${n.best.name} — `,t("b",{text:K(n.best.there,1)}),` против ${K(n.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((n.best.here-n.best.there)*100).toFixed(1)} п.п.`)),n.partner&&c.push(t("div.partner-links",{style:"margin-top:8px"},n.partner.url?lt(n.partner):null,ft(n.partner)),t("div.hint",{text:et(n.partner)}))):c.push(t("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),t("div.card",{},t("div.kicker",{},t("span",{text:"Сколько маржи вы отдаёте"}),t("span.badge",{text:"сегодня"})),...c)}function Yt(o){let n=o.scan,c=Gt(o);return n?.rows?.length?[c,t("div.card",{},t("div.kicker",{},t("span",{text:n.title}),t("span.badge",{text:`средняя маржа ${K(n.average,1)}`})),t("table",{},t("tr",{},t("th",{text:n.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),n.rows.map(h=>t("tr.click",{"data-act":"scan-go","data-arg":String(h.index),title:"Показать на странице"},t("td.name",{},h.name,h.sub?t("span.sub",{text:h.sub}):null),t("td",{},h.fav,t("span.sub",{text:K(h.favPct)})),t(`td${h.low?".best":""}`,{text:K(h.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:n.note}))]:[c,t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function Ft(o){let n=o.express;if(!n.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let c=n.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${n.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},G("trash",13),"Очистить")),n.legs.map(h=>t("div.leg",{},t("div.t",{},t("b",{text:h.label,title:h.label}),t("span",{text:h.title,title:h.title})),t("span.o",{text:V(h.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":h.id,title:"Убрать",style:"width:24px;height:24px"},G("close",13))))),c?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:V(c.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:K(c.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:V(c.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:K(c.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function wt(o){let n=o.edges||{status:"idle"},c=w=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),w?t("span.badge",{text:w}):null);if(n.status==="loading"&&!n.data)return[t("div.card",{},c("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(n.status==="error"&&!n.data)return[t("div.card",{},c(),t("div.note.warn",{},G("alert"),t("span",{text:n.error})))];let h=n.data;if(!h)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let y=w=>w==null?"—":`${w>=0?"+":"−"}${(Math.abs(w)*100).toFixed(1)}%`,x=w=>new Date(w).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),b=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(h.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(h.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:y(h.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:h.positiveWeek==null?"—":K(h.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),v=(h.signals||[]).map(w=>t("tr",{},t("td.name",{},`${w.home} — ${w.away}`,t("span.sub",{text:`${w.league} · ${x(w.start)}`})),t("td",{},w.label,t("span.sub",{text:w.book})),t("td",{text:V(w.odds)}),t("td",{text:V(1/w.p),title:`Честная цена по ${w.count} конторам`}),t("td.best",{text:`+${(w.edge*100).toFixed(1)}%`})));return[t("div.card",{},c(h.full?"тариф «Макс»":"витрина"),v.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),v):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),h.note?t("div.hint",{style:"margin-top:8px"},h.note," ",i.bot?t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),b]}function Jt(o){let n=o.settings,c=(h,y,x)=>t("div.seg",{},x.map(([b,v])=>t(`button${y===b?".on":""}`,{type:"button","data-act":h,"data-arg":b,text:v})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),c("set-overlay",n.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),c("set-theme",n.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(n.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${n.ready?".pos":""}`,{text:n.ready?"подключён":"не подключён"})),n.proxy?t("div.field",{},t("label",{text:"Доступ"}),c("set-mode",n.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,n.mode==="license"&&n.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:n.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),n.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[n.licenseMask?`Ключ ${n.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",n.plan,n.usage].filter(Boolean).join(" "),i.bot&&!n.licenseMask?[" ",t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:n.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),n.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${n.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function Qt(o){dt=o;let n=JSON.stringify(o);if(n===R)return;R=n;for(let v of g.querySelectorAll("details[data-key]"))D.set(v.dataset.key,v.open);let c=g.scrollTop;$.textContent=o.bookName?`· ${o.bookName}`:"",p.classList.toggle("off",o.settings.overlay==="off"),S.replaceChildren(G(o.theme==="dark"?"sun":"moon")),z.replaceChildren(G(o.settings.overlay==="off"?"eyeOff":"eye")),z.classList.toggle("on",o.settings.overlay!=="off"),_.classList.toggle("on",o.tab==="settings"),_.dataset.arg=o.tab==="settings"?o.backTab:"settings";let h=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];u.replaceChildren(...h.map(([v,w])=>t(`button.tab${o.tab===v?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":v},w,v==="express"&&o.express.legs.length?t("span.count",{text:String(o.express.legs.length)}):null)));let y=o.tab==="settings"?Jt(o):o.tab==="scan"?Yt(o):o.tab==="express"?Ft(o):o.tab==="edges"?wt(o):Ot(o),x=o.update?t("div.card.soft.update",{},t("b",{text:`Вышла Линза ${o.update.version}`})," — ",o.update.url?t("a",{href:o.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,b=o.whatsnew?.changes?.length&&o.tab!=="settings"?t("div.card.soft.update",{},t("b",{text:`Линза обновилась до ${o.whatsnew.version}`}),t("ul.facts",{style:"margin-top:6px"},o.whatsnew.changes.flatMap(v=>v.items).slice(0,6).map(v=>t("li",{},t("span",{text:v})))),t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;g.replaceChildren(...[x,b,...y].filter(Boolean)),g.scrollTop=c,k.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function Et(o){e.setAttribute("data-theme",o)}function $t(){C.hidden=!1,r.opened?.()}function ct(){C.hidden=!0}function Mt(){C.hidden?$t():ct()}function s(o){o?.fab&&M(l,o.fab.left,o.fab.top),o?.panel&&M(C,o.panel.left,o.panel.top)}let d=0;function m(o){f.querySelector(".toast")?.remove();let n=t("div.toast",{text:o,role:"status"});f.appendChild(n),clearTimeout(d),d=setTimeout(()=>n.remove(),2600)}return{render:Qt,setTheme:Et,open:$t,close:ct,toggle:Mt,restore:s,toast:m,shadow:f,rect:()=>C.hidden?null:C.getBoundingClientRect(),get isOpen(){return!C.hidden},get view(){return dt}}}var De="Расширение обновилось. Обновите эту вкладку (F5).";function gt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function Y(a,r={}){if(!gt())return{ok:!1,error:De,code:"reload"};try{return await chrome.runtime.sendMessage({type:a,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(i){let e=String(i?.message||i);return/context invalidated|message port closed|receiving end does not exist/i.test(e)||!gt()?{ok:!1,error:De,code:"reload"}:{ok:!1,error:e}}}function We(a){if(gt())try{chrome.runtime.onMessage.addListener(r=>{a(r)})}catch{}}async function le(a){if(!gt())return{};try{return await chrome.storage.local.get(a)}catch{return{}}}function bt(a){if(gt())try{chrome.storage.local.set(a)}catch{}}var Ve=(a=Date.now())=>new Date(a).toISOString().slice(0,10);function Ut(a,r=Date.now()){return a&&a.day===Ve(r)&&a.items&&typeof a.items=="object"?a:{day:Ve(r),items:{}}}function Ke(a,{key:r,book:i,margin:e}){if(!r||!Number.isFinite(e)||e<=0||e>.5)return!1;let f=Math.round(e*1e4)/1e4,p=a.items[r];return p&&p.here===f&&p.book===i?!1:(a.items[r]={book:i,here:f,others:p?.others||{}},!0)}function Ze(a,r,i){let e=a.items[r];if(!e)return!1;let f=!1;for(let p of i||[]){if(p.here||p.sharp||!p.odds?.length||p.odds.some(g=>!(g>1)))continue;let l=St(p.odds);if(l.kind!=="full"||!(l.margin>0))continue;let u=Math.round(l.margin*1e4)/1e4;e.others[p.name]!==u&&(e.others[p.name]=u,f=!0)}return f}function Ue(a,r){let i=Object.values(a?.items||{}).filter(l=>l.book===r);if(!i.length)return null;let e=l=>l.reduce((u,g)=>u+g,0)/l.length,p=[...new Set(i.flatMap(l=>Object.keys(l.others||{})))].map(l=>{let u=i.filter(g=>Number.isFinite(g.others?.[l]));return u.length>=2?{name:l,n:u.length,there:e(u.map(g=>g.others[l])),here:e(u.map(g=>g.here))}:null}).filter(Boolean).sort((l,u)=>l.there-u.there);return{n:i.length,here:e(i.map(l=>l.here)),best:p[0]||null,others:p}}var En=[{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function He(a,r){let i=String(a||"").split(".").map(Number),e=String(r||"").split(".").map(Number);for(let f=0;f<Math.max(i.length,e.length);f++){let p=(i[f]||0)-(e[f]||0);if(p)return p>0}return!1}function Xe(a,r){return En.filter(i=>He(i.version,a)&&!He(i.version,r))}var Ht=globalThis.__lzBus,ce=Ht&&window.top===window?Ne(location.hostname):null;ce&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,qn(ce.adapter,ce.book));async function qn(a,r){let i=await le(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),e={settings:{...ee,...i["lz.settings"]||{}},positions:(i["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Bn(i["lz.express"]),margins:Ut(i["lz.margins"]),whatsnew:i["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},f=new WeakMap,p=new WeakMap,l=Oe(),u=Ie({bus:Ht,brand:Pt,actions:Yt()});u.restore(e.positions);function g(s){let d=s.outcomes.map(n=>n.odd).join("/"),m=f.get(s);if(m?.sig===d)return m.set;let o=St(s.outcomes.map(n=>n.odd));return f.set(s,{sig:d,set:o}),o}function k(){return e.match?e.analysis.get(e.match.key):null}function $(s){let d=k()?.result;if(!d?.model||s.scope==="list"||!e.match||!Object.values(d.shift||{}).some(h=>Math.abs(h)>=.5))return null;let{home:m,draw:o,away:n}=d.model,c=s.outcomes.length;if(s.kind==="1x2"&&s.main&&c===3)return[m,o,n];if(s.kind==="12"&&s.main&&c===2&&o<.005)return[m,n];if(s.kind==="dc"&&s.main&&c===3)return[m+o,m+n,o+n];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&c===2){let h=s.period===e.match.home?m:s.period===e.match.away?n:null;if(h!=null)return[h,1-h]}return null}function S(){let s=e.markets.filter(d=>d.scope!=="list"&&d.main&&(d.kind==="1x2"||d.kind==="12"));return s.find(d=>d.scope==="top")||s[0]||null}function z(s,d){let m=s.outcomes[d].label;return s.scope==="list"?!s.event||!s.main?m:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][d]||m:s.kind==="12"&&[s.event.home,s.event.away][d]||m:e.match?s.kind==="1x2"?[e.match.home,"Ничья",e.match.away][d]||m:s.kind==="12"&&[e.match.home,e.match.away][d]||m:m}function _(){let s=e.settings.overlay,d=[];for(let o of e.markets){if(o.outcomes.forEach((v,w)=>p.set(v.el,{market:o,index:w})),s==="off")continue;let n=g(o);if(n.kind==="partial")continue;let c=$(o),h=c||n.fair,y=0;for(let v=1;v<n.fair.length;v+=1)n.fair[v]>n.fair[y]&&(y=v);let x="accent";if(c){let v=0;for(let w=1;w<c.length;w+=1)c[w]-n.fair[w]>c[v]-n.fair[v]&&(v=w);c[v]-n.fair[v]>=.015&&(y=v,x="pos")}let b=o.scope!=="list"||o.main&&(o.kind==="1x2"||o.kind==="12");o.outcomes.forEach((v,w)=>{let O=w===y&&b;!O&&s!=="all"||d.push({el:v.el,frame:O,chip:ht(h[w]),tone:O?x:"quiet"})})}let m=F();if(m){let o=d.find(n=>n.el===m.item.el);o?o.selected=!0:d.push({el:m.item.el,frame:!1,selected:!0,chip:null})}l.set(d)}function F(){if(!e.selected)return null;let s=e.markets.find(m=>m.id===e.selected.id),d=s?.outcomes[e.selected.index];return d?.el?.isConnected?{market:s,item:d,index:e.selected.index}:null}function C(){if(e.settings.theme!=="auto")return e.settings.theme;for(let s of[document.body,document.documentElement]){let m=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!m||m[4]==="0")continue;return(.2126*m[1]+.7152*m[2]+.0722*m[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let q=0;function R(){clearTimeout(q),q=setTimeout(()=>bt({"lz.margins":e.margins}),1500)}function dt(){if(e.pageType!=="match"||!e.match||e.match.live)return;e.margins=Ut(e.margins);let s=E();s&&Ke(e.margins,{key:e.match.key,book:r.id,margin:s.margin})&&R()}function D(){location.href!==e.url&&(e.url=location.href,e.selected=null,l.hideTip());let s="other",d=[],m=null;try{s=a.pageType(document,location),d=a.collect(document,location),m=a.readMatch(document,location)}catch(n){console.error("[Линза] страница не прочитана",n)}s!==e.pageType&&(e.pageType=s,e.tab!=="settings"&&e.tab!=="express"&&(e.tab=s==="match"?"match":"scan")),e.markets=d,e.match=m,dt();let o=C();o!==e.theme&&(e.theme=o),l.setTheme(e.theme),u.setTheme(e.theme),_(),ft(),L(),u.isOpen&&(Nt(),Ct(),Ot(),Lt(),u.render(H()))}let ut=new Set,I=null;function L(){if(a.observeTargets)for(let s of a.observeTargets(document))ut.has(s)||(ut.add(s),I=I||new MutationObserver(B),I.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let M=0,A=0;function B(){let s=Date.now();A||(A=s),clearTimeout(M);let d=s-A>900?0:220;M=setTimeout(()=>{A=0,!document.hidden&&D()},d)}function E(){let s=S();if(!s)return null;let d=g(s);if(d.kind!=="full")return null;let m=$(s);return{title:"Что заложено в цене",margin:d.margin,rows:s.outcomes.map((o,n)=>({name:z(s,n),odd:o.odd,fair:d.fair[n],model:m?m[n]:null})),overtime:Q()}}function Q(){if(!["hockey","basketball"].includes(e.match?.sport))return null;let s=e.markets.find(m=>m.scope!=="list"&&m.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${m.title} ${m.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${m.title} ${m.period}`));if(!s)return null;let d=g(s);return d.kind!=="full"?null:{title:[s.title,s.period].filter(Boolean).join(" · "),rows:s.outcomes.map((m,o)=>({name:z(s,o)||[e.match.home,e.match.away][o],odd:m.odd,fair:d.fair[o]}))}}function tt(){let s=F();if(!s)return null;let{market:d,item:m,index:o}=s,n=g(d),c=$(d),h=n.fair?n.fair[o]:null,y=d.event?`${d.event.home} — ${d.event.away}`:e.match?`${e.match.home} — ${e.match.away}`:"",x=e.match?e.compare.get(e.match.key):null,b=null;if(x?.rows?.length&&d.main&&(d.kind==="1x2"||d.kind==="12")&&d.scope!=="list")for(let w of x.rows){let O=w.odds[o];O&&(!b||O>b.odd)&&(b={name:w.name,odd:O,book:w.book||""})}b&&(b.partner=b.book&&b.book!==r.id&&e.partners.data?.[b.book]||null,b.gain=Math.round((b.odd-m.odd)*(e.settings.stake||1e3)));let v=`${d.id}#${o}`;return{market:[d.title,d.period,d.line].filter(Boolean).join(" · "),label:[z(d,o),y].filter(Boolean).join(" · "),odd:m.odd,fair:h,margin:n.margin,fairOdd:h?1/h:null,model:c?c[o]:null,ev:c?ge(c[o],m.odd):null,best:b,canAdd:Number.isFinite(h)&&!e.express.some(w=>w.id===v),inExpress:e.express.some(w=>w.id===v),note:n.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":c?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function rt(){let s=Ue(Ut(e.margins),r.id);if(!s)return null;let d=s.best&&s.best.there<s.best.here?s.best:null,m=d&&pt().find(o=>o.name===d.name&&(o.url||o.code))||null;return{...s,best:d,partner:m}}function at(){let s=[];if(e.pageType==="match"?e.markets.forEach((n,c)=>{if(n.scope==="list")return;let h=g(n);if(h.kind!=="full")return;let y=0;for(let x=1;x<h.fair.length;x+=1)h.fair[x]>h.fair[y]&&(y=x);s.push({index:c,name:n.title,sub:[n.period,n.line].filter(Boolean).join(" · "),margin:h.margin,fav:n.outcomes[y].label,favPct:h.fair[y]})}):e.markets.forEach((n,c)=>{if(!n.event||!n.main||n.kind!=="1x2"&&n.kind!=="12")return;let h=g(n);if(h.kind!=="full")return;let y=0;for(let b=1;b<h.fair.length;b+=1)h.fair[b]>h.fair[y]&&(y=b);let x=n.kind==="1x2"?[n.event.home,"Ничья",n.event.away][y]:[n.event.home,n.event.away][y];s.push({index:c,name:`${n.event.home} — ${n.event.away}`,sub:n.event.league||n.event.time,margin:h.margin,fav:x,favPct:h.fair[y]})}),!s.length)return null;let d=new Set;for(let n=s.length-1;n>=0;n-=1){let c=`${s[n].name}|${s[n].sub}`;d.has(c)?s.splice(n,1):d.add(c)}let m=s.reduce((n,c)=>n+c.margin,0)/s.length;s.sort((n,c)=>n.margin-c.margin);let o=s.slice(0,16);return o.forEach(n=>{n.low=n.margin<=m*.8}),{title:e.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:e.pageType==="match"?"Рынок":"Матч",average:m,rows:o,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${o.length} из ${s.length}, сначала самые дешёвые.`}}function st(){let s=e.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function H(){let s=e.match?.key,d=s&&e.analysis.get(s)||{status:"idle",steps:[]},m=s&&e.compare.get(s)||{status:"idle"},o=e.match?.live&&a.readEsportsWidget?a.readEsportsWidget(document):null,n=e.status;return{tab:e.tab,backTab:e.backTab,theme:e.theme,bookName:r.name,pageType:e.pageType,match:e.match?{...e.match,sportName:ue[e.match.sport]||""}:null,esports:o?{...o,homeName:e.match.home,awayName:e.match.away}:null,line:E(),analysis:{status:d.status,steps:d.steps||[],result:d.result||null,error:d.error||"",needKey:!!d.needKey},compare:m,consensus:s&&e.consensus.get(s)||null,model:s&&e.model.get(s)||null,live:Xt(s),facts:s&&e.facts.get(s)||null,pick:tt(),scan:e.tab==="scan"?at():null,margins:e.tab==="scan"?rt():null,edges:e.edges,bookId:r.id,partners:pt(),stake:Number(e.settings.stake)||1e3,express:{legs:e.express,stats:he(e.express)},quota:st(),update:e.status.update?{version:e.status.update,url:Pt.site?`${Pt.site}#install`:""}:null,whatsnew:e.whatsnew?{version:e.whatsnew.to,changes:Xe(e.whatsnew.from,e.whatsnew.to)}:null,settings:{overlay:e.settings.overlay,theme:e.settings.theme,stake:Number(e.settings.stake)||1e3,mode:n.mode,proxy:n.proxy,ready:n.ready,hasKey:n.hasKey,keyMask:n.keyMask,licenseMask:n.licenseMask,plan:n.plan==="free"||!n.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[n.plan]||"Про"}»${n.until?` до ${n.until.split("-").reverse().join(".")}`:""}.`,usage:n.limit?`Сегодня разборов: ${n.used} из ${n.limit}.`:""}}}let Z=()=>{u.isOpen&&u.render(H())};function it(s){Object.assign(e.settings,s),bt({"lz.settings":e.settings}),D(),u.render(H())}async function xt(s=!1){if(!s&&Date.now()-e.partners.at<3600*1e3)return;e.partners.at=Date.now();let d=await Y("lz:partners",{force:s});d.ok&&d.data&&typeof d.data=="object"&&(e.partners.data=d.data,u.isOpen&&u.render(H()),ot())}let pt=()=>Object.values(e.partners.data||{}).filter(s=>s&&s.id!==r.id);function ot(){if(!u.isOpen||e.tab!=="match"||!e.match)return;let s=pt().filter(d=>d.url||d.code).map(d=>d.id);s.length&&Y("lz:partner-seen",{ids:s,s:"panel"})}async function J(){e.edges={...e.edges,status:"loading",error:""};let s=await Y("lz:edges",{sport:e.match?.sport||""});e.edges=s.ok?{status:"done",data:s.data,error:"",at:Date.now()}:{status:"error",data:e.edges.data,error:s.error,at:Date.now()},Z()}async function et(){let s=await Y("lz:status");s.ok&&(e.status=s.data),Z()}function lt(){let s=S(),d=s?g(s):null;return{book:r.name,match:e.match,market:s&&d?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((m,o)=>z(s,o)),odds:s.outcomes.map(m=>m.odd)}:null}}function ft(){if(!e.match||!gt())return;let s=lt();if(!s.market)return;let d=`${e.match.key}|${s.market.odds.join("/")}`;d!==ft.last&&(ft.last=d,Y("lz:quote",s))}async function Nt(){let s=e.match;if(!s||s.live||e.consensus.has(s.key))return;let d=lt();if(!d.market?.odds?.length)return;e.consensus.set(s.key,null);let m=await Y("lz:consensus",{match:s,size:d.market.odds.length});e.consensus.set(s.key,m.ok&&m.data?.consensus?m.data:null),e.match?.key===s.key&&u.isOpen&&u.render(H())}async function Lt(){let s=e.match;if(!s?.live||s.sport!=="basketball")return;let d=e.live.get(s.key);if(d&&(d.pending||Date.now()-d.at<3e4))return;e.live.set(s.key,{...d||{},pending:!0});let m=await Y("lz:live",{match:s});e.live.set(s.key,{at:Date.now(),data:m.ok&&m.data&&!m.data.error?m.data:null,error:m.ok?m.data?.error||"":m.error||""}),e.match?.key===s.key&&u.isOpen&&u.render(H())}function Xt(s){let d=s&&e.live.get(s);if(!d?.data)return d?.error?{error:d.error}:null;let m=d.data,o=!!m.flipped,n=(b,v)=>o?[v,b]:[b,v],c=E(),h=c?.overtime?.rows||c?.rows||[],y=h.length===2?h.map(b=>b.fair):h.length===3&&h.every(b=>Number.isFinite(b.fair))?[h[0].fair+h[1].fair/2,h[2].fair+h[1].fair/2]:null,x=m.tables||{};return{names:[e.match.home,e.match.away],score:n(m.score[0],m.score[1]),periods:(m.periods||[]).map(([b,v])=>n(b,v)),period:m.period,elapsed:m.elapsed,left:m.left,clock:m.clock,format:m.format,probs:n(m.p1,m.p2),book:y,prior:m.prior,expMargin:o?-m.expMargin:m.expMargin,sd:m.sd,projTotal:m.projTotal,sdTotal:m.sdTotal,handicap:(x.handicap||[]).map(b=>o?{line:-b.line,home:b.away,away:b.home}:b).sort((b,v)=>b.line-v.line),total:x.total||[],quarterTotal:x.quarterTotal||[],bookLines:m.bookLines?{handicap:m.bookLines.handicap?o?{...m.bookLines.handicap,line:-m.bookLines.handicap.line,odds:[...m.bookLines.handicap.odds].reverse(),fair:[...m.bookLines.handicap.fair].reverse(),p:1-m.bookLines.handicap.p,book:1-m.bookLines.handicap.book,gap:-m.bookLines.handicap.gap}:m.bookLines.handicap:null,total:m.bookLines.total||null}:null,quarter:m.quarter?{...m.quarter,score:n(m.quarter.score[0],m.quarter.score[1]),expMargin:o?-m.quarter.expMargin:m.quarter.expMargin,probs:n(m.quarter.p1,m.quarter.p2)}:null,at:d.at}}async function Ct(){let s=e.match;if(!s||!["cs","dota","tennis","basketball"].includes(s.sport)||e.model.has(s.key)||s.live&&(s.sport==="tennis"||s.sport==="basketball"))return;e.model.set(s.key,null);let d=await Y("lz:model",{match:s});e.model.set(s.key,d.ok&&d.data?.p1?d.data:null),e.match?.key===s.key&&u.isOpen&&u.render(H())}let At=new Map;async function Ot(){let s=e.match;if(!s||!["football","hockey","basketball","cs","dota"].includes(s.sport))return;let d=s.live&&Date.now()-(At.get(s.key)||0)>60*1e3;if(e.facts.has(s.key)&&!d)return;let m=e.facts.get(s.key)||null;At.set(s.key,Date.now()),e.facts.set(s.key,m);let o=await Y("lz:facts",{match:s});e.facts.set(s.key,o.ok&&o.data?.facts?.length?o.data:m),e.match?.key===s.key&&u.isOpen&&u.render(H())}async function Gt(){let s=e.match;if(!s||e.analysis.has(s.key))return;let d=await Y("lz:cached",{match:s});!d.ok||!d.data||e.analysis.has(s.key)||(e.analysis.set(s.key,{status:"done",steps:[],result:d.data}),D(),Z())}function Yt(){return{opened(){et(),D(),Gt(),Nt(),Ct(),Ot(),Lt(),xt(),u.render(H()),ot()},tab(s){s==="settings"&&(e.backTab=e.tab==="settings"?e.backTab:e.tab),e.tab=s||"match",s==="edges"&&e.edges.status!=="loading"&&Date.now()-e.edges.at>300*1e3&&J(),u.render(H())},"edges-refresh"(){J(),u.render(H())},theme(){it({theme:e.theme==="dark"?"light":"dark"})},"overlay-toggle"(){it({overlay:e.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){it({overlay:s})},"set-theme"(s){it({theme:s})},async"set-mode"(s){await Y("lz:settings",{mode:s}),et()},"copy-code"(s){if(!s)return;let d=()=>u.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(s).then(d,()=>u.toast(`Промокод: ${s}`)):u.toast(`Промокод: ${s}`)},"set-stake"(s,d,m){let o=Math.round(Number(m.getElementById("lz-stake")?.value));if(!Number.isFinite(o)||o<10||o>1e7)return u.toast("Введите сумму от 10 ₽");it({stake:o}),u.toast("Сумма сохранена")},async"save-key"(s,d,m){let o=m.getElementById("lz-key"),n=(o?.value||"").trim();if(n.length<8)return u.toast("Вставьте ключ целиком");let c=await Y("lz:settings",{apiKey:n});u.toast(c.ok?"Ключ сохранён":c.error),o&&(o.value=""),et()},async"clear-key"(){await Y("lz:settings",{apiKey:""}),u.toast("Ключ удалён"),et()},async"save-license"(s,d,m){let o=m.getElementById("lz-license"),n=(o?.value||"").trim();if(n.length<6)return u.toast("Вставьте ключ целиком");let c=await Y("lz:settings",{licenseKey:n});u.toast(c.ok?"Ключ принят":c.error),o&&(o.value=""),et()},async"clear-license"(){await Y("lz:settings",{licenseKey:""}),u.toast("Ключ удалён"),et()},savePosition(s,d){e.positions[s]=d,le(["lz.positions"]).then(m=>{let o=m["lz.positions"]||{};o[location.hostname]=e.positions,bt({"lz.positions":o})})},async analyze(){if(!e.match)return;let s=e.match.key,d={status:"loading",steps:[`${e.match.home} — ${e.match.away}`]};e.analysis.set(s,d),Z();let m=await Y("lz:analyze",{...lt(),force:!0});m.ok?e.analysis.set(s,{status:"done",steps:d.steps,result:m.data}):e.analysis.set(s,{status:"error",steps:d.steps,error:m.error,needKey:m.code==="no-access"}),et(),D(),u.render(H())},async compare(){if(!e.match)return;let s=e.match.key;e.compare.set(s,{status:"loading"}),Z();let d=await Y("lz:compare",lt());e.compare.set(s,d.ok?{status:"done",...d.data}:{status:"done",rows:[],labels:[],note:d.error}),d.ok&&Ze(e.margins,s,d.data.rows)&&R(),Z()},"whatsnew-ok"(){e.whatsnew=null,bt({"lz.whatsnew":null}),Z()},"pick-clear"(){e.selected=null,_(),Z()},"leg-add"(){let s=tt(),d=F();!s?.canAdd||!d||(e.express.push({id:`${d.market.id}#${d.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),bt({"lz.express":e.express}),u.toast("Добавлено в расчёт экспресса"),Z())},"leg-remove"(s){e.express=e.express.filter(d=>d.id!==s),bt({"lz.express":e.express}),Z()},"leg-clear"(){e.express=[],bt({"lz.express":e.express}),Z()},"scan-go"(s){let d=e.markets[Number(s)],m=d?.outcomes[0]?.el;m?.isConnected&&(m.scrollIntoView({behavior:"smooth",block:"center"}),e.selected={id:d.id,index:0},setTimeout(_,400))}}}function Ft(s){let d=s.composedPath();for(let m=0;m<Math.min(d.length,6);m+=1){let o=d[m]instanceof Element?p.get(d[m]):null;if(o&&o.market.outcomes[o.index]?.el===d[m])return o}return null}let wt=new Map;function Jt(s){if(!s.event||!s.main||!["1x2","12"].includes(s.kind)||s.scope!=="list"||s.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!s.event,main:s.main,kind:s.kind,scope:s.scope,live:s.event?.live})),null;let d=s.event.key;if(wt.has(d))return wt.get(d);let m={home:s.event.home,away:s.event.away,sport:Qt(s),league:s.event.league||""},o=Y("lz:consensus",{match:m,size:s.outcomes.length}).then(n=>((!n.ok||!n.data?.consensus)&&console.debug("[lz] рынок для списка:",n.error||n.data?.error||"нет данных"),n.ok&&n.data?.consensus?n.data:null)).catch(n=>(console.debug("[lz] рынок для списка:",String(n?.message||n)),null));return wt.set(d,o),o.then(n=>wt.set(d,n)),o}let Qt=s=>s.event?.sport||e.match?.sport||zt(location.pathname,document.title,s.event?.league);function Et({market:s,index:d},m=null){let o=g(s),n=$(s),c=s.event?`${s.event.home} — ${s.event.away}`:"",h=s.outcomes.map((b,v)=>{let w=o.fair?o.fair[v]:1/b.odd;return t(`div.tip-row${v===d?".hot":""}`,{},t("span",{text:z(s,v)}),t("span.odd",{text:V(b.odd)}),t("span.pct",{text:ht(w,w<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(w*100)}%`})))}),y=o.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:ht(o.margin,1)}),n?t("span",{}," · модель: ",t("b",{text:ht(n[d],1)})):null),x=null;if(m?.consensus){let b=m.consensus.length===s.outcomes.length,v=!b&&m.consensus.length===2&&s.outcomes.length===3;if(b||v){let w=b?m.consensus[d]:null,O=w?s.outcomes[d].odd*w-1:0;x=t("div.tip-foot",{},`Рынок, ${m.count} контор${v?", с овертаймом":""}: `,t("b",{text:m.consensus.map(W=>ht(W,0)).join(" / ")}),O>.005?t("span.pos",{text:` · кэф выше рынка на ${(O*100).toFixed(1)}%`}):null)}}else m===void 0&&(x=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),c?t("div.tip-sub",{text:c}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),h.slice(0,8),y,x)}let $t=0,ct=null;Ht.on("page:pointerover",s=>{if(e.settings.overlay==="off")return;let d=Ft(s),m=d?d.market.outcomes[d.index].el:null;if(m!==ct){if(ct=m,clearTimeout($t),!d)return l.hideTip();$t=setTimeout(()=>{if(ct!==m||!m.isConnected)return;l.setAvoid(u.rect());let o=Jt(d.market);l.showTip(m,Et(d,o instanceof Promise?void 0:o)),o instanceof Promise&&o.then(n=>{ct===m&&m.isConnected&&l.showTip(m,Et(d,n))})},280)}}),Ht.on("page:click",s=>{let d=Ft(s);d&&(e.selected={id:d.market.id,index:d.index},e.tab==="scan"&&(e.tab="match"),_(),Z())}),We(s=>{if(s.type!=="lz:progress")return;let d=e.analysis.get(s.key);!d||d.status!=="loading"||(d.steps=[...d.steps,s.text].slice(-7),Z())});let Mt=()=>{D(),new MutationObserver(B).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||D()}),setInterval(()=>{!document.hidden&&location.href!==e.url&&D()},600),setInterval(()=>{!document.hidden&&u.isOpen&&B()},4e3),gt()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(e.settings={...ee,...s["lz.settings"].newValue||{}},D())}),et()};document.body?Mt():document.addEventListener("DOMContentLoaded",Mt,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:e,view:H,refresh:D,overlay:l,panel:u}}function Bn(a){let r=Date.now()-432e5;return(Array.isArray(a)?a:[]).filter(i=>i&&i.at>r&&i.odd>1)}})();
