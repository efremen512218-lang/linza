(()=>{var Dt=r=>typeof r=="string"?r:"",Ut={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Dt("https://efremen512218-lang.github.io/linza/"),telegram:Dt("https://t.me/linza_odds"),bot:Dt("https://t.me/linza_keys_bot?start=ext")},eo=Dt("https://185-72-145-3.sslip.io"),cn={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var dn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function xe(r){let a=String(r||"").toLowerCase();return dn.find(s=>s.hosts.some(e=>a===e||a.endsWith(`.${e}`)))||null}var ie={overlay:"picks",theme:"auto",mode:"own",model:cn.model,stake:1e3},ye={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function bt(r){let a=String(r??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(a))return null;let s=parseFloat(a.replace(",","."));return s>=1.001&&s<=1e3?s:null}var ve=r=>r.reduce((a,s)=>a+1/s,0);function Ot(r){let a=(r||[]).filter(e=>Number.isFinite(e)&&e>1);if(a.length<2||a.length!==(r||[]).length)return{kind:"partial",margin:null,fair:null};let s=ve(a);if(s>=.985&&s<=1.3)return{kind:"full",margin:s-1,fair:a.map(e=>1/e/s)};if(a.length===3&&s>=1.97&&s<=2.4){let e=s/2;return{kind:"double",margin:e-1,fair:a.map(f=>Math.min(.995,1/f/e))}}return{kind:"partial",margin:null,fair:null}}function ke(r){let a=(r||[]).map(g=>g||[]).filter(g=>g.length),s=a.flat().filter(Boolean);if(s.length<2)return{sets:[],rest:s};let e=g=>g.length>=2&&g.every(Boolean)&&Ot(g.map(b=>b.odd)).kind!=="partial",f=g=>{let b=g.filter(z=>z.some(Boolean));if(!b.length)return null;let v=b.filter(e);if(v.length/b.length<.6)return null;let S=new Set(v.flat());return{sets:v,rest:s.filter(z=>!S.has(z))}},p=g=>{let b=[];for(let v=0;v<a.length;v+=g)b.push(a.slice(v,v+g).flat());return b},c=()=>{let g=[];for(let b=0;b+1<a.length;b+=2){let v=Math.max(a[b].length,a[b+1].length);for(let S=0;S<v;S+=1)g.push([a[b][S]??null,a[b+1][S]??null])}return g},d=[()=>p(1)];a.length>=2&&a.length%2===0&&d.push(c,()=>p(2)),a.length>=3&&a.length%3===0&&d.push(()=>p(3)),a.length>1&&d.push(()=>[a.flat()]);for(let g of d){let b=f(g());if(b)return b}return{sets:[],rest:s}}function we(r,a=1.13){let s=d=>{let g=ve(d.map(b=>b.odd));return g>=.995&&g<=a?!0:d.length===3&&g>=1.99&&g<=a*2},e=d=>Math.abs(d*4-Math.round(d*4))<1e-9,f=[],p=[],c=0;for(;c<r.length;){let d=r.slice(c,c+3),g=r.slice(c,c+2);d.length===3&&s(d)?(f.push(d),c+=3):g.length===2&&s(g)?(f.push(g),c+=2):r[c+2]&&e(r[c+1].odd)&&s([r[c],r[c+2]])?(f.push([r[c],r[c+2]]),p.push(r[c+1]),c+=3):(p.push(r[c]),c+=1)}return{sets:f,rest:p}}function $e(r){let a=(r||[]).filter(f=>f&&f.odd>1&&f.fair>0&&f.fair<1);if(!a.length)return null;let s=a.reduce((f,p)=>f*p.odd,1),e=a.reduce((f,p)=>f*p.fair,1);return{legs:a.length,odd:s,chance:e,fairOdd:1/e,margin:1-s*e}}function ze(r,a){return r*a-1}function Z(r){return Number.isFinite(r)?r>=100?r.toFixed(0):r>=10?r.toFixed(1):r.toFixed(2):"—"}function xt(r,a=0){if(!Number.isFinite(r))return"—";let s=r*100;return s>0&&s<1&&a===0?"<1%":`${s.toFixed(a)}%`}function le(r){return String(r??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var un=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Me(r){return String(r??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(a=>a.length>=2&&!un.has(a))}function At(r,a){let s=le(r),e=le(a);if(s.length<2||e.length<2)return 0;if(s===e)return 1;let f=s.length<=e.length?s:e,p=f===s?e:s;if(f.length>=4&&p.includes(f))return .85;let c=Me(r),d=Me(a),g=v=>String(v??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[v,S]of[[r,d],[a,c]]){let z=g(v);if(z&&S.length>=2&&S.includes(z[1])&&S.some(_=>_!==z[1]&&_[0]===z[2]))return .8}if(c.length&&d.length){let S=c.filter(z=>d.some(_=>_===z||z.length>=5&&_.startsWith(z.slice(0,5)))).length/Math.max(c.length,d.length);if(S>=.5)return .6+.3*S}let b=0;for(;b<s.length&&b<e.length&&s[b]===e[b];)b+=1;return b>=5?Math.min(.8,.45+b*.04):0}function pn(r){let a=String(r??"").toLowerCase(),s=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(a)&&s.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(a)&&s.push("women"),/\(рез|\(р\)|резерв|reserve/.test(a)&&s.push("reserve"),/люб/.test(a)&&s.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(a)&&s.push("cyber"),s.join("+")}function zt(r,a){let s=p=>{let c=le(p),d=pn(p);return c.length<2?"":d?`${c}~${d}`:c},e=s(r),f=s(a);return!e||!f?"":[e,f].sort().join("|")}var L=r=>(r?.textContent||"").replace(/[ \s]+/g," ").trim(),ce=r=>r.offsetParent===null&&r.tagName!=="BODY";function fn(r){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(r||"").trim())}function mn(r){let a=String(r||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return a?a[0]:""}function Et(r,a){let s=String(r||"").toLowerCase();return/двойной шанс/.test(s)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(s)?"other":/фор[аы]|гандикап/.test(s)?"handicap":/тотал/.test(s)?"total":/обе забьют/.test(s)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(s)?a===3?"1x2":a===2?"12":"other":"other"}var hn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function Nt(...r){let a=r.filter(Boolean).join(" ");for(let[s,e]of hn)if(s.test(a))return e;return""}function de(r){if(!r)return null;let a=bt(L(r));if(a)return a;let s=L(r).split(" ");return bt(s[s.length-1])}var gn=0;function Mt({scope:r,title:a,period:s="",line:e="",kind:f,outcomes:p,event:c=null,anchor:d=null,eventKey:g=""}){let b=p.length;return{id:`${r}|${g}|${a}|${s}|${e}|${p.map(v=>v.label).join("/")}`,serial:gn+=1,scope:r,title:a,period:s,line:e,kind:f||Et(a,b),main:fn(s)&&!mn(a),outcomes:p,event:c,anchor:d||p[0]?.el||null}}var D=(r,a)=>[...r.querySelectorAll(a)];function Ce(r){return(String(r||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function ue(r){return r.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":r.querySelector(".card")?"list":"other"}var Se={win:"В",loose:"П",lose:"П",draw:"Н"};function _e(r){return D(r,".competitor-form__value").map(a=>Se[[...a.classList].find(s=>Se[s])]||L(a).slice(0,1)).filter(Boolean).join("")}function bn(r){let a=r.querySelector(".marketbook-header--live");if(a){let e=D(a,".game-scoring__item").map(c=>L(c)),f=D(a,".game-periods .period").map(c=>{let d=D(c,"span");return{label:L(c.querySelector("i")),home:L(d[0]),away:L(d[1])}}).filter(c=>c.home!==""&&c.away!==""),p=D(a,".game-specials > div").map(c=>{let d=D(c,"span"),g=c.querySelector("i"),b=g?.classList.contains("yellow-card")?"жёлтые":g?.classList.contains("red-card")?"красные":g?.classList.contains("penalty-card")?"угловые":"";return b?{kind:b,home:L(d[0]),away:L(d[1])}:null}).filter(Boolean);return{state:L(a.querySelector(".game-timing-state")),score:e.length===2?e:[],periods:f,extras:p}}let s=r.querySelector(".match-card");if(s&&!s.querySelector(".match-card__timer--prematch")){let e=L(s.querySelector(".match-card__main-score")).replace(/\s/g,""),f=D(s,".match-card__score").map(c=>L(c)).filter(c=>/^\d{1,2}$/.test(c)),p=D(r,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(c=>L(c)).filter(c=>/\d\s*:\s*\d/.test(c)).slice(0,5);return{state:L(s.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(e)?e.split(":"):[],rounds:f.length>=2?f.slice(0,2):[],periods:p.map((c,d)=>({label:`${d+1} карта`,raw:c})),extras:[]}}return null}function Ne(r,a){if(ue(r)!=="match")return null;let s=D(r,".breadcrumbs .breadcrumbs__item").map(b=>L(b)).filter(Boolean),e=L(r.querySelector(".event-breadcrumbs")),f=D(r,".marketbook-header--prematch .competitor-name").map(b=>L(b));if(f.length<2&&(f=D(r,".marketbook-header--live .competitors-desc__name").map(b=>L(b))),f.length<2&&(f=D(r,".match-card .match-card__team-name").map(b=>L(b))),f.length<2||!f[0]||!f[1])return null;let p=Nt(s[1]&&/киберспорт/i.test(s[0])?s[1]:"",s[0],e),c=/киберспорт/i.test(s[0]||"")?s.slice(2).join(", ")||e.split(",").slice(1).join(",").trim():s.slice(1).join(", "),d=[L(r.querySelector(".prematch-date")),L(r.querySelector(".prematch-time"))].filter(Boolean).join(" ")||L(r.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),g=bn(r);return{book:"Winline",id:Ce(a?.pathname),key:zt(f[0],f[1]),home:f[0],away:f[1],sport:p,league:c,start:g?"":d,live:g,form:{home:_e(r.querySelector(".competitor-form--left")||r.createElement("div")),away:_e(r.querySelector(".competitor-form--right")||r.createElement("div"))},stats:$n(zn(r),f[0],f[1]),url:a?.href||""}}function xn(r,a){let s=[];for(let e of D(r,".bet-line")){if(ce(e))continue;let f=L(e.querySelector(".bet-line__market-name")),p=L(e.querySelector(".bet-line__period")),c=D(e,".odd-btn"),d=c.map((b,v)=>{let S=L(b.querySelector(".odd-btn__label")),z=D(b,"span").map(_=>bt(L(_))).find(Boolean)||null;return z?{el:b,odd:z,label:S||pe(c.length,v,f),locked:!1}:null});if(d.length<2||d.some(b=>!b))continue;let g=L(e.querySelector(".coef-btn")).replace(/\s+/g," ");s.push(Mt({scope:"top",title:f,period:p,line:g,outcomes:d,anchor:e,eventKey:a}))}return s}function pe(r,a,s){return/тотал/i.test(s)?["Меньше","Больше"][a]||"":r===3?["П1","Х","П2"][a]:r===2?["1","2"][a]:String(a+1)}function yn(r,a){let s=[];for(let e of D(r,".market")){let f=D(e,".market__row");if(!f.length)continue;let p=L(e.querySelector(".market-title")),c=f.map(g=>{let b=L(g.querySelector(".market__row-text"));return D(g,".market-row-btn").map(v=>{let S=bt(L(v.querySelector(".market-row-btn__coef")));if(!S||v.hasAttribute("disabled"))return null;let z=v.getAttribute("title")||L(v.querySelector(".market-row-btn__text"));return{el:v,odd:S,label:z.replace(/\s+/g," ").trim(),rowLabel:b,locked:!1}})}),{sets:d}=ke(c);for(let g of d){let b=[...new Set(g.map(_=>_.rowLabel).filter(Boolean))],v=b.length<=1,S=v?"":(g[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],z=g.map(_=>({el:_.el,odd:_.odd,label:v?_.label:_.rowLabel||_.label,locked:!1}));s.push(Mt({scope:"board",title:p,period:v&&b[0]||"",line:S,kind:Et(p,z.length),outcomes:z,anchor:e,eventKey:a}))}}return s}var vn=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function kn(r){let a=D(r,".card__competitors .name .name, .half__names .name").map(e=>L(e));if(a.length<2)return null;let s=r.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Ce(s),key:zt(a[0],a[1]),home:a[0],away:a[1],href:s,live:/card--live/.test(r.className)||!!r.querySelector(".card__body-live"),time:L(r.querySelector(".header-left__time, .footer__time")),league:L(r.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:r}}function Te(r){let a=[];for(let s of D(r,".card")){if(ce(s))continue;let e=kn(s);if(e){for(let f of D(s,".card__body")){let p=L(f.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(f.className)?"отрезок":"");for(let c of D(f,".card__market")){let d=D(c,".coefficient-button");if(d.length<2)continue;let g=(vn.find(([v])=>v.test(d[0].className))||[])[1]||"other",b=d.map((v,S)=>{let z=/--is-blank/.test(v.className)?null:de(v);return z?{el:v,odd:z,label:g==="total"?["Меньше","Больше"][S]:pe(d.length,S,""),locked:/coefficient-button_locked/.test(v.className)}:null});b.some(v=>!v)||a.push(Mt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[g]||"Рынок",period:/^матч$/i.test(p)?"":p,line:L(c.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:g,outcomes:b,event:e,anchor:s,eventKey:e.key}))}}for(let f of D(s,".half__coef-buttons")){let p=D(f,".coef-buttons__button"),c=p.map((d,g)=>{let b=de(d.querySelector(".button__coef-title")||d);return b?{el:d,odd:b,label:pe(p.length,g,""),locked:!1}:null});c.length<2||c.some(d=>!d)||a.push(Mt({scope:"list",title:c.length===3?"Исход":"Победитель",kind:c.length===3?"1x2":"12",outcomes:c,event:e,anchor:s,eventKey:e.key}))}}}return a}function wn(r){if(!r?.body)return null;let a=g=>/^\d{1,3}\s?%$/.test(g),s=D(r,"h4").map(g=>{let b=[...g.nextElementSibling?.children||[]],v=L(b[0]),S=L(b[b.length-1]);return a(v)&&a(S)?{label:L(g),home:v.replace(/\s/g,""),away:S.replace(/\s/g,"")}:null}).filter(Boolean);if(!s.length)return null;let e=(r.body.innerText||r.body.textContent||"").replace(/\s+/g," "),f=[...e.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(g=>Number(g[1])),c=[...(e.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(g=>g[1].replace(/\s/g,""));return{names:L(r.querySelector("h3")).split(/\s+vs\s+/i).map(g=>g.trim()).filter(Boolean),rows:s,samples:f.slice(0,2),form:c.length>=2?{home:c[0],away:c[1]}:null}}function $n(r,a,s){if(!r||r.names.length<2)return r;let e=At(r.names[0],a)+At(r.names[1],s);return At(r.names[0],s)+At(r.names[1],a)<=e?r:{names:[r.names[1],r.names[0]],rows:r.rows.map(p=>({label:p.label,home:p.away,away:p.home})),samples:r.samples.slice().reverse(),form:r.form?{home:r.form.away,away:r.form.home}:null}}function zn(r){let a=r.querySelector("iframe.stats__iframe");if(!a)return null;try{return wn(a.contentDocument)}catch{return null}}function Mn(r){let a=["one","two"].map(p=>r.querySelector(`.event-live-center__team-widget--${p}`));if(!a[0]||!a[1])return null;let s=p=>{let c=p;try{c=p.querySelector("iframe")?.contentDocument?.body||p}catch{c=p}let d=D(c,'[class*="player"]').filter(b=>!D(b,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(b.className)),g=[];for(let b of d){let v=L(b).split(" ").filter(Boolean),S=v.find(_=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(_)&&/[A-Za-z]/.test(_));if(!S||g.some(_=>_.nick===S))continue;let z=v.filter(_=>/^\d{1,3}$/.test(_)).map(Number);g.push({nick:S,numbers:z.slice(0,4)})}return g.slice(0,5)},e=s(a[0]),f=s(a[1]);return e.length<3||f.length<3?null:{home:e,away:f}}var Le={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:ue,readMatch:Ne,readEsportsWidget:Mn,observeTargets(r){try{let a=r.querySelector("iframe.stats__iframe")?.contentDocument?.body;return a?[a]:[]}catch{return[]}},collect(r,a){if(ue(r)==="match"){let f=Ne(r,a)?.key||"";return[...xn(r,f),...yn(r,f),...Te(r)]}return Te(r)}};var Vt=(r,a)=>{try{return[...r.querySelectorAll(a)]}catch{return[]}};function Fe(r,a){let s=[r];if(a.shadow)for(let e of Vt(r,a.shadow))e.shadowRoot&&s.push(e.shadowRoot);return s}var Wt=r=>(r.defaultView?.innerWidth||0)>0,Sn='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function _n(r){let a=[],s=r.ownerDocument.createTreeWalker(r,4);for(;s.nextNode();){let e=s.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(e&&a.push(...e.split(" ")),a.length>5)return null}return a}function Nn(r,a){if(a.label){let s=r.querySelector(a.label),e=s?s.textContent.replace(/[ \s]+/g," ").trim():"";if(e&&!/^\d{1,3}[.,]\d{1,3}$/.test(e))return e}if(a.cell&&a.headerRow){let s=r.closest(a.cell),e=s?.parentElement,f=e?.parentElement?.querySelector(a.headerRow);if(f&&f!==e){let p=[...e.children].indexOf(s),c=f.children[p]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(c)return c.charAt(0).toUpperCase()+c.slice(1).toLowerCase()}}return""}function Tn(r,a){if(!a.cell||!a.lineCell)return"";let s=r.closest(a.cell);for(;s&&(s=s.previousElementSibling);){if(!s.matches?.(a.lineCell))continue;let e=s.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return e?e[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function Cn(r,a){if(r.disabled||r.hasAttribute?.("disabled"))return null;let s=a.value&&r.querySelector(a.value)||r,e=_n(s);if(!e||!e.length||e.join(" ").length>28)return null;let f=e[e.length-1];if(!(a.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(f))return null;let p=bt(f);if(!p||p>500||e.slice(0,-1).some(d=>/^\d{1,3}[.,]\d{1,3}$/.test(d)))return null;let c=e.slice(0,-1).join(" ");return!a.outcome&&/[+−]|^-/.test(c)?null:{odd:p,label:c}}function Ln(r,a){let s=[],e=new Set,f=Fe(r,a).flatMap(p=>Vt(p,a.outcome||Sn));for(let p of f){if(e.has(p)||a.skip&&p.closest(a.skip)||p.closest("#lz-root, #lz-marks"))continue;let c=Cn(p,a);if(c){if(!a.outcome&&Wt(r)){let d=p.getBoundingClientRect();if(d.width<26||d.width>320||d.height<16||d.height>90)continue}e.add(p),s.push({el:p,odd:c.odd,label:c.label||Nn(p,a),line:Tn(p,a),locked:!1})}}return a.outcome?s:s.filter(p=>!s.some(c=>c.el!==p.el&&c.el.contains(p.el)))}function Fn(r,a,s){if(a.row)return r.closest(a.row);let e=r.parentElement;for(let f=0;f<6&&e&&e!==e.ownerDocument.body;f+=1){let p=s(e);if(p>=2&&p<=16){if(!Wt(e.ownerDocument))return e;let c=e.getBoundingClientRect();if(c.height<=130&&c.width>=120)return e}if(p>16)break;e=e.parentElement}return null}var Oe=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function On(r,a){let s=a.length,e=r;for(let v=0;v<7;v+=1){let S=e.parentElement;if(!S||a.some(E=>!S.contains(E.el))||S.querySelectorAll("*").length>400||[...S.querySelectorAll('button, a, td, [role="button"]')].filter(E=>!a.some(O=>O.el===E||O.el.contains(E)||E.contains(O.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(L(E))).length>s)break;e=S}let f=a[0].el,p=[],c=e.ownerDocument.createTreeWalker(e,4);for(;c.nextNode();){let v=c.currentNode;if(f.contains(v))break;let S=v.textContent.replace(/[ \s]+/g," ").trim();S.length<2||S.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(S)||/\d{1,2}:\d{2}|^\d|['′]$/.test(S)||Oe.test(S)||p.push(S)}let d=p.slice(-2),g=p.map(v=>v.split(/\s+[—–-]\s+/)).filter(v=>v.length===2).pop();if(g&&(d=g),d.length<2||d[0]===d[1])return null;let b=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:zt(d[0],d[1]),home:d[0],away:d[1],href:b,live:!1,time:"",league:"",card:e}}function An(r,a,s){if(!a.names)return On(r,s);let e=a.event&&r.closest(a.event)||r,f=[...new Set(Vt(e,a.names).map(d=>L(d)).filter(Boolean))],p=f;if(f.length===1&&(p=f[0].split(/\s+[—–-]\s+/)),p.length<2||!p[0]||!p[1])return null;let c=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:zt(p[0],p[1]),home:p[0],away:p[1],href:c,live:!1,time:"",league:"",card:e}}function En(r){let s=String(r.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!s)return null;let e=[s[1].trim(),s[2].trim()];return e.some(f=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(f))?null:e}function Ae(r,a={}){function s(z,_){return a.matchUrl&&a.matchUrl.test(_?.pathname||"")||a.matchPage&&z.querySelector(a.matchPage)?"match":"list"}function e(z){let _=z.defaultView;if(!_||!Wt(z))return[];let E=[];for(let O of z.querySelectorAll("h1, h2, h3, div, span, p, a")){if(O.children.length)continue;let q=L(O);if(q.length<3||q.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(q)||/\d{1,2}[:.]\d{2}/.test(q)||Oe.test(q))continue;let U=O.getBoundingClientRect();if(!(U.top<60||U.top>450||U.width<30||parseFloat(_.getComputedStyle(O).fontSize)<15)&&(E.includes(q)||E.push(q),E.length===2))break}return E}function f(z,_){if(s(z,_)!=="match")return null;let E=a.matchNames?Vt(z,a.matchNames).map(q=>L(q)).filter(Boolean):[];if(E.length===1&&(E=E[0].split(/\s+[—–-]\s+/)),E.length<2&&(E=En(z)||[]),E.length<2&&(E=e(z)),E.length<2)return null;let O=a.matchLeague?L(z.querySelector(a.matchLeague)):"";return{book:r.name,id:(String(_?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:zt(E[0],E[1]),home:E[0],away:E[1],sport:Nt(_?.pathname,O,z.title,L(z.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:O,start:"",live:/(^|\/)live(\/|$)/i.test(_?.pathname||"")?!0:null,form:{home:"",away:""},url:_?.href||""}}function p(z,_){return!z||!_?"":_.startsWith("attr:")?String(z.getAttribute(_.slice(5))||"").trim():L(z.querySelector(_))}function c(z,_){if(!Wt(_))return[z];let E=z.map(q=>{let U=q.el.getBoundingClientRect();return{cell:q,top:U.top,left:U.left}}).sort((q,U)=>Math.abs(q.top-U.top)>8?q.top-U.top:q.left-U.left),O=[];for(let q of E){let U=O[O.length-1];U&&Math.abs(U.top-q.top)<=8?U.cells.push(q.cell):O.push({top:q.top,cells:[q.cell]})}return O.map(q=>q.cells)}let d=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],g=z=>(d.find(([_])=>_.test(z.join("/").toLowerCase()))||[])[1]||"other";function b(z,_){let E=s(z,_),O=E==="match"&&a.match?{...a,...a.match}:a;return v(z,_,E,O)}function v(z,_,E,O){let q=Ln(z,O);if(q.length<2)return[];let U=new Set(q.map(F=>F.el)),ut=F=>{let N=0;for(let A of U)F.contains(A)&&(N+=1);return N},K=new Map;for(let F of q){let N=Fn(F.el,O,ut);N&&(K.has(N)||K.set(N,[]),K.get(N).push(F))}let pt=E==="match"?f(z,_):null,W=[];for(let[F,N]of K){let A=E==="match"?null:An(F,O,N),P=O.group?F.closest(O.group):null,B=p(P,O.groupTitle),Q=p(P,O.groupPeriod),tt=O.visualRows?c(N,z):[N],rt=0;for(let ot of tt)for(let st of we(ot).sets){let X=rt===0,H=st.length,ct=H===3?["П1","Х","П2"]:["1","2"],kt=st.map((nt,et)=>({...nt,label:nt.label||ct[et]||String(et+1)})),ft=X&&H===3?"Исход":X?"Победитель":`Рынок ${rt+1}`,it=X?H===3?"1x2":"12":"other";B&&(ft=B,it=Et(B,H),it==="other"&&(it=g(kt.map(nt=>nt.label)))),H===3&&kt.every(nt=>/\sили\s/i.test(nt.label))&&(it="dc"),W.push(Mt({scope:E==="match"?"board":"list",title:ft,period:Q,line:st[0].line&&st.every(nt=>nt.line===st[0].line)?st[0].line:"",kind:it,outcomes:kt,event:A,anchor:F,eventKey:A?.key||pt?.key||`row${W.length}`})),rt+=1}}return W}let S=z=>Fe(z,a).slice(1);return{id:r.id,name:r.name,hosts:r.hosts,generic:!0,pageType:s,readMatch:f,collect:b,observeTargets:S,readEsportsWidget:()=>null}}var Ee={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},Be={fonbet:Ee,pari:Ee,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function qe(r){let a=xe(r);return a?a.id==="winline"?{adapter:Le,book:a}:{adapter:Ae(a,Be[a.id]||{}),book:a}:null}var Kt=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #8b8fa3;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #73778c;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var Pe=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(r,a,...s){let[e,...f]=r.split("."),p=document.createElement(e||"div");f.length&&(p.className=f.join(" "));for(let[c,d]of Object.entries(a||{}))if(!(d==null||d===!1))if(c==="class")p.className=[p.className,d].filter(Boolean).join(" ");else if(c==="style")p.style.cssText=d;else if(c==="text")p.textContent=d;else{if(c==="html")throw new Error("html запрещён");c.startsWith("data-")||c.startsWith("aria-")||c==="role"||c==="title"||c==="type"||c==="href"||c==="target"||c==="rel"||c==="placeholder"||c==="value"||c==="for"||c==="name"||c==="maxlength"||c==="autocomplete"||c==="spellcheck"||c==="tabindex"?p.setAttribute(c,d===!0?"":String(d)):c==="disabled"||c==="hidden"||c==="checked"||c==="selected"?p[c]=!!d:p[c]=d}return Ie(p,s),p}function Ie(r,a){for(let s of a)s==null||s===!1||(Array.isArray(s)?Ie(r,s):r.appendChild(s instanceof Node?s:document.createTextNode(String(s))))}var je="http://www.w3.org/2000/svg";function J(r,a=16){let s=document.createElementNS(je,"svg");s.setAttribute("viewBox","0 0 20 20"),s.setAttribute("width",a),s.setAttribute("height",a),s.setAttribute("fill","none"),s.setAttribute("stroke","currentColor"),s.setAttribute("stroke-width","1.7"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("aria-hidden","true");for(let e of Pn[r]||[]){let f=document.createElementNS(je,"path");f.setAttribute("d",e),s.appendChild(f)}return s}var Pn={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function Re(){let r=document.createElement("div");r.id="lz-marks",r.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let a=r.attachShadow({mode:"open"});a.appendChild(t("style",{text:Kt+Pe}));let s=t("div.layer"),e=t("div.tip");a.append(s,e);let f=new Map,p=new Set,c=0,d=null,g=null,b=new IntersectionObserver(F=>{for(let N of F)N.isIntersecting?p.add(N.target):(p.delete(N.target),f.get(N.target)?.node.classList.remove("on"));S()},{rootMargin:"120px"});function v(){r.isConnected||document.documentElement.appendChild(r)}function S(){c||(c=requestAnimationFrame(()=>{c=0,E()}))}let z=(F,N)=>{for(let A=N;A;A=A.parentNode||A.host)if(A===F)return!0;return!1};function _(F,N){let A=N.left+N.width/2,P=N.top+N.height/2;if(A<0||P<0||A>window.innerWidth||P>window.innerHeight)return!1;let B=document.elementFromPoint(A,P);for(;B?.shadowRoot?.elementFromPoint;){let Q=B.shadowRoot.elementFromPoint(A,P);if(!Q||Q===B)break;B=Q}return!!B&&B!==F&&!z(F,B)&&!z(B,F)}function E(){for(let F of p){let N=f.get(F);if(!N)continue;if(!F.isConnected){O(F);continue}let A=F.getBoundingClientRect();if(A.width<6||A.height<6||_(F,A)){N.node.classList.remove("on");continue}let P=Math.round(A.left),B=Math.round(A.top),Q=Math.round(A.width),tt=Math.round(A.height);(N.x!==P||N.y!==B)&&(N.node.style.transform=`translate3d(${P}px, ${B}px, 0)`,N.x=P,N.y=B),(N.w!==Q||N.h!==tt)&&(N.node.style.width=`${Q}px`,N.node.style.height=`${tt}px`,N.w=Q,N.h=tt,N.node.classList.toggle("small",tt<26)),N.node.classList.add("on")}d&&U()}function O(F){let N=f.get(F);N&&(b.unobserve(F),p.delete(F),N.node.remove(),f.delete(F))}function q(F){v();let N=new Map;for(let A of F)A.el?.isConnected&&N.set(A.el,A);for(let A of[...f.keys()])N.has(A)||O(A);for(let[A,P]of N){let B=f.get(A);if(!B){let tt=t("div.mark"),rt=parseFloat(getComputedStyle(A).borderTopLeftRadius);tt.style.borderRadius=`${Number.isFinite(rt)&&rt>0?Math.min(rt,16):6}px`;let ot=t("span.chip");tt.appendChild(ot),s.appendChild(tt),B={node:tt,chip:ot,sig:""},f.set(A,B),b.observe(A)}let Q=`${P.frame?1:0}|${P.selected?1:0}|${P.tone||""}|${P.chip||""}`;Q!==B.sig&&(B.sig=Q,B.node.classList.toggle("frame",!!P.frame),B.node.classList.toggle("selected",!!P.selected),B.node.classList.toggle("pos",P.tone==="pos"&&!!P.frame),B.chip.hidden=!P.chip,B.chip.textContent=P.chip||"",B.chip.className=`chip${P.tone&&P.tone!=="accent"?" "+P.tone:""}`)}S()}function U(){if(!d?.isConnected)return K();let F=d.getBoundingClientRect(),N=264,A=e.offsetHeight||140,P=F.left+F.width/2-N/2;P=Math.max(8,Math.min(P,window.innerWidth-N-8)),g&&P+N>g.left-8&&P<g.right&&(P=Math.max(8,g.left-N-10));let B=F.bottom+10;B+A>window.innerHeight-8&&(B=F.top-A-10),B<8&&(B=8),e.style.transform=`translate3d(${Math.round(P)}px, ${Math.round(B)}px, 0)`}function ut(F,N){v(),d=F,e.replaceChildren(N),U(),e.classList.add("on")}function K(){d=null,e.classList.remove("on")}function pt(F){g=F}function W(F){r.setAttribute("data-theme",F)}return window.addEventListener("scroll",S,{capture:!0,passive:!0}),window.addEventListener("resize",S,{passive:!0}),setInterval(()=>{f.size&&!document.hidden&&S()},700),{set:q,schedule:S,showTip:ut,hideTip:K,setTheme:W,setAvoid:pt,get tipTarget(){return d},count:()=>f.size}}var De=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var Xt=r=>Math.min(.999,Math.max(.001,r));function fe(r,a,s=0,e=0){let f=Math.ceil(a/2),p=new Map,c=(d,g)=>{if(d>=f)return 1;if(g>=f)return 0;let b=d*16+g;return p.has(b)||p.set(b,r*c(d+1,g)+(1-r)*c(d,g+1)),p.get(b)};return c(s,e)}function Yt(r,a){let s=.001,e=.999;for(let f=0;f<50;f++){let p=(s+e)/2;r(p)<a?s=p:e=p}return(s+e)/2}function In(r,a){let s=Xt(r);return Math.ceil(a/2)<=1?s:Yt(e=>fe(e,a),s)}function Gt(r,a,s,e=new Map){if(a>=4)return[1,0];if(s>=4)return[0,0];if(a===3&&s===3)return[0,1];let f=a*8+s;if(!e.has(f)){let[p,c]=Gt(r,a+1,s,e),[d,g]=Gt(r,a,s+1,e);e.set(f,[r*p+(1-r)*d,r*c+(1-r)*g])}return e.get(f)}function Ue(r){let[a,s]=Gt(r,0,0);return a/(1-s)}function Zt(r,a,s){if(a=Math.max(0,Math.floor(a)),s=Math.max(0,Math.floor(s)),Math.min(a,s)>=12){let p=Math.floor((Math.min(a,s)-12)/3),c=a-12-3*p,d=s-12-3*p,[g,b]=Gt(r,c,d);return g+b*Ue(r)}let e=new Map,f=(p,c)=>{if(p>=13)return 1;if(c>=13)return 0;if(p===12&&c===12)return Ue(r);let d=p*32+c;return e.has(d)||e.set(d,r*f(p+1,c)+(1-r)*f(p,c+1)),e.get(d)};return f(a,s)}function Rn(r){return Yt(a=>Zt(a,0,0),Xt(r))}var Dn=24,Ht=Array.from({length:101},(r,a)=>(a+.5)/101),We=null;function Ve(r,a){let s=Ht.map(c=>(r-1)*Math.log(c)+(a-1)*Math.log(1-c)),e=Math.max(...s),f=s.map(c=>Math.exp(c-e)),p=f.reduce((c,d)=>c+d,0);return f.map(c=>c/p)}function Ke(r,a,s=0,e=0){if(!Number.isFinite(a))return Zt(r,s,e);let f=Ve(r*a+s,(1-r)*a+e);return!s&&!e?(We||=Ht.map(p=>Zt(p,0,0)),f.reduce((p,c,d)=>p+c*We[d],0)):f.reduce((p,c,d)=>p+c*Zt(Ht[d],s,e),0)}function Un(r,a){return Number.isFinite(a)?Yt(s=>Ke(s,a),Xt(r)):Rn(r)}var Wn={cs:8,dota:1/0};function Ze(r,a,s,e=0,f=0){return Number.isFinite(a)?Ve(r*a+e,(1-r)*a+f).reduce((c,d,g)=>c+d*fe(Ht[g],s,e,f),0):fe(r,s,e,f)}function Vn(r,a,s){return Number.isFinite(s)?Yt(e=>Ze(e,s,a),Xt(r)):In(r,a)}function Kn(r,a){let s=Math.max(r,a),e=Math.min(r,a);return e<12?s>=13:s-12-3*Math.floor((e-12)/3)>=4}function Ge({pre:r,bo:a=3,maps:s=[0,0],rounds:e=null,game:f="cs",kappa:p=Dn,kappaMap:c=Wn[f]??1/0}){let d=Math.ceil(a/2),[g,b]=(s||[0,0]).map(q=>Math.max(0,Number(q)||0));if(g>=d)return{p:1,map:null};if(b>=d)return{p:0,map:null};let v=Vn(r,a,c),S=(q,U)=>Ze(v,c,a,q,U),[z,_]=Array.isArray(e)&&e.length===2?e.map(Number):[NaN,NaN];if(!Number.isFinite(z)||!Number.isFinite(_)||z===0&&_===0||Kn(z,_))return{p:S(g,b),map:null};let E=Number.isFinite(c)?(v*c+g)/(c+g+b):v,O=Ke(Un(E,p),p,z,_);return{p:O*S(g+1,b)+(1-O)*S(g,b+1),map:O}}var G=(r,a=0)=>xt(r,a),St=r=>`${r>0?"+":r<0?"−":""}${Math.abs(r).toFixed(1)}`;function He({bus:r,actions:a,brand:s}){let e=document.createElement("div");e.id=r.rootId,e.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let f=e.attachShadow({mode:"open"});f.appendChild(t("style",{text:Kt+De}));let p=t("span.dot"),c=t("button.fab",{type:"button","data-act":"toggle",title:`${s.name}: открыть панель`,"aria-label":`${s.name}: открыть панель`},J("lens",18),t("span",{text:s.name}),p),d=t("div.tabs",{role:"tablist"}),g=t("div.body"),b=t("div.foot"),v=t("small"),S=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),z=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),_=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},J("gear")),E=t("div.head",{},t("div.brand",{},t("span.logo",{},J("lens",15)),t("span",{text:s.name}),v),t("span.grow"),z,S,_,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},J("close"))),O=t("section.panel",{hidden:!0,role:"dialog","aria-label":s.name},E,d,g,b);f.append(c,O);let q=()=>{e.isConnected||document.documentElement.appendChild(e)};q(),new MutationObserver(q).observe(document.documentElement,{childList:!0});let U="",ut=null,K=new Map,pt=o=>{for(let n of o.composedPath()){if(n===e)break;if(n?.dataset?.act)return n}return null},W=null;r.on("ui:pointerdown",o=>{if(o.button!==0)return;let n=o.composedPath(),l=n.includes(c),h=n.includes(E)&&!n.some(x=>x?.dataset?.act);if(!l&&!h)return;let w=l?c:O,y=w.getBoundingClientRect();W={target:w,key:l?"fab":"panel",sx:o.clientX,sy:o.clientY,ox:y.left,oy:y.top,moved:!1},r.setDragging(!0)}),r.on("drag:move",o=>{if(!W)return;let n=o.clientX-W.sx,l=o.clientY-W.sy;!W.moved&&Math.hypot(n,l)<5||(W.moved=!0,W.target.classList.add("dragging"),N(W.target,W.ox+n,W.oy+l))}),r.on("drag:end",()=>{if(W){if(r.setDragging(!1),W.target.classList.remove("dragging"),W.moved){let o=W.target.getBoundingClientRect();a.savePosition(W.key,{left:o.left,top:o.top}),F=!0,setTimeout(()=>{F=!1},60)}W=null}});let F=!1;function N(o,n,l){let h=o.offsetWidth||120,w=o.offsetHeight||40,y=Math.max(6,Math.min(n,window.innerWidth-h-6)),x=Math.max(6,Math.min(l,window.innerHeight-Math.min(w,60)-6));o.style.left=`${Math.round(y)}px`,o.style.top=`${Math.round(x)}px`,o.style.right="auto"}r.on("ui:click",o=>{if(F)return;let n=pt(o);if(!n||n.disabled)return;o.preventDefault();let l=n.dataset.act;if(l==="toggle")return Lt();if(l==="close")return dt();let h=a[l];h&&h(n.dataset.arg,n,f)}),r.on("ui:keydown",o=>{if(o.key==="Escape"&&dt(),o.key==="Enter"){let n=o.composedPath()[0];n?.dataset?.enter&&a[n.dataset.enter]?.(n.value,n,f)}});let A=(o,n)=>t("span.form",{},[...String(o||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),n);function P(o){let n=o.live,l=n?t("div.center",{},n.score?.length===2?t("span.score",{text:`${n.score[0]} : ${n.score[1]}`}):null,t("span.badge.live",{text:n.state||"Лайв"})):t("div.center",{},t("span",{text:o.start||"до матча"})),h=n?.periods?.length?t("div.periods",{text:n.periods.map(y=>y.raw?`${y.label} ${y.raw}`:`${/^\d+$/.test(y.label)?`${y.label}-й отрезок`:y.label} ${y.home}:${y.away}`).join(" · ")}):null,w=n?.extras?.length?t("div.periods",{text:n.extras.map(y=>`${y.kind} ${y.home}:${y.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:o.league||o.sportName||"",title:o.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:o.home,title:o.home}),o.form?.home?A(o.form.home):null),l,t("div.team.away",{},t("b",{text:o.away,title:o.away}),o.form?.away?A(o.form.away):null)),h,w)}function B(o){let n=o.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),Number.isFinite(o.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${G(o.margin,1)}`}):null),o.rows.map(l=>{let h=n&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:Z(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},G(n&&Number.isFinite(l.model)?l.model:l.fair),h!=null&&Math.abs(h)>=.05?t(`small${h>0?".pos":".neg"}`,{text:`${St(h)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),n?t("span.model",{text:"оценка модели"}):null))}function Q(o){let n=o.analysis;if(n.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},n.steps.map((x,k)=>t(`div.step${k===n.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:x})))));if(n.status==="error")return t("div.card",{},t("div.note.warn",{},J("alert"),t("span",{text:n.error})),n.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},J("gear"),"Открыть настройки")):null);if(n.status!=="done"||!n.result)return null;let l=n.result,h={home:o.match?.home,away:o.match?.away,draw:"ничья"}[l.lean],w=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:o.match?.home,away:o.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,y=new Map((l.facts||[]).map(x=>[x.id,x]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:h?`Данные сдвигают оценку в сторону: ${h}`:w?`Данные слегка склоняют в сторону: ${w.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),w?t("div.note",{style:"margin-bottom:10px"},J("info"),t("span",{text:`Модель предложила сдвиг на ${w.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(x=>t(`li.factor${x.side==="home"?".home":x.side==="away"?".away":""}`,{},t("div",{},t("p",{text:x.text}),t("div.src",{},(x.facts||[]).map(k=>y.get(k)).filter(Boolean).map(k=>t("span.tag",{text:`${k.id} · ${k.source}`,title:k.text}))))))):null,l.scenarios?.length?t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Как может пойти игра"})),t("ul.facts",{},l.scenarios.map(x=>t("li",{},t("span",{text:x.text})," ",t("em",{text:`— ${x.facts.join(", ")}`}))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},J("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:K.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(x=>t("li",{},t("b",{text:x.id}),t("span",{},x.text," ",t("em",{text:`— ${x.source}`})))))),tt(l.research),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function tt(o){return o?o.skipped==="plan"?t("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):o.sources?.length?t("div.hint",{style:"margin-top:8px"},`${o.note} Прочитано: `,o.sources.map((n,l)=>[l?", ":"",t("a",{href:n.url,target:"_blank",rel:"noopener",text:n.domain})])):o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null:null}function rt(o){let n=o.compare?.consensus||o.analysis?.result?.consensus||o.consensus;if(!n?.consensus||!o.line?.rows?.length)return null;let l=n.consensus.length===2&&o.line.rows.length===3;if(!l&&o.line.rows.length!==n.consensus.length)return null;let h=l?o.line.overtime:null,w=h?h.rows:l?[o.line.rows[0],o.line.rows[2]].map(k=>({...k,odd:null,fair:null})):o.line.rows,y=o.match?.sport==="mma",x=n.updated?new Date(n.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?y?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${n.count} контор`})),w.map((k,M)=>{let C=n.consensus[M],R=k.odd?k.odd*C-1:0,$=Number.isFinite(k.fair)?(k.fair-C)*100:0;return t("div.prob",{},t("span.name",{text:k.name,title:k.name}),t("span.odd",{text:Z(1/C),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(C*100)}%`}),t("u",{style:`left:${Math.round((k.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},G(C),R>.005?t("small.pos",{text:`кэф выше рынка ${St(R*100)}%`}):Math.abs($)>=2?t(`small${$>0?".neg":""}`,{text:`${St($)} п.п. к рынку`,title:$>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!h?null:t("span.model",{text:h?`шанс по рынку «${h.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l&&y?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?h?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${n.pinnacle?`Pinnacle ${n.pinnacle.map(Z).join(" / ")}. `:""}${n.betfair?`Betfair ${n.betfair.map(Z).join(" / ")}. `:""}Цены ${n.count} контор без маржи${x?`, обновлено в ${x}`:""}${n.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let ot=new Map;function st(o,n){let l=o.match?.live;if(!l||!["cs","dota"].includes(n.game)||l.score?.length!==2)return null;let h=l.score.map(Number),w=Number(n.bo)||3;if(h.some(k=>!Number.isFinite(k)||k<0)||Math.max(...h)>=Math.ceil(w/2))return null;let y=n.game==="cs"&&l.rounds?.length===2&&l.rounds.every(k=>/^[0-9]{1,2}$/.test(String(k)))?l.rounds.map(Number):null,x=`${n.p1}|${w}|${h}|${y}`;return ot.has(x)||(ot.size>50&&ot.clear(),ot.set(x,{...Ge({pre:n.p1,bo:w,maps:h,rounds:y,game:n.game}),bo:w,maps:h,rounds:y})),ot.get(x)}function X(o){let n=o.compare?.model||o.analysis?.result?.model||o.model;if(!n?.p1||!o.line?.rows?.length)return null;let l=o.line.rows.length===3&&(n.overtime||n.drawless);if(!l&&o.line.rows.length!==2)return null;let h=l?o.line.overtime:null,w=h?h.rows:l?[o.line.rows[0],o.line.rows[2]].map(T=>({...T,fair:null})):o.line.rows,y=st(o,n),x=y?[y.p,1-y.p]:[n.p1,n.p2],k=n.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${n.samples} матчей у менее опытного игрока)`:n.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${n.samples} боёв в UFC у менее опытного бойца)`:n.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${n.samples} игр у менее опытной команды)`:n.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${n.samples} ${lt(n.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${n.samples} ${lt(n.samples,"карта","карты","карт")} у менее опытной команды)`,M=n.backtest,C=(M?.calibration||[]).filter(T=>[60,70,80].includes(T.threshold)),R=M?.labels?.[n.confidence],$=(R?`С подписью «${n.confidence}» на проверке сбывалось ${G(R.hit/100,1)} (${R.n} ${lt(R.n,"матч","матча","матчей")}). `:"")+(C.length?`На проверке ${M.test} сыгранных матчей: ${C.map(T=>`при уверенности ≥${T.threshold}% сбывалось ${T.hit}%`).join(", ")}`:M?`На проверке ${M.test} матчей угадано ${Math.round(M.acc*100)}%`:"Точность ещё измеряется");return t("div.card",{},t("div.kicker",{},t("span",{text:y?`Модель по счёту · bo${y.bo}`:l?n.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:y?`до матча: ${n.confidence}`:`уверенность: ${n.confidence}`})),w.map((T,I)=>{let j=x[I],V=Number.isFinite(T.fair)?(j-T.fair)*100:0;return t("div.prob",{},t("span.name",{text:T.name,title:T.name}),t("span.odd",{text:Z(1/j),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(j*100)}%`}),t("u",{style:`left:${Math.round((T.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},G(j),Math.abs(V)>=3?t(`small${V>0?".pos":".neg"}`,{text:`${St(V)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:y?"шанс серии по счёту":"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),y?t("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${y.maps.join(":")}${y.rounds?`, на карте ${y.rounds.join(":")} — шанс текущей карты ${G(y.map??.5)}`:""}. До матча модель давала ${G(n.p1)} / ${G(n.p2)}.`}):null,ft(n,w),n.factors?.length?t("ul.facts",{style:"margin-top:8px"},n.factors.slice(0,n.sport==="mma"?12:4).map(T=>t("li",{},t("span",{text:T})))):null,t("div.hint",{style:"margin-top:8px",text:y?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${n.game==="cs"?" и раунды":""} уточняют силу команд. ${n.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${k}. ${$}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function H(o,n,l,h){let w=o.bookLines;if(!w)return null;let y=k=>k>0?`+${k}`:`${k}`,x=(k,M,C,R)=>t("li",{},t("span",{text:`${k}: Fonbet ${M.map(Z).join(" / ")}, честно ${C.map($=>$?Z($):"—").join(" / ")}`}),h&&Math.abs(R)>=5?t(`small${R>0?".pos":".neg"}`,{text:` ${St(R)} п.п. к первой стороне`}):null);return t("ul.facts",{style:"margin-top:8px"},w.handicap?x(`Фора ${n} ${y(w.handicap.line)} / ${l} ${y(-w.handicap.line)}`,w.handicap.odds,w.handicap.fair,w.handicap.gap):null,w.total?x(`Тотал ${w.total.line} больше / меньше`,w.total.odds,w.total.fair,w.total.gap):null)}function ct(o){let n=o.live;if(!n)return null;if(n.error)return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"})),t("div.hint",{text:n.error}));let[l,h]=n.names,w=$=>$?Z($):"—",y=n.book&&(n.prior.source==="line"||n.prior.source==="model"),x=n.left>0?`${n.period>n.format.periods?"ОТ":`${n.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(n.left))} мин`:"конец игры",k=($,T,I,j,V,ht)=>T.length?t("details",{"data-key":`live-${$}`,open:K.get(`live-${$}`)||!1},t("summary",{text:$}),t("ul.facts",{},T.map(gt=>t("li",{},t("span",{text:`${V(gt)} — ${w(gt[I])} · ${ht(gt)} — ${w(gt[j])}`}))))):null,M=$=>$>0?`+${$}`:`${$}`,C=n.quarter,R=C&&C.left>0?`${C.index}-я четверть (${C.score.join(":")}, осталось ≈${Math.max(1,Math.round(C.left))} мин): ${l} ${w(C.probs[0]?1/C.probs[0]:null)} · ничья ${w(C.draw?1/C.draw:null)} · ${h} ${w(C.probs[1]?1/C.probs[1]:null)}; разница ${C.expMargin>=0?l:h} ${Math.abs(C.expMargin).toFixed(1)}, тотал четверти ≈${C.projTotal}.`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${n.score.join(":")} · ${x}`})),n.names.map(($,T)=>{let I=n.probs[T],j=n.book?n.book[T]:null,V=y&&Number.isFinite(j)?(I-j)*100:0;return t("div.prob",{},t("span.name",{text:$,title:$}),t("span.odd",{text:Z(1/I),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(I*100)}%`}),Number.isFinite(j)?t("u",{style:`left:${Math.round(j*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},G(I),Math.abs(V)>=3?t(`small${V>0?".pos":".neg"}`,{text:`${St(V)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (с ОТ)"}),n.book?t("span.model",{text:"шанс по цене этой конторы"}):null),H(n,l,h,y),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Ожидаемая итоговая разница: ${n.expMargin>=0?l:h} ${Math.abs(n.expMargin).toFixed(1)} (разброс ±${n.sd}). Тотал ≈${n.projTotal} (±${n.sdTotal}).`})),R?t("li",{},t("span",{text:R})):null),k("Фора — честные кэфы",n.handicap,"home","away",$=>`${l} ${M($.line)}`,$=>`${h} ${M(-$.line)}`),k("Тотал матча — честные кэфы",n.total,"over","under",$=>`больше ${$.line}`,$=>`меньше ${$.line}`),k("Тотал четверти — честные кэфы",n.quarterTotal,"over","under",$=>`больше ${$.line}`,$=>`меньше ${$.line}`),t("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${n.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${n.prior.note}.${y?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function kt(o){let n=o.verdict;return n?.lines?.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Итог"}),t("span.badge",{text:n.best?`перевес ${Math.round(n.best.edge*100)}%`:"без перевеса"})),t("ul.facts",{},n.lines.map(l=>t("li",{},t("span",{text:l})))),n.track?t("div.hint",{style:"margin-top:6px",text:n.track}):null,o.analysis.status!=="done"?t("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ft(o,n){let l=o.durations;if(o.sport!=="mma"||!l)return null;let h=y=>y?Z(y):"—",w=n.map(y=>y.name);return t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Честные кэфы"}),t("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),t("ul.facts",{},t("li",{},t("span",{text:`Победа: ${w[0]||"первый"} ${h(o.fair?.p1)} · ${w[1]||"второй"} ${h(o.fair?.p2)}`})),l.lines.map(y=>t("li",{},t("span",{text:`Тотал ${y.line} раунда: больше ${h(y.over)} · меньше ${h(y.under)}`}))),t("li",{},t("span",{text:`Дойдёт до решения: да ${h(l.decision.yes)} · нет ${h(l.decision.no)}`})),t("li",{},t("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),t("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function it(o){let l=((o.compare?.model||o.analysis?.result?.model||o.model)?.profiles||[]).filter(h=>h?.lines?.length);return l.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Профили"}),t("span.badge",{text:"модель Линзы"})),l.map((h,w)=>t("details",{"data-key":`profile-${w}`,open:K.get(`profile-${w}`)??w===0},t("summary",{text:h.name}),t("ul.facts",{},h.lines.map(y=>t("li",{},t("span",{text:y})))))),t("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function nt(o){let n=o.facts;if(!n?.facts?.length)return null;let l=n.facts.filter(x=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(x.text)),h=n.facts.filter(x=>!l.includes(x)&&/состав|стартов/i.test(x.text)),w=n.facts.filter(x=>!l.includes(x)&&!h.includes(x)),y=(x,k,M)=>k.length?t("details",{"data-key":`facts-${x}`,open:M||K.get(`facts-${x}`)||!1},t("summary",{text:`${x} (${k.length})`}),t("ul.facts",{},k.map(C=>t("li",{},t("span",{text:C.text}))))):null;return t("div.card",{},t("div.kicker",{},t("span",{text:"Составы, травмы, форма"}),t("span.badge",{text:n.source||n.facts[0].source||"источник"})),y("Травмы и отсутствующие",l,!0),y("Составы",h,!0),y("Форма, таблица, очные встречи",w,!l.length&&!h.length),t("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",n.url?t("a",{href:n.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let et=o=>`${Math.round(o).toLocaleString("ru-RU")} ₽`,lt=(o,n,l,h)=>{let w=o%100,y=o%10;return w>10&&w<20?h:y===1?n:y>=2&&y<=4?l:h},mt=o=>(o.erid?["Реклама",o.legal,`erid ${o.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",o.legal].filter(Boolean).join(" · "))+" · 18+",wt=(o,n)=>t("a.btn.ghost.small",{href:o.go?`${o.go}?s=panel`:o.url,target:"_blank",rel:"noopener sponsored"},J("link",13),n||`Открыть у ${o.name}`),$t=o=>o.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":o.code,title:o.bonus||"Скопировать промокод"},`Промокод ${o.code}`):null;function te(o){let n=(o.partners||[]).filter(l=>l.url||l.code);return n.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:n.length===1?`Промокод ${n[0].name}`:"Промокоды контор"})),n.map(l=>t("div.partner",{},t("div.partner-text",{},t("b",{text:l.name}),l.bonus?t("span",{text:` — ${l.bonus}`}):null),t("div.partner-links",{},$t(l),l.url?wt(l):null),t("div.hint",{text:mt(l)})))):null}function ee(o,n={}){if(o.status==="idle")return null;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let l=o.labels||[];if(!o.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:o.note||"В открытых линиях этой пары нет."}));let h=l.map(($,T)=>Math.max(...o.rows.map(I=>I.odds[T]||0))),w=Object.fromEntries((n.partners||[]).map($=>[$.id,$])),y=$=>$.book&&$.book!==n.bookId&&!$.sharp&&w[$.book]||null,x=n.stake||1e3,k=o.rows.find($=>$.here)||o.rows[0],C=l.map(($,T)=>{let I=k?.odds?.[T],j=o.rows.filter(V=>V!==k&&!V.sharp&&V.odds[T]).sort((V,ht)=>ht.odds[T]-V.odds[T])[0];return!I||!j||j.odds[T]<=I?null:{label:$,row:j,odd:j.odds[T],mine:I,gain:(j.odds[T]-I)*x}}).filter(Boolean).sort(($,T)=>T.gain-$.gain)[0],R=o.rows.map(y).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),l.map($=>t("th",{text:$}))),o.rows.map($=>{let T=y($);return t("tr",{},t("td.name",{title:$.sharp?"Цена с мирового рынка, для сравнения":""},$.name,T?t("div.partner-links",{},T.url?wt(T):null,$t(T)):null),$.odds.map((I,j)=>t(`td${I&&I===h[j]&&o.rows.length>1?".best":""}`,{text:I?Z(I):"—"})))})),C&&C.gain>=1?t("div.gain",{},`На «${C.label}» у ${C.row.name} кэф ${Z(C.odd)} против ${Z(C.mine)} здесь: со ставки ${et(x)} выигрыш больше на `,t("b",{text:et(C.gain)}),"."):null,R.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(R.map(mt))].join(" ")}):null,o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null)}function ne(o){let n=[],l=(w,y,x)=>n.push(t("dt",{text:w}),t(`dd${x?"."+x:""}`,{text:y}));Number.isFinite(o.fair)?(l("Шанс по линии без маржи",G(o.fair,1)),l("Кэф без маржи конторы",Z(o.fairOdd)),l("Маржа конторы в этом рынке",G(o.margin,1))):l("Заложено в кэфе (с маржой)",G(1/o.odd,1)),Number.isFinite(o.model)&&(l("Оценка модели",G(o.model,1)),l("Ожидание на рубль по модели",`${St(o.ev*100)}%`,o.ev>.005?"pos":o.ev<-.005?"neg":"")),o.best&&l(`Лучшая цена: ${o.best.name}`,Z(o.best.odd),o.best.odd>o.odd?"pos":"");let h=o.best?.partner&&(o.best.partner.url||o.best.partner.code)?o.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:o.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},J("close",13))),t("div.pick-head",{},t("span.big",{text:Z(o.odd)}),t("span.what",{text:o.label,title:o.label})),t("dl.kv",{},n),o.note?t("div.hint",{style:"margin-top:8px",text:o.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!o.canAdd,title:o.canAdd?"":"Нужен рынок с полным набором исходов"},J("plus",14),o.inExpress?"Уже в экспрессе":"В расчёт экспресса")),h?t("div.partner",{style:"margin-top:10px"},o.best.gain>=1?t("div.gain",{},`У ${h.name} этот кэф выше: со ставки ${et(o.stake||1e3)} выигрыш больше на `,t("b",{text:et(o.best.gain)}),"."):null,t("div.partner-links",{},h.url?wt(h):null,$t(h)),t("div.hint",{text:mt(h)})):null)}function Bt(o){let n=(l,h)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),h.map(w=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:w.nick}),t("span",{style:"color:var(--lz-muted)",text:w.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},n(o.homeName,o.home),n(o.awayName,o.away)))}function qt(o,n){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:n.home}),t("th",{text:n.away})),o.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),o.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${o.samples[0]} и ${o.samples[1]} карт.`}):null)}function Pt(o){let n=[];if(o.pick&&n.push(ne({...o.pick,stake:o.stake})),!o.match)return n.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),n;n.push(P(o.match)),o.esports&&n.push(Bt(o.esports)),o.match.stats?.rows?.length&&n.push(qt(o.match.stats,o.match)),o.line&&n.push(B(o.line));let l=rt(o);l&&n.push(l);let h=ct(o);h&&n.push(h);let w=X(o);w&&n.push(w);let y=kt(o);y&&n.push(y);let x=it(o);x&&n.push(x);let k=nt(o);k&&n.push(k);let M=o.analysis.status==="loading";n.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:M},J("spark"),M?"Разбираю…":o.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:o.compare.status==="loading"},J("scale"),"Сравнить цены"))),o.quota&&n.push(t("div.hint.center-text",{text:o.quota}));let C=te(o);C&&n.push(C);let R=Q(o);R&&n.push(R);let $=ee(o.compare,o);return $&&n.push($),n}function oe(o){let n=o.margins;if(!n)return null;let l=[t("div",{},`Сегодня вы открыли ${n.n} ${lt(n.n,"матч","матча","матчей")} до начала: в основной исход ${o.bookName||"контора"} закладывает в среднем `,t("b",{text:G(n.here,1)})," маржи.")];return n.best?(l.push(t("div",{style:"margin-top:6px"},`На тех же ${n.best.n} ${lt(n.best.n,"матче","матчах","матчах")} у ${n.best.name} — `,t("b",{text:G(n.best.there,1)}),` против ${G(n.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((n.best.here-n.best.there)*100).toFixed(1)} п.п.`)),n.partner&&l.push(t("div.partner-links",{style:"margin-top:8px"},n.partner.url?wt(n.partner):null,$t(n.partner)),t("div.hint",{text:mt(n.partner)}))):l.push(t("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),t("div.card",{},t("div.kicker",{},t("span",{text:"Сколько маржи вы отдаёте"}),t("span.badge",{text:"сегодня"})),...l)}function re(o){let n=o.scan,l=oe(o);return n?.rows?.length?[l,t("div.card",{},t("div.kicker",{},t("span",{text:n.title}),t("span.badge",{text:`средняя маржа ${G(n.average,1)}`})),t("table",{},t("tr",{},t("th",{text:n.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),n.rows.map(h=>t("tr.click",{"data-act":"scan-go","data-arg":String(h.index),title:"Показать на странице"},t("td.name",{},h.name,h.sub?t("span.sub",{text:h.sub}):null),t("td",{},h.fav,t("span.sub",{text:G(h.favPct)})),t(`td${h.low?".best":""}`,{text:G(h.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:n.note}))]:[l,t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function jt(o){let n=o.express;if(!n.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=n.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${n.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},J("trash",13),"Очистить")),n.legs.map(h=>t("div.leg",{},t("div.t",{},t("b",{text:h.label,title:h.label}),t("span",{text:h.title,title:h.title})),t("span.o",{text:Z(h.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":h.id,title:"Убрать",style:"width:24px;height:24px"},J("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:Z(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:G(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:Z(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:G(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function _t(o){let n=o.edges||{status:"idle"},l=M=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),M?t("span.badge",{text:M}):null);if(n.status==="loading"&&!n.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(n.status==="error"&&!n.data)return[t("div.card",{},l(),t("div.note.warn",{},J("alert"),t("span",{text:n.error})))];let h=n.data;if(!h)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let w=M=>M==null?"—":`${M>=0?"+":"−"}${(Math.abs(M)*100).toFixed(1)}%`,y=M=>new Date(M).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),x=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(h.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(h.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:w(h.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:h.positiveWeek==null?"—":G(h.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),k=(h.signals||[]).map(M=>t("tr",{},t("td.name",{},`${M.home} — ${M.away}`,t("span.sub",{text:`${M.league} · ${y(M.start)}`})),t("td",{},M.label,t("span.sub",{text:M.book})),t("td",{text:Z(M.odds)}),t("td",{text:Z(1/M.p),title:`Честная цена по ${M.count} конторам`}),t("td.best",{text:`+${(M.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(h.full?"тариф «Макс»":"витрина"),k.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),k):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),h.note?t("div.hint",{style:"margin-top:8px"},h.note," ",s.bot?t("a",{href:s.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),x]}function ae(o){let n=o.settings,l=(h,w,y)=>t("div.seg",{},y.map(([x,k])=>t(`button${w===x?".on":""}`,{type:"button","data-act":h,"data-arg":x,text:k})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",n.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",n.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(n.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${n.ready?".pos":""}`,{text:n.ready?"подключён":"не подключён"})),n.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",n.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,n.mode==="license"&&n.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:n.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),n.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[n.licenseMask?`Ключ ${n.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",n.plan,n.usage].filter(Boolean).join(" "),s.bot&&!n.licenseMask?[" ",t("a",{href:s.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:n.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),n.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${n.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function se(o){ut=o;let n=JSON.stringify(o);if(n===U)return;U=n;for(let k of g.querySelectorAll("details[data-key]"))K.set(k.dataset.key,k.open);let l=g.scrollTop;v.textContent=o.bookName?`· ${o.bookName}`:"",p.classList.toggle("off",o.settings.overlay==="off"),S.replaceChildren(J(o.theme==="dark"?"sun":"moon")),z.replaceChildren(J(o.settings.overlay==="off"?"eyeOff":"eye")),z.classList.toggle("on",o.settings.overlay!=="off"),_.classList.toggle("on",o.tab==="settings"),_.dataset.arg=o.tab==="settings"?o.backTab:"settings";let h=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];d.replaceChildren(...h.map(([k,M])=>t(`button.tab${o.tab===k?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":k},M,k==="express"&&o.express.legs.length?t("span.count",{text:String(o.express.legs.length)}):null)));let w=o.tab==="settings"?ae(o):o.tab==="scan"?re(o):o.tab==="express"?jt(o):o.tab==="edges"?_t(o):Pt(o),y=o.update?t("div.card.soft.update",{},t("b",{text:`Вышла Линза ${o.update.version}`})," — ",o.update.url?t("a",{href:o.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,x=o.whatsnew?.changes?.length&&o.tab!=="settings"?t("div.card.soft.update",{},t("b",{text:`Линза обновилась до ${o.whatsnew.version}`}),t("ul.facts",{style:"margin-top:6px"},o.whatsnew.changes.flatMap(k=>k.items).slice(0,6).map(k=>t("li",{},t("span",{text:k})))),t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;g.replaceChildren(...[y,x,...w].filter(Boolean)),g.scrollTop=l,b.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function It(o){e.setAttribute("data-theme",o)}function Ct(){O.hidden=!1,a.opened?.()}function dt(){O.hidden=!0}function Lt(){O.hidden?Ct():dt()}function i(o){o?.fab&&N(c,o.fab.left,o.fab.top),o?.panel&&N(O,o.panel.left,o.panel.top)}let u=0;function m(o){f.querySelector(".toast")?.remove();let n=t("div.toast",{text:o,role:"status"});f.appendChild(n),clearTimeout(u),u=setTimeout(()=>n.remove(),2600)}return{render:se,setTheme:It,open:Ct,close:dt,toggle:Lt,restore:i,toast:m,shadow:f,rect:()=>O.hidden?null:O.getBoundingClientRect(),get isOpen(){return!O.hidden},get view(){return ut}}}var Xe="Расширение обновилось. Обновите эту вкладку (F5).";function yt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function Y(r,a={}){if(!yt())return{ok:!1,error:Xe,code:"reload"};try{return await chrome.runtime.sendMessage({type:r,...a})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(s){let e=String(s?.message||s);return/context invalidated|message port closed|receiving end does not exist/i.test(e)||!yt()?{ok:!1,error:Xe,code:"reload"}:{ok:!1,error:e}}}function Ye(r){if(yt())try{chrome.runtime.onMessage.addListener(a=>{r(a)})}catch{}}async function me(r){if(!yt())return{};try{return await chrome.storage.local.get(r)}catch{return{}}}function vt(r){if(yt())try{chrome.storage.local.set(r)}catch{}}var Je=(r=Date.now())=>new Date(r).toISOString().slice(0,10);function Jt(r,a=Date.now()){return r&&r.day===Je(a)&&r.items&&typeof r.items=="object"?r:{day:Je(a),items:{}}}function Qe(r,{key:a,book:s,margin:e}){if(!a||!Number.isFinite(e)||e<=0||e>.5)return!1;let f=Math.round(e*1e4)/1e4,p=r.items[a];return p&&p.here===f&&p.book===s?!1:(r.items[a]={book:s,here:f,others:p?.others||{}},!0)}function tn(r,a,s){let e=r.items[a];if(!e)return!1;let f=!1;for(let p of s||[]){if(p.here||p.sharp||!p.odds?.length||p.odds.some(g=>!(g>1)))continue;let c=Ot(p.odds);if(c.kind!=="full"||!(c.margin>0))continue;let d=Math.round(c.margin*1e4)/1e4;e.others[p.name]!==d&&(e.others[p.name]=d,f=!0)}return f}function en(r,a){let s=Object.values(r?.items||{}).filter(c=>c.book===a);if(!s.length)return null;let e=c=>c.reduce((d,g)=>d+g,0)/c.length,p=[...new Set(s.flatMap(c=>Object.keys(c.others||{})))].map(c=>{let d=s.filter(g=>Number.isFinite(g.others?.[c]));return d.length>=2?{name:c,n:d.length,there:e(d.map(g=>g.others[c])),here:e(d.map(g=>g.here))}:null}).filter(Boolean).sort((c,d)=>c.there-d.there);return{n:s.length,here:e(s.map(c=>c.here)),best:p[0]||null,others:p}}var Zn=[{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function nn(r,a){let s=String(r||"").split(".").map(Number),e=String(a||"").split(".").map(Number);for(let f=0;f<Math.max(s.length,e.length);f++){let p=(s[f]||0)-(e[f]||0);if(p)return p>0}return!1}function on(r,a){return Zn.filter(s=>nn(s.version,r)&&!nn(s.version,a))}var Tt=r=>Number.isFinite(r)?(Math.round(r*100)/100).toFixed(2):"—",rn=r=>`${Math.round(r*100)}%`,Gn=(r,a)=>r*a-1;function Hn(r){return r<.03?null:r<.06?"небольшая — примерно половина обычной":r<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function an(r,{source:a="",reasons:s=[],risk:e=""}={}){let f=(r||[]).filter(v=>Number(v.odd)>1&&v.p>.01&&v.p<.99).map(v=>({...v,fairOdd:1/v.p,edge:Gn(v.p,Number(v.odd))}));if(!f.length)return null;let c=[...f].sort((v,S)=>S.edge-v.edge)[0],d=c.edge>=.03?{...c,size:Hn(c.edge)}:null,g=f.filter(v=>v!==c||!d).map(v=>({...v,note:v.edge>=.03?`перевес ${rn(v.edge)} к честной цене ${Tt(v.fairOdd)}`:v.edge>-.02?`честная цена (${Tt(v.fairOdd)}), перевеса нет`:`цена ниже честной (${Tt(v.fairOdd)})`})),b=[];if(d){let v=d.source||a;b.push(`Лучшая цена: ${d.label} по ${Tt(d.odd)} — перевес около ${rn(d.edge)} к честной цене ${Tt(d.fairOdd)}${v?` (${v})`:""}. Сумма: ${d.size}.`),s.length&&b.push(`За: ${s.join(" ")}`),e&&b.push(`Главный риск: ${e}`)}else b.push(`Перевеса нет: все цены близки к честным или ниже${a?` (${a})`:""} — разумнее пропустить.`);return g.length&&b.push(`${d?"Остальное":"По рынкам"}: ${g.map(v=>`${v.label} по ${Tt(v.odd)} — ${v.note}`).join("; ")}.`),b.push("Это расчёт, а не гарантия: проиграть можно и при перевесе в цене. 18+"),{best:d,others:g,lines:b}}function he(r){let a=e=>/^(б|больше|бол|over|o\b|тб)/i.test(String(e||"").trim()),s=e=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(e||"").trim());return a(r[0])&&s(r[1])?0:s(r[0])&&a(r[1])?1:-1}var Xn=r=>{let a=r<0?-1:1,s=Math.abs(r),e=1/(1+.3275911*s);return a*(1-((((1.061405429*e-1.453152027)*e+1.421413741)*e-.284496736)*e+.254829592)*e*Math.exp(-s*s))},ge=r=>.5*(1+Xn(r/Math.SQRT2));function sn(r,a,s){if(!(Math.abs(s-Math.round(s))<1e-9)){let c=1-ge((s-r)/a);return{win:c,push:0,lose:1-c}}let f=1-ge((s+.5-r)/a),p=ge((s-.5-r)/a);return{win:f,push:Math.max(0,1-f-p),lose:p}}function Yn(r,a,s){let e=sn(r,a,-s);return{home:e.win,away:e.lose,push:e.push}}function Jn(r,a,s){let e=sn(r,a,s);return{over:e.win,under:e.lose,push:e.push}}function ln(r,{handicap:a=null,total:s=null}={},e=["Хозяева","Гости"]){let f=r?.lines;if(!f||!Number.isFinite(f.margin)||!(f.sigma>0))return[];let p=[],c=b=>b>0?`+${b}`:`${b}`,d=(b,v)=>b/(1-v||1),g=(b,v)=>1/b/(1/b+1/v);if(a&&Number.isFinite(a.line)&&Math.abs(a.line)<60&&a.home>1&&a.away>1){let b=Yn(f.margin,f.sigma,a.line);Math.abs(d(b.home,b.push)-g(a.home,a.away))<=.3&&p.push({label:`Фора ${e[0]} ${c(a.line)}`,odd:a.home,p:d(b.home,b.push),kind:"handicap",side:"home",source:"модель Линзы"}),p.length&&p.push({label:`Фора ${e[1]} ${c(-a.line)}`,odd:a.away,p:d(b.away,b.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(s&&Number.isFinite(f.total)&&f.sigmaT>0&&Number.isFinite(s.line)&&s.line>50&&s.over>1&&s.under>1){let b=Jn(f.total,f.sigmaT,s.line);Math.abs(d(b.over,b.push)-g(s.over,s.under))<=.3&&(p.push({label:`Тотал больше ${s.line}`,odd:s.over,p:d(b.over,b.push),kind:"total",source:"модель Линзы"}),p.push({label:`Тотал меньше ${s.line}`,odd:s.under,p:d(b.under,b.push),kind:"total",source:"модель Линзы"}))}return p}var Qt=globalThis.__lzBus,be=Qt&&window.top===window?qe(location.hostname):null;be&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Qn(be.adapter,be.book));async function Qn(r,a){let s=await me(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),e={settings:{...ie,...s["lz.settings"]||{}},positions:(s["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:to(s["lz.express"]),margins:Jt(s["lz.margins"]),whatsnew:s["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},f=new WeakMap,p=new WeakMap,c=Re(),d=He({bus:Qt,brand:Ut,actions:re()});d.restore(e.positions);function g(i){let u=i.outcomes.map(n=>n.odd).join("/"),m=f.get(i);if(m?.sig===u)return m.set;let o=Ot(i.outcomes.map(n=>n.odd));return f.set(i,{sig:u,set:o}),o}function b(){return e.match?e.analysis.get(e.match.key):null}function v(i){let u=b()?.result;if(!u?.model||i.scope==="list"||!e.match||!Object.values(u.shift||{}).some(h=>Math.abs(h)>=.5))return null;let{home:m,draw:o,away:n}=u.model,l=i.outcomes.length;if(i.kind==="1x2"&&i.main&&l===3)return[m,o,n];if(i.kind==="12"&&i.main&&l===2&&o<.005)return[m,n];if(i.kind==="dc"&&i.main&&l===3)return[m+o,m+n,o+n];if(/^победит\s*\(осн\.?\s*время\)$/i.test(i.title)&&l===2){let h=i.period===e.match.home?m:i.period===e.match.away?n:null;if(h!=null)return[h,1-h]}return null}function S(){let i=e.markets.filter(u=>u.scope!=="list"&&u.main&&(u.kind==="1x2"||u.kind==="12"));return i.find(u=>u.scope==="top")||i[0]||null}function z(i,u){let m=i.outcomes[u].label;return i.scope==="list"?!i.event||!i.main?m:i.kind==="1x2"?[i.event.home,"Ничья",i.event.away][u]||m:i.kind==="12"&&[i.event.home,i.event.away][u]||m:e.match?i.kind==="1x2"?[e.match.home,"Ничья",e.match.away][u]||m:i.kind==="12"&&[e.match.home,e.match.away][u]||m:m}function _(){let i=e.settings.overlay,u=[];for(let o of e.markets){if(o.outcomes.forEach((k,M)=>p.set(k.el,{market:o,index:M})),i==="off")continue;let n=g(o);if(n.kind==="partial")continue;let l=v(o),h=l||n.fair,w=0;for(let k=1;k<n.fair.length;k+=1)n.fair[k]>n.fair[w]&&(w=k);let y="accent";if(l){let k=0;for(let M=1;M<l.length;M+=1)l[M]-n.fair[M]>l[k]-n.fair[k]&&(k=M);l[k]-n.fair[k]>=.015&&(w=k,y="pos")}let x=o.scope!=="list"||o.main&&(o.kind==="1x2"||o.kind==="12");o.outcomes.forEach((k,M)=>{let C=M===w&&x;!C&&i!=="all"||u.push({el:k.el,frame:C,chip:xt(h[M]),tone:C?y:"quiet"})})}let m=E();if(m){let o=u.find(n=>n.el===m.item.el);o?o.selected=!0:u.push({el:m.item.el,frame:!1,selected:!0,chip:null})}c.set(u)}function E(){if(!e.selected)return null;let i=e.markets.find(m=>m.id===e.selected.id),u=i?.outcomes[e.selected.index];return u?.el?.isConnected?{market:i,item:u,index:e.selected.index}:null}function O(){if(e.settings.theme!=="auto")return e.settings.theme;for(let i of[document.body,document.documentElement]){let m=(i?getComputedStyle(i).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!m||m[4]==="0")continue;return(.2126*m[1]+.7152*m[2]+.0722*m[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let q=0;function U(){clearTimeout(q),q=setTimeout(()=>vt({"lz.margins":e.margins}),1500)}function ut(){if(e.pageType!=="match"||!e.match||e.match.live)return;e.margins=Jt(e.margins);let i=B();i&&Qe(e.margins,{key:e.match.key,book:a.id,margin:i.margin})&&U()}function K(){location.href!==e.url&&(e.url=location.href,e.selected=null,c.hideTip());let i="other",u=[],m=null;try{i=r.pageType(document,location),u=r.collect(document,location),m=r.readMatch(document,location)}catch(n){console.error("[Линза] страница не прочитана",n)}i!==e.pageType&&(e.pageType=i,e.tab!=="settings"&&e.tab!=="express"&&(e.tab=i==="match"?"match":"scan")),e.markets=u,e.match=m,ut();let o=O();o!==e.theme&&(e.theme=o),c.setTheme(e.theme),d.setTheme(e.theme),_(),mt(),F(),d.isOpen&&(wt(),Bt(),Pt(),$t(),d.render(X()))}let pt=new Set,W=null;function F(){if(r.observeTargets)for(let i of r.observeTargets(document))pt.has(i)||(pt.add(i),W=W||new MutationObserver(P),W.observe(i,{childList:!0,subtree:!0,characterData:!0}))}let N=0,A=0;function P(){let i=Date.now();A||(A=i),clearTimeout(N);let u=i-A>900?0:220;N=setTimeout(()=>{A=0,!document.hidden&&K()},u)}function B(){let i=S();if(!i)return null;let u=g(i);if(u.kind!=="full")return null;let m=v(i);return{title:"Что заложено в цене",margin:u.margin,rows:i.outcomes.map((o,n)=>({name:z(i,n),odd:o.odd,fair:u.fair[n],model:m?m[n]:null})),overtime:Q()}}function Q(){if(!["hockey","basketball"].includes(e.match?.sport))return null;let i=e.markets.find(m=>m.scope!=="list"&&m.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${m.title} ${m.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${m.title} ${m.period}`));if(!i)return null;let u=g(i);return u.kind!=="full"?null:{title:[i.title,i.period].filter(Boolean).join(" · "),rows:i.outcomes.map((m,o)=>({name:z(i,o)||[e.match.home,e.match.away][o],odd:m.odd,fair:u.fair[o]}))}}function tt(){let i=E();if(!i)return null;let{market:u,item:m,index:o}=i,n=g(u),l=v(u),h=n.fair?n.fair[o]:null,w=u.event?`${u.event.home} — ${u.event.away}`:e.match?`${e.match.home} — ${e.match.away}`:"",y=e.match?e.compare.get(e.match.key):null,x=null;if(y?.rows?.length&&u.main&&(u.kind==="1x2"||u.kind==="12")&&u.scope!=="list")for(let M of y.rows){let C=M.odds[o];C&&(!x||C>x.odd)&&(x={name:M.name,odd:C,book:M.book||""})}x&&(x.partner=x.book&&x.book!==a.id&&e.partners.data?.[x.book]||null,x.gain=Math.round((x.odd-m.odd)*(e.settings.stake||1e3)));let k=`${u.id}#${o}`;return{market:[u.title,u.period,u.line].filter(Boolean).join(" · "),label:[z(u,o),w].filter(Boolean).join(" · "),odd:m.odd,fair:h,margin:n.margin,fairOdd:h?1/h:null,model:l?l[o]:null,ev:l?ze(l[o],m.odd):null,best:x,canAdd:Number.isFinite(h)&&!e.express.some(M=>M.id===k),inExpress:e.express.some(M=>M.id===k),note:n.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":l?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function rt(){let i=en(Jt(e.margins),a.id);if(!i)return null;let u=i.best&&i.best.there<i.best.here?i.best:null,m=u&&ft().find(o=>o.name===u.name&&(o.url||o.code))||null;return{...i,best:u,partner:m}}function ot(){let i=[];if(e.pageType==="match"?e.markets.forEach((n,l)=>{if(n.scope==="list")return;let h=g(n);if(h.kind!=="full")return;let w=0;for(let y=1;y<h.fair.length;y+=1)h.fair[y]>h.fair[w]&&(w=y);i.push({index:l,name:n.title,sub:[n.period,n.line].filter(Boolean).join(" · "),margin:h.margin,fav:n.outcomes[w].label,favPct:h.fair[w]})}):e.markets.forEach((n,l)=>{if(!n.event||!n.main||n.kind!=="1x2"&&n.kind!=="12")return;let h=g(n);if(h.kind!=="full")return;let w=0;for(let x=1;x<h.fair.length;x+=1)h.fair[x]>h.fair[w]&&(w=x);let y=n.kind==="1x2"?[n.event.home,"Ничья",n.event.away][w]:[n.event.home,n.event.away][w];i.push({index:l,name:`${n.event.home} — ${n.event.away}`,sub:n.event.league||n.event.time,margin:h.margin,fav:y,favPct:h.fair[w]})}),!i.length)return null;let u=new Set;for(let n=i.length-1;n>=0;n-=1){let l=`${i[n].name}|${i[n].sub}`;u.has(l)?i.splice(n,1):u.add(l)}let m=i.reduce((n,l)=>n+l.margin,0)/i.length;i.sort((n,l)=>n.margin-l.margin);let o=i.slice(0,16);return o.forEach(n=>{n.low=n.margin<=m*.8}),{title:e.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:e.pageType==="match"?"Рынок":"Матч",average:m,rows:o,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${o.length} из ${i.length}, сначала самые дешёвые.`}}function st(){let i=e.status;return i.ready?i.limit?`Разборов сегодня: ${i.used} из ${i.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function X(){let i=e.match?.key,u=i&&e.analysis.get(i)||{status:"idle",steps:[]},m=i&&e.compare.get(i)||{status:"idle"},o=e.match?.live&&r.readEsportsWidget?r.readEsportsWidget(document):null,n=e.status;return{tab:e.tab,backTab:e.backTab,theme:e.theme,bookName:a.name,pageType:e.pageType,match:e.match?{...e.match,sportName:ye[e.match.sport]||""}:null,esports:o?{...o,homeName:e.match.home,awayName:e.match.away}:null,line:B(),analysis:{status:u.status,steps:u.steps||[],result:u.result||null,error:u.error||"",needKey:!!u.needKey},compare:m,consensus:i&&e.consensus.get(i)||null,model:i&&e.model.get(i)||null,live:ne(i),verdict:ee(i),facts:i&&e.facts.get(i)||null,pick:tt(),scan:e.tab==="scan"?ot():null,margins:e.tab==="scan"?rt():null,edges:e.edges,bookId:a.id,partners:ft(),stake:Number(e.settings.stake)||1e3,express:{legs:e.express,stats:$e(e.express)},quota:st(),update:e.status.update?{version:e.status.update,url:Ut.site?`${Ut.site}#install`:""}:null,whatsnew:e.whatsnew?{version:e.whatsnew.to,changes:on(e.whatsnew.from,e.whatsnew.to)}:null,settings:{overlay:e.settings.overlay,theme:e.settings.theme,stake:Number(e.settings.stake)||1e3,mode:n.mode,proxy:n.proxy,ready:n.ready,hasKey:n.hasKey,keyMask:n.keyMask,licenseMask:n.licenseMask,plan:n.plan==="free"||!n.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[n.plan]||"Про"}»${n.until?` до ${n.until.split("-").reverse().join(".")}`:""}.`,usage:n.limit?`Сегодня разборов: ${n.used} из ${n.limit}.`:""}}}let H=()=>{d.isOpen&&d.render(X())};function ct(i){Object.assign(e.settings,i),vt({"lz.settings":e.settings}),K(),d.render(X())}async function kt(i=!1){if(!i&&Date.now()-e.partners.at<3600*1e3)return;e.partners.at=Date.now();let u=await Y("lz:partners",{force:i});u.ok&&u.data&&typeof u.data=="object"&&(e.partners.data=u.data,d.isOpen&&d.render(X()),it())}let ft=()=>Object.values(e.partners.data||{}).filter(i=>i&&i.id!==a.id);function it(){if(!d.isOpen||e.tab!=="match"||!e.match)return;let i=ft().filter(u=>u.url||u.code).map(u=>u.id);i.length&&Y("lz:partner-seen",{ids:i,s:"panel"})}async function nt(){e.edges={...e.edges,status:"loading",error:""};let i=await Y("lz:edges",{sport:e.match?.sport||""});e.edges=i.ok?{status:"done",data:i.data,error:"",at:Date.now()}:{status:"error",data:e.edges.data,error:i.error,at:Date.now()},H()}async function et(){let i=await Y("lz:status");i.ok&&(e.status=i.data),H()}function lt(){let i=S(),u=i?g(i):null;return{book:a.name,match:e.match,market:i&&u?.kind==="full"?{kind:i.kind,labels:i.outcomes.map((m,o)=>z(i,o)),odds:i.outcomes.map(m=>m.odd)}:null}}function mt(){if(!e.match||!yt())return;let i=lt();if(!i.market)return;let u=`${e.match.key}|${i.market.odds.join("/")}`;u!==mt.last&&(mt.last=u,Y("lz:quote",i))}async function wt(){let i=e.match;if(!i||i.live||e.consensus.has(i.key))return;let u=lt();if(!u.market?.odds?.length)return;e.consensus.set(i.key,null);let m=await Y("lz:consensus",{match:i,size:u.market.odds.length});e.consensus.set(i.key,m.ok&&m.data?.consensus?m.data:null),e.match?.key===i.key&&d.isOpen&&d.render(X())}async function $t(){let i=e.match;if(!i?.live||i.sport!=="basketball")return;let u=e.live.get(i.key);if(u&&(u.pending||Date.now()-u.at<3e4))return;e.live.set(i.key,{...u||{},pending:!0});let m=await Y("lz:live",{match:i});e.live.set(i.key,{at:Date.now(),data:m.ok&&m.data&&!m.data.error?m.data:null,error:m.ok?m.data?.error||"":m.error||""}),e.match?.key===i.key&&d.isOpen&&d.render(X())}function te(i,u,m){let o=e.match,n=`${i}|${[u.best,...u.others].filter(Boolean).map(h=>`${h.label}:${h.odd}`).join(",")}`;if(e.verdictSent===n)return;e.verdictSent=n;let l=[u.best,...u.others].filter(Boolean).map(h=>({label:h.label,odd:h.odd,p:h.p,kind:h.kind||"win",side:h.side||"",line:h.line??null}));Y("lz:verdict",{payload:{sport:o.sport,league:o.league||"",home:o.home,away:o.away,book:a.name,source:m,options:l}}).then(h=>{h?.ok&&h.data?.track&&h.data.track!==e.verdictTrack&&(e.verdictTrack=h.data.track,d.isOpen&&d.render(X()))}).catch(()=>{})}function ee(i){let u=e.match,m=i&&B();if(!u||!m||u.live)return null;let o=e.consensus.get(i),n=e.model.get(i),l=e.analysis.get(i)?.result,h=[u.home,u.away],w=[],y="",x=m.rows;if(o?.consensus?.length===x.length)x.forEach(($,T)=>w.push({label:$.name,odd:$.odd,p:o.consensus[T],side:x.length===3?["home","draw","away"][T]:["home","away"][T]})),y=`консенсус ${o.count} контор`;else{let $=x.length===2?x:u.sport==="mma"&&x.length===3?[x[0],x[2]]:m.overtime?.rows||null,T=o?.consensus?.length===2?o.consensus:n?.p1?[n.p1,n.p2]:null;$&&T&&($.forEach((I,j)=>w.push({label:h[j],odd:I.odd,p:T[j],side:["home","away"][j]})),y=o?.consensus?.length===2?`консенсус ${o.count} контор`:"модель Линзы")}let k=n?.sport==="mma"?n.durations:null;if(k)for(let $ of e.markets){if($.scope==="list"||$.kind!=="total"||$.outcomes.length!==2)continue;let T=String($.line||"").replace(",","."),I=T==="1.5"?k.r1+k.r2/2:T==="2.5"&&k.rounds===3?k.r1+k.r2+k.r3/2:null,j=he($.outcomes.map(V=>V.label));I==null||j<0||w.some(V=>V.kind==="total"&&V.line===T)||(w.push({label:`Больше ${T} раунда`,odd:$.outcomes[j].odd,p:1-I,kind:"total",line:T}),w.push({label:`Меньше ${T} раунда`,odd:$.outcomes[1-j].odd,p:I,kind:"total",line:T}))}if(n?.sport==="basketball"&&n.lines){let $=Ft=>{let at=String(Ft||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return at?Number(at[0]):NaN},T=Ft=>e.markets.filter(at=>at.scope!=="list"&&at.main&&at.kind===Ft&&at.outcomes.length===2&&at.outcomes.every(Rt=>Rt.odd>1)).sort((at,Rt)=>Math.abs(at.outcomes[0].odd-at.outcomes[1].odd)-Math.abs(Rt.outcomes[0].odd-Rt.outcomes[1].odd))[0]||null,I=T("handicap"),j=T("total"),V=I?$(I.outcomes[0].label):NaN;I&&!Number.isFinite(V)&&(V=$(I.line));let ht=j?$(j.line):NaN;j&&!Number.isFinite(ht)&&(ht=$(j.outcomes[0].label));let gt=j?he(j.outcomes.map(Ft=>Ft.label)):-1;w.push(...ln(n,{handicap:I&&Number.isFinite(V)?{line:V,home:I.outcomes[0].odd,away:I.outcomes[1].odd}:null,total:j&&gt>=0&&Number.isFinite(ht)?{line:ht,over:j.outcomes[gt].odd,under:j.outcomes[1-gt].odd}:null},h))}if(!w.length)return null;let M=[...w].sort(($,T)=>T.p*T.odd-$.p*$.odd)[0]?.side,C=(l?.factors||[]).filter($=>M&&$.side===M).slice(0,2).map($=>$.text),R=an(w,{source:y,reasons:C,risk:l?.risks?.[0]||""});return R&&te(i,R,y),R&&{...R,track:e.verdictTrack||""}}function ne(i){let u=i&&e.live.get(i);if(!u?.data)return u?.error?{error:u.error}:null;let m=u.data,o=!!m.flipped,n=(x,k)=>o?[k,x]:[x,k],l=B(),h=l?.overtime?.rows||l?.rows||[],w=h.length===2?h.map(x=>x.fair):h.length===3&&h.every(x=>Number.isFinite(x.fair))?[h[0].fair+h[1].fair/2,h[2].fair+h[1].fair/2]:null,y=m.tables||{};return{names:[e.match.home,e.match.away],score:n(m.score[0],m.score[1]),periods:(m.periods||[]).map(([x,k])=>n(x,k)),period:m.period,elapsed:m.elapsed,left:m.left,clock:m.clock,format:m.format,probs:n(m.p1,m.p2),book:w,prior:m.prior,expMargin:o?-m.expMargin:m.expMargin,sd:m.sd,projTotal:m.projTotal,sdTotal:m.sdTotal,handicap:(y.handicap||[]).map(x=>o?{line:-x.line,home:x.away,away:x.home}:x).sort((x,k)=>x.line-k.line),total:y.total||[],quarterTotal:y.quarterTotal||[],bookLines:m.bookLines?{handicap:m.bookLines.handicap?o?{...m.bookLines.handicap,line:-m.bookLines.handicap.line,odds:[...m.bookLines.handicap.odds].reverse(),fair:[...m.bookLines.handicap.fair].reverse(),p:1-m.bookLines.handicap.p,book:1-m.bookLines.handicap.book,gap:-m.bookLines.handicap.gap}:m.bookLines.handicap:null,total:m.bookLines.total||null}:null,quarter:m.quarter?{...m.quarter,score:n(m.quarter.score[0],m.quarter.score[1]),expMargin:o?-m.quarter.expMargin:m.quarter.expMargin,probs:n(m.quarter.p1,m.quarter.p2)}:null,at:u.at}}async function Bt(){let i=e.match;if(!i||!["cs","dota","tennis","basketball","mma"].includes(i.sport)||e.model.has(i.key)||i.live&&(i.sport==="tennis"||i.sport==="basketball"||i.sport==="mma"))return;e.model.set(i.key,null);let u=await Y("lz:model",{match:i});e.model.set(i.key,u.ok&&u.data?.p1?u.data:null),e.match?.key===i.key&&d.isOpen&&d.render(X())}let qt=new Map;async function Pt(){let i=e.match;if(!i||!["football","hockey","basketball","cs","dota"].includes(i.sport))return;let u=i.live&&Date.now()-(qt.get(i.key)||0)>60*1e3;if(e.facts.has(i.key)&&!u)return;let m=e.facts.get(i.key)||null;qt.set(i.key,Date.now()),e.facts.set(i.key,m);let o=await Y("lz:facts",{match:i});e.facts.set(i.key,o.ok&&o.data?.facts?.length?o.data:m),e.match?.key===i.key&&d.isOpen&&d.render(X())}async function oe(){let i=e.match;if(!i||e.analysis.has(i.key))return;let u=await Y("lz:cached",{match:i});!u.ok||!u.data||e.analysis.has(i.key)||(e.analysis.set(i.key,{status:"done",steps:[],result:u.data}),K(),H())}function re(){return{opened(){et(),K(),oe(),wt(),Bt(),Pt(),$t(),kt(),d.render(X()),it()},tab(i){i==="settings"&&(e.backTab=e.tab==="settings"?e.backTab:e.tab),e.tab=i||"match",i==="edges"&&e.edges.status!=="loading"&&Date.now()-e.edges.at>300*1e3&&nt(),d.render(X())},"edges-refresh"(){nt(),d.render(X())},theme(){ct({theme:e.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ct({overlay:e.settings.overlay==="off"?"picks":"off"})},"set-overlay"(i){ct({overlay:i})},"set-theme"(i){ct({theme:i})},async"set-mode"(i){await Y("lz:settings",{mode:i}),et()},"copy-code"(i){if(!i)return;let u=()=>d.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(i).then(u,()=>d.toast(`Промокод: ${i}`)):d.toast(`Промокод: ${i}`)},"set-stake"(i,u,m){let o=Math.round(Number(m.getElementById("lz-stake")?.value));if(!Number.isFinite(o)||o<10||o>1e7)return d.toast("Введите сумму от 10 ₽");ct({stake:o}),d.toast("Сумма сохранена")},async"save-key"(i,u,m){let o=m.getElementById("lz-key"),n=(o?.value||"").trim();if(n.length<8)return d.toast("Вставьте ключ целиком");let l=await Y("lz:settings",{apiKey:n});d.toast(l.ok?"Ключ сохранён":l.error),o&&(o.value=""),et()},async"clear-key"(){await Y("lz:settings",{apiKey:""}),d.toast("Ключ удалён"),et()},async"save-license"(i,u,m){let o=m.getElementById("lz-license"),n=(o?.value||"").trim();if(n.length<6)return d.toast("Вставьте ключ целиком");let l=await Y("lz:settings",{licenseKey:n});d.toast(l.ok?"Ключ принят":l.error),o&&(o.value=""),et()},async"clear-license"(){await Y("lz:settings",{licenseKey:""}),d.toast("Ключ удалён"),et()},savePosition(i,u){e.positions[i]=u,me(["lz.positions"]).then(m=>{let o=m["lz.positions"]||{};o[location.hostname]=e.positions,vt({"lz.positions":o})})},async analyze(){if(!e.match)return;let i=e.match.key,u={status:"loading",steps:[`${e.match.home} — ${e.match.away}`]};e.analysis.set(i,u),H();let m=await Y("lz:analyze",{...lt(),force:!0});m.ok?e.analysis.set(i,{status:"done",steps:u.steps,result:m.data}):e.analysis.set(i,{status:"error",steps:u.steps,error:m.error,needKey:m.code==="no-access"}),et(),K(),d.render(X())},async compare(){if(!e.match)return;let i=e.match.key;e.compare.set(i,{status:"loading"}),H();let u=await Y("lz:compare",lt());e.compare.set(i,u.ok?{status:"done",...u.data}:{status:"done",rows:[],labels:[],note:u.error}),u.ok&&tn(e.margins,i,u.data.rows)&&U(),H()},"whatsnew-ok"(){e.whatsnew=null,vt({"lz.whatsnew":null}),H()},"pick-clear"(){e.selected=null,_(),H()},"leg-add"(){let i=tt(),u=E();!i?.canAdd||!u||(e.express.push({id:`${u.market.id}#${u.index}`,title:i.market,label:i.label,odd:i.odd,fair:i.fair,at:Date.now()}),vt({"lz.express":e.express}),d.toast("Добавлено в расчёт экспресса"),H())},"leg-remove"(i){e.express=e.express.filter(u=>u.id!==i),vt({"lz.express":e.express}),H()},"leg-clear"(){e.express=[],vt({"lz.express":e.express}),H()},"scan-go"(i){let u=e.markets[Number(i)],m=u?.outcomes[0]?.el;m?.isConnected&&(m.scrollIntoView({behavior:"smooth",block:"center"}),e.selected={id:u.id,index:0},setTimeout(_,400))}}}function jt(i){let u=i.composedPath();for(let m=0;m<Math.min(u.length,6);m+=1){let o=u[m]instanceof Element?p.get(u[m]):null;if(o&&o.market.outcomes[o.index]?.el===u[m])return o}return null}let _t=new Map;function ae(i){if(!i.event||!i.main||!["1x2","12"].includes(i.kind)||i.scope!=="list"||i.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!i.event,main:i.main,kind:i.kind,scope:i.scope,live:i.event?.live})),null;let u=i.event.key;if(_t.has(u))return _t.get(u);let m={home:i.event.home,away:i.event.away,sport:se(i),league:i.event.league||""},o=Y("lz:consensus",{match:m,size:i.outcomes.length}).then(n=>((!n.ok||!n.data?.consensus)&&console.debug("[lz] рынок для списка:",n.error||n.data?.error||"нет данных"),n.ok&&n.data?.consensus?n.data:null)).catch(n=>(console.debug("[lz] рынок для списка:",String(n?.message||n)),null));return _t.set(u,o),o.then(n=>_t.set(u,n)),o}let se=i=>i.event?.sport||e.match?.sport||Nt(location.pathname,document.title,i.event?.league);function It({market:i,index:u},m=null){let o=g(i),n=v(i),l=i.event?`${i.event.home} — ${i.event.away}`:"",h=i.outcomes.map((x,k)=>{let M=o.fair?o.fair[k]:1/x.odd;return t(`div.tip-row${k===u?".hot":""}`,{},t("span",{text:z(i,k)}),t("span.odd",{text:Z(x.odd)}),t("span.pct",{text:xt(M,M<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(M*100)}%`})))}),w=o.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:xt(o.margin,1)}),n?t("span",{}," · модель: ",t("b",{text:xt(n[u],1)})):null),y=null;if(m?.consensus){let x=m.consensus.length===i.outcomes.length,k=!x&&m.consensus.length===2&&i.outcomes.length===3;if(x||k){let M=x?m.consensus[u]:null,C=M?i.outcomes[u].odd*M-1:0;y=t("div.tip-foot",{},`Рынок, ${m.count} контор${k?", с овертаймом":""}: `,t("b",{text:m.consensus.map(R=>xt(R,0)).join(" / ")}),C>.005?t("span.pos",{text:` · кэф выше рынка на ${(C*100).toFixed(1)}%`}):null)}}else m===void 0&&(y=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[i.title,i.period,i.line].filter(Boolean).join(" · ")}),l?t("div.tip-sub",{text:l}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),h.slice(0,8),w,y)}let Ct=0,dt=null;Qt.on("page:pointerover",i=>{if(e.settings.overlay==="off")return;let u=jt(i),m=u?u.market.outcomes[u.index].el:null;if(m!==dt){if(dt=m,clearTimeout(Ct),!u)return c.hideTip();Ct=setTimeout(()=>{if(dt!==m||!m.isConnected)return;c.setAvoid(d.rect());let o=ae(u.market);c.showTip(m,It(u,o instanceof Promise?void 0:o)),o instanceof Promise&&o.then(n=>{dt===m&&m.isConnected&&c.showTip(m,It(u,n))})},280)}}),Qt.on("page:click",i=>{let u=jt(i);u&&(e.selected={id:u.market.id,index:u.index},e.tab==="scan"&&(e.tab="match"),_(),H())}),Ye(i=>{if(i.type!=="lz:progress")return;let u=e.analysis.get(i.key);!u||u.status!=="loading"||(u.steps=[...u.steps,i.text].slice(-7),H())});let Lt=()=>{K(),new MutationObserver(P).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||K()}),setInterval(()=>{!document.hidden&&location.href!==e.url&&K()},600),setInterval(()=>{!document.hidden&&d.isOpen&&P()},4e3),yt()&&chrome.storage.onChanged.addListener(i=>{i["lz.settings"]&&(e.settings={...ie,...i["lz.settings"].newValue||{}},K())}),et()};document.body?Lt():document.addEventListener("DOMContentLoaded",Lt,{once:!0}),document.documentElement.setAttribute("data-lz",a.id),globalThis.__lz={state:e,view:X,refresh:K,overlay:c,panel:d}}function to(r){let a=Date.now()-432e5;return(Array.isArray(r)?r:[]).filter(s=>s&&s.at>a&&s.odd>1)}})();
