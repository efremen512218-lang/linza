(()=>{var vt=r=>typeof r=="string"?r:"",Et={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:vt("https://efremen512218-lang.github.io/linza/"),telegram:vt("https://t.me/linza_odds"),bot:vt("https://t.me/linza_keys_bot")},je=vt("https://185-72-145-3.sslip.io"),de={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var ue=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function qt(r){let a=String(r||"").toLowerCase();return ue.find(i=>i.hosts.some(e=>a===e||a.endsWith(`.${e}`)))||null}var $t={overlay:"picks",theme:"auto",mode:"own",model:de.model},Bt={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function ot(r){let a=String(r??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(a))return null;let i=parseFloat(a.replace(",","."));return i>=1.001&&i<=1e3?i:null}var Ft=r=>r.reduce((a,i)=>a+1/i,0);function Mt(r){let a=(r||[]).filter(e=>Number.isFinite(e)&&e>1);if(a.length<2||a.length!==(r||[]).length)return{kind:"partial",margin:null,fair:null};let i=Ft(a);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:a.map(e=>1/e/i)};if(a.length===3&&i>=1.97&&i<=2.4){let e=i/2;return{kind:"double",margin:e-1,fair:a.map(p=>Math.min(.995,1/p/e))}}return{kind:"partial",margin:null,fair:null}}function Rt(r){let a=(r||[]).map(m=>m||[]).filter(m=>m.length),i=a.flat().filter(Boolean);if(i.length<2)return{sets:[],rest:i};let e=m=>m.length>=2&&m.every(Boolean)&&Mt(m.map(b=>b.odd)).kind!=="partial",p=m=>{let b=m.filter(v=>v.some(Boolean));if(!b.length)return null;let y=b.filter(e);if(y.length/b.length<.6)return null;let z=new Set(y.flat());return{sets:y,rest:i.filter(v=>!z.has(v))}},f=m=>{let b=[];for(let y=0;y<a.length;y+=m)b.push(a.slice(y,y+m).flat());return b},c=()=>{let m=[];for(let b=0;b+1<a.length;b+=2){let y=Math.max(a[b].length,a[b+1].length);for(let z=0;z<y;z+=1)m.push([a[b][z]??null,a[b+1][z]??null])}return m},u=[()=>f(1)];a.length>=2&&a.length%2===0&&u.push(c,()=>f(2)),a.length>=3&&a.length%3===0&&u.push(()=>f(3)),a.length>1&&u.push(()=>[a.flat()]);for(let m of u){let b=p(m());if(b)return b}return{sets:[],rest:i}}function Pt(r,a=1.13){let i=u=>{let m=Ft(u.map(b=>b.odd));return m>=.995&&m<=a?!0:u.length===3&&m>=1.99&&m<=a*2},e=u=>Math.abs(u*4-Math.round(u*4))<1e-9,p=[],f=[],c=0;for(;c<r.length;){let u=r.slice(c,c+3),m=r.slice(c,c+2);u.length===3&&i(u)?(p.push(u),c+=3):m.length===2&&i(m)?(p.push(m),c+=2):r[c+2]&&e(r[c+1].odd)&&i([r[c],r[c+2]])?(p.push([r[c],r[c+2]]),f.push(r[c+1]),c+=3):(f.push(r[c]),c+=1)}return{sets:p,rest:f}}function jt(r){let a=(r||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!a.length)return null;let i=a.reduce((p,f)=>p*f.odd,1),e=a.reduce((p,f)=>p*f.fair,1);return{legs:a.length,odd:i,chance:e,fairOdd:1/e,margin:1-i*e}}function Dt(r,a){return r*a-1}function Z(r){return Number.isFinite(r)?r>=100?r.toFixed(0):r>=10?r.toFixed(1):r.toFixed(2):"—"}function rt(r,a=0){if(!Number.isFinite(r))return"—";let i=r*100;return i>0&&i<1&&a===0?"<1%":`${i.toFixed(a)}%`}function St(r){return String(r??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zа-я0-9]/g,"")}var pe=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function It(r){return String(r??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").split(/[^a-zа-я0-9]+/).filter(a=>a.length>=2&&!pe.has(a))}function gt(r,a){let i=St(r),e=St(a);if(i.length<2||e.length<2)return 0;if(i===e)return 1;let p=i.length<=e.length?i:e,f=p===i?e:i;if(p.length>=4&&f.includes(p))return .85;let c=It(r),u=It(a);if(c.length&&u.length){let y=c.filter(z=>u.some(v=>v===z||z.length>=5&&v.startsWith(z.slice(0,5)))).length/Math.max(c.length,u.length);if(y>=.5)return .6+.3*y}let m=0;for(;m<i.length&&m<e.length&&i[m]===e[m];)m+=1;return m>=5?Math.min(.8,.45+m*.04):0}function fe(r){let a=String(r??"").toLowerCase(),i=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(a)&&i.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(a)&&i.push("women"),/\(рез|\(р\)|резерв|reserve/.test(a)&&i.push("reserve"),/люб/.test(a)&&i.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(a)&&i.push("cyber"),i.join("+")}function it(r,a){let i=f=>{let c=St(f),u=fe(f);return c.length<2?"":u?`${c}~${u}`:c},e=i(r),p=i(a);return!e||!p?"":[e,p].sort().join("|")}var M=r=>(r?.textContent||"").replace(/[ \s]+/g," ").trim(),Tt=r=>r.offsetParent===null&&r.tagName!=="BODY";function me(r){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(r||"").trim())}function bt(r,a){let i=String(r||"").toLowerCase();return/двойной шанс/.test(i)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(i)?"other":/фор[аы]|гандикап/.test(i)?"handicap":/тотал/.test(i)?"total":/обе забьют/.test(i)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(i)?a===3?"1x2":a===2?"12":"other":"other"}var he=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function ut(...r){let a=r.filter(Boolean).join(" ");for(let[i,e]of he)if(i.test(a))return e;return""}function Lt(r){if(!r)return null;let a=ot(M(r));if(a)return a;let i=M(r).split(" ");return ot(i[i.length-1])}var ge=0;function lt({scope:r,title:a,period:i="",line:e="",kind:p,outcomes:f,event:c=null,anchor:u=null,eventKey:m=""}){let b=f.length;return{id:`${r}|${m}|${a}|${i}|${e}|${f.map(y=>y.label).join("/")}`,serial:ge+=1,scope:r,title:a,period:i,line:e,kind:p||bt(a,b),main:me(i),outcomes:f,event:c,anchor:u||f[0]?.el||null}}var B=(r,a)=>[...r.querySelectorAll(a)];function Xt(r){return(String(r||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function Ct(r){return r.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":r.querySelector(".card")?"list":"other"}var Wt={win:"В",loose:"П",lose:"П",draw:"Н"};function Zt(r){return B(r,".competitor-form__value").map(a=>Wt[[...a.classList].find(i=>Wt[i])]||M(a).slice(0,1)).filter(Boolean).join("")}function be(r){let a=r.querySelector(".marketbook-header--live");if(a){let e=B(a,".game-scoring__item").map(c=>M(c)),p=B(a,".game-periods .period").map(c=>{let u=B(c,"span");return{label:M(c.querySelector("i")),home:M(u[0]),away:M(u[1])}}).filter(c=>c.home!==""&&c.away!==""),f=B(a,".game-specials > div").map(c=>{let u=B(c,"span"),m=c.querySelector("i"),b=m?.classList.contains("yellow-card")?"жёлтые":m?.classList.contains("red-card")?"красные":m?.classList.contains("penalty-card")?"угловые":"";return b?{kind:b,home:M(u[0]),away:M(u[1])}:null}).filter(Boolean);return{state:M(a.querySelector(".game-timing-state")),score:e.length===2?e:[],periods:p,extras:f}}let i=r.querySelector(".match-card");if(i&&!i.querySelector(".match-card__timer--prematch")){let e=M(i.querySelector(".match-card__main-score")).replace(/\s/g,""),p=B(i,".match-card__score").map(c=>M(c)).filter(c=>/^\d{1,2}$/.test(c)),f=B(r,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(c=>M(c)).filter(c=>/\d\s*:\s*\d/.test(c)).slice(0,5);return{state:M(i.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(e)?e.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:f.map((c,u)=>({label:`${u+1} карта`,raw:c})),extras:[]}}return null}function Kt(r,a){if(Ct(r)!=="match")return null;let i=B(r,".breadcrumbs .breadcrumbs__item").map(b=>M(b)).filter(Boolean),e=M(r.querySelector(".event-breadcrumbs")),p=B(r,".marketbook-header--prematch .competitor-name").map(b=>M(b));if(p.length<2&&(p=B(r,".marketbook-header--live .competitors-desc__name").map(b=>M(b))),p.length<2&&(p=B(r,".match-card .match-card__team-name").map(b=>M(b))),p.length<2||!p[0]||!p[1])return null;let f=ut(i[1]&&/киберспорт/i.test(i[0])?i[1]:"",i[0],e),c=/киберспорт/i.test(i[0]||"")?i.slice(2).join(", ")||e.split(",").slice(1).join(",").trim():i.slice(1).join(", "),u=[M(r.querySelector(".prematch-date")),M(r.querySelector(".prematch-time"))].filter(Boolean).join(" ")||M(r.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),m=be(r);return{book:"Winline",id:Xt(a?.pathname),key:it(p[0],p[1]),home:p[0],away:p[1],sport:f,league:c,start:m?"":u,live:m,form:{home:Zt(r.querySelector(".competitor-form--left")||r.createElement("div")),away:Zt(r.querySelector(".competitor-form--right")||r.createElement("div"))},stats:ze(_e(r),p[0],p[1]),url:a?.href||""}}function xe(r,a){let i=[];for(let e of B(r,".bet-line")){if(Tt(e))continue;let p=M(e.querySelector(".bet-line__market-name")),f=M(e.querySelector(".bet-line__period")),c=B(e,".odd-btn"),u=c.map((b,y)=>{let z=M(b.querySelector(".odd-btn__label")),v=B(b,"span").map(_=>ot(M(_))).find(Boolean)||null;return v?{el:b,odd:v,label:z||Nt(c.length,y,p),locked:!1}:null});if(u.length<2||u.some(b=>!b))continue;let m=M(e.querySelector(".coef-btn")).replace(/\s+/g," ");i.push(lt({scope:"top",title:p,period:f,line:m,outcomes:u,anchor:e,eventKey:a}))}return i}function Nt(r,a,i){return/тотал/i.test(i)?["Меньше","Больше"][a]||"":r===3?["П1","Х","П2"][a]:r===2?["1","2"][a]:String(a+1)}function ye(r,a){let i=[];for(let e of B(r,".market")){let p=B(e,".market__row");if(!p.length)continue;let f=M(e.querySelector(".market-title")),c=p.map(m=>{let b=M(m.querySelector(".market__row-text"));return B(m,".market-row-btn").map(y=>{let z=ot(M(y.querySelector(".market-row-btn__coef")));if(!z||y.hasAttribute("disabled"))return null;let v=y.getAttribute("title")||M(y.querySelector(".market-row-btn__text"));return{el:y,odd:z,label:v.replace(/\s+/g," ").trim(),rowLabel:b,locked:!1}})}),{sets:u}=Rt(c);for(let m of u){let b=[...new Set(m.map(_=>_.rowLabel).filter(Boolean))],y=b.length<=1,z=y?"":(m[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=m.map(_=>({el:_.el,odd:_.odd,label:y?_.label:_.rowLabel||_.label,locked:!1}));i.push(lt({scope:"board",title:f,period:y&&b[0]||"",line:z,kind:bt(f,v.length),outcomes:v,anchor:e,eventKey:a}))}}return i}var ve=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function we(r){let a=B(r,".card__competitors .name .name, .half__names .name").map(e=>M(e));if(a.length<2)return null;let i=r.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Xt(i),key:it(a[0],a[1]),home:a[0],away:a[1],href:i,live:/card--live/.test(r.className)||!!r.querySelector(".card__body-live"),time:M(r.querySelector(".header-left__time, .footer__time")),league:M(r.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:r}}function Vt(r){let a=[];for(let i of B(r,".card")){if(Tt(i))continue;let e=we(i);if(e){for(let p of B(i,".card__body")){let f=M(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let c of B(p,".card__market")){let u=B(c,".coefficient-button");if(u.length<2)continue;let m=(ve.find(([y])=>y.test(u[0].className))||[])[1]||"other",b=u.map((y,z)=>{let v=/--is-blank/.test(y.className)?null:Lt(y);return v?{el:y,odd:v,label:m==="total"?["Меньше","Больше"][z]:Nt(u.length,z,""),locked:/coefficient-button_locked/.test(y.className)}:null});b.some(y=>!y)||a.push(lt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[m]||"Рынок",period:/^матч$/i.test(f)?"":f,line:M(c.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:m,outcomes:b,event:e,anchor:i,eventKey:e.key}))}}for(let p of B(i,".half__coef-buttons")){let f=B(p,".coef-buttons__button"),c=f.map((u,m)=>{let b=Lt(u.querySelector(".button__coef-title")||u);return b?{el:u,odd:b,label:Nt(f.length,m,""),locked:!1}:null});c.length<2||c.some(u=>!u)||a.push(lt({scope:"list",title:c.length===3?"Исход":"Победитель",kind:c.length===3?"1x2":"12",outcomes:c,event:e,anchor:i,eventKey:e.key}))}}}return a}function ke(r){if(!r?.body)return null;let a=m=>/^\d{1,3}\s?%$/.test(m),i=B(r,"h4").map(m=>{let b=[...m.nextElementSibling?.children||[]],y=M(b[0]),z=M(b[b.length-1]);return a(y)&&a(z)?{label:M(m),home:y.replace(/\s/g,""),away:z.replace(/\s/g,"")}:null}).filter(Boolean);if(!i.length)return null;let e=(r.body.innerText||r.body.textContent||"").replace(/\s+/g," "),p=[...e.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(m=>Number(m[1])),c=[...(e.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(m=>m[1].replace(/\s/g,""));return{names:M(r.querySelector("h3")).split(/\s+vs\s+/i).map(m=>m.trim()).filter(Boolean),rows:i,samples:p.slice(0,2),form:c.length>=2?{home:c[0],away:c[1]}:null}}function ze(r,a,i){if(!r||r.names.length<2)return r;let e=gt(r.names[0],a)+gt(r.names[1],i);return gt(r.names[0],i)+gt(r.names[1],a)<=e?r:{names:[r.names[1],r.names[0]],rows:r.rows.map(f=>({label:f.label,home:f.away,away:f.home})),samples:r.samples.slice().reverse(),form:r.form?{home:r.form.away,away:r.form.home}:null}}function _e(r){let a=r.querySelector("iframe.stats__iframe");if(!a)return null;try{return ke(a.contentDocument)}catch{return null}}function $e(r){let a=["one","two"].map(f=>r.querySelector(`.event-live-center__team-widget--${f}`));if(!a[0]||!a[1])return null;let i=f=>{let c=f;try{c=f.querySelector("iframe")?.contentDocument?.body||f}catch{c=f}let u=B(c,'[class*="player"]').filter(b=>!B(b,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(b.className)),m=[];for(let b of u){let y=M(b).split(" ").filter(Boolean),z=y.find(_=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(_)&&/[A-Za-z]/.test(_));if(!z||m.some(_=>_.nick===z))continue;let v=y.filter(_=>/^\d{1,3}$/.test(_)).map(Number);m.push({nick:z,numbers:v.slice(0,4)})}return m.slice(0,5)},e=i(a[0]),p=i(a[1]);return e.length<3||p.length<3?null:{home:e,away:p}}var Ut={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:Ct,readMatch:Kt,readEsportsWidget:$e,observeTargets(r){try{let a=r.querySelector("iframe.stats__iframe")?.contentDocument?.body;return a?[a]:[]}catch{return[]}},collect(r,a){if(Ct(r)==="match"){let p=Kt(r,a)?.key||"";return[...xe(r,p),...ye(r,p),...Vt(r)]}return Vt(r)}};var kt=(r,a)=>{try{return[...r.querySelectorAll(a)]}catch{return[]}};function Ht(r,a){let i=[r];if(a.shadow)for(let e of kt(r,a.shadow))e.shadowRoot&&i.push(e.shadowRoot);return i}var wt=r=>(r.defaultView?.innerWidth||0)>0,Me='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function Se(r){let a=[],i=r.ownerDocument.createTreeWalker(r,4);for(;i.nextNode();){let e=i.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(e&&a.push(...e.split(" ")),a.length>5)return null}return a}function Te(r,a){if(r.disabled||r.hasAttribute?.("disabled"))return null;let i=a.value&&r.querySelector(a.value)||r,e=Se(i);if(!e||!e.length||e.join(" ").length>28)return null;let p=e[e.length-1];if(!(a.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let f=ot(p);if(!f||f>500||e.slice(0,-1).some(u=>/^\d{1,3}[.,]\d{1,3}$/.test(u)))return null;let c=e.slice(0,-1).join(" ");return!a.outcome&&/[+−]|^-/.test(c)?null:{odd:f,label:c}}function Le(r,a){let i=[],e=new Set,p=Ht(r,a).flatMap(f=>kt(f,a.outcome||Me));for(let f of p){if(e.has(f)||a.skip&&f.closest(a.skip)||f.closest("#lz-root, #lz-marks"))continue;let c=Te(f,a);if(c){if(!a.outcome&&wt(r)){let u=f.getBoundingClientRect();if(u.width<26||u.width>320||u.height<16||u.height>90)continue}e.add(f),i.push({el:f,odd:c.odd,label:c.label,locked:!1})}}return a.outcome?i:i.filter(f=>!i.some(c=>c.el!==f.el&&c.el.contains(f.el)))}function Ce(r,a,i){if(a.row)return r.closest(a.row);let e=r.parentElement;for(let p=0;p<6&&e&&e!==e.ownerDocument.body;p+=1){let f=i(e);if(f>=2&&f<=16){if(!wt(e.ownerDocument))return e;let c=e.getBoundingClientRect();if(c.height<=130&&c.width>=120)return e}if(f>16)break;e=e.parentElement}return null}var Yt=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function Ne(r,a){let i=a.length,e=r;for(let y=0;y<7;y+=1){let z=e.parentElement;if(!z||a.some(A=>!z.contains(A.el))||z.querySelectorAll("*").length>400||[...z.querySelectorAll('button, a, td, [role="button"]')].filter(A=>!a.some(O=>O.el===A||O.el.contains(A)||A.contains(O.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(M(A))).length>i)break;e=z}let p=a[0].el,f=[],c=e.ownerDocument.createTreeWalker(e,4);for(;c.nextNode();){let y=c.currentNode;if(p.contains(y))break;let z=y.textContent.replace(/[ \s]+/g," ").trim();z.length<2||z.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(z)||/\d{1,2}:\d{2}|^\d|['′]$/.test(z)||Yt.test(z)||f.push(z)}let u=f.slice(-2),m=f.map(y=>y.split(/\s+[—–-]\s+/)).filter(y=>y.length===2).pop();if(m&&(u=m),u.length<2||u[0]===u[1])return null;let b=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:it(u[0],u[1]),home:u[0],away:u[1],href:b,live:!1,time:"",league:"",card:e}}function Ae(r,a,i){if(!a.names)return Ne(r,i);let e=a.event&&r.closest(a.event)||r,p=[...new Set(kt(e,a.names).map(u=>M(u)).filter(Boolean))],f=p;if(p.length===1&&(f=p[0].split(/\s+[—–-]\s+/)),f.length<2||!f[0]||!f[1])return null;let c=e.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:it(f[0],f[1]),home:f[0],away:f[1],href:c,live:!1,time:"",league:"",card:e}}function Oe(r){let i=String(r.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!i)return null;let e=[i[1].trim(),i[2].trim()];return e.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:e}function Gt(r,a={}){function i(v,_){return a.matchUrl&&a.matchUrl.test(_?.pathname||"")||a.matchPage&&v.querySelector(a.matchPage)?"match":"list"}function e(v){let _=v.defaultView;if(!_||!wt(v))return[];let A=[];for(let O of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if(O.children.length)continue;let N=M(O);if(N.length<3||N.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(N)||/\d{1,2}[:.]\d{2}/.test(N)||Yt.test(N))continue;let R=O.getBoundingClientRect();if(!(R.top<60||R.top>450||R.width<30||parseFloat(_.getComputedStyle(O).fontSize)<15)&&(A.includes(N)||A.push(N),A.length===2))break}return A}function p(v,_){if(i(v,_)!=="match")return null;let A=a.matchNames?kt(v,a.matchNames).map(N=>M(N)).filter(Boolean):[];if(A.length===1&&(A=A[0].split(/\s+[—–-]\s+/)),A.length<2&&(A=Oe(v)||[]),A.length<2&&(A=e(v)),A.length<2)return null;let O=a.matchLeague?M(v.querySelector(a.matchLeague)):"";return{book:r.name,id:(String(_?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:it(A[0],A[1]),home:A[0],away:A[1],sport:ut(_?.pathname,O,v.title),league:O,start:"",live:null,form:{home:"",away:""},url:_?.href||""}}function f(v,_){return!v||!_?"":_.startsWith("attr:")?String(v.getAttribute(_.slice(5))||"").trim():M(v.querySelector(_))}function c(v,_){if(!wt(_))return[v];let A=v.map(N=>{let R=N.el.getBoundingClientRect();return{cell:N,top:R.top,left:R.left}}).sort((N,R)=>Math.abs(N.top-R.top)>8?N.top-R.top:N.left-R.left),O=[];for(let N of A){let R=O[O.length-1];R&&Math.abs(R.top-N.top)<=8?R.cells.push(N.cell):O.push({top:N.top,cells:[N.cell]})}return O.map(N=>N.cells)}let u=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],m=v=>(u.find(([_])=>_.test(v.join("/").toLowerCase()))||[])[1]||"other";function b(v,_){let A=i(v,_),O=A==="match"&&a.match?{...a,...a.match}:a;return y(v,_,A,O)}function y(v,_,A,O){let N=Le(v,O);if(N.length<2)return[];let R=new Set(N.map(T=>T.el)),G=T=>{let C=0;for(let E of R)T.contains(E)&&(C+=1);return C},H=new Map;for(let T of N){let C=Ce(T.el,O,G);C&&(H.has(C)||H.set(C,[]),H.get(C).push(T))}let et=A==="match"?p(v,_):null,F=[];for(let[T,C]of H){let E=A==="match"?null:Ae(T,O,C),S=O.group?T.closest(O.group):null,q=f(S,O.groupTitle),j=f(S,O.groupPeriod),P=O.visualRows?c(C,v):[C],I=0;for(let K of P)for(let X of Pt(K).sets){let J=I===0,Q=X.length,ft=Q===3?["П1","Х","П2"]:["1","2"],ct=X.map((nt,dt)=>({...nt,label:nt.label||ft[dt]||String(dt+1)})),st=J&&Q===3?"Исход":J?"Победитель":`Рынок ${I+1}`,Y=J?Q===3?"1x2":"12":"other";q&&(st=q,Y=bt(q,Q),Y==="other"&&(Y=m(ct.map(nt=>nt.label)))),F.push(lt({scope:A==="match"?"board":"list",title:st,period:j,kind:Y,outcomes:ct,event:E,anchor:T,eventKey:E?.key||et?.key||`row${F.length}`})),I+=1}}return F}let z=v=>Ht(v,a).slice(1);return{id:r.id,name:r.name,hosts:r.hosts,generic:!0,pageType:i,readMatch:p,collect:b,observeTargets:z,readEsportsWidget:()=>null}}var Qt={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]'},Jt={fonbet:Qt,pari:Qt,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function te(r){let a=qt(r);return a?a.id==="winline"?{adapter:Ut,book:a}:{adapter:Gt(a,Jt[a.id]||{}),book:a}:null}var zt=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var ee=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(r,a,...i){let[e,...p]=r.split("."),f=document.createElement(e||"div");p.length&&(f.className=p.join(" "));for(let[c,u]of Object.entries(a||{}))if(!(u==null||u===!1))if(c==="class")f.className=[f.className,u].filter(Boolean).join(" ");else if(c==="style")f.style.cssText=u;else if(c==="text")f.textContent=u;else{if(c==="html")throw new Error("html запрещён");c.startsWith("data-")||c.startsWith("aria-")||c==="role"||c==="title"||c==="type"||c==="href"||c==="target"||c==="rel"||c==="placeholder"||c==="value"||c==="for"||c==="name"||c==="maxlength"||c==="autocomplete"||c==="spellcheck"||c==="tabindex"?f.setAttribute(c,u===!0?"":String(u)):c==="disabled"||c==="hidden"||c==="checked"||c==="selected"?f[c]=!!u:f[c]=u}return oe(f,i),f}function oe(r,a){for(let i of a)i==null||i===!1||(Array.isArray(i)?oe(r,i):r.appendChild(i instanceof Node?i:document.createTextNode(String(i))))}var ne="http://www.w3.org/2000/svg";function W(r,a=16){let i=document.createElementNS(ne,"svg");i.setAttribute("viewBox","0 0 20 20"),i.setAttribute("width",a),i.setAttribute("height",a),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.7"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("aria-hidden","true");for(let e of Be[r]||[]){let p=document.createElementNS(ne,"path");p.setAttribute("d",e),i.appendChild(p)}return i}var Be={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function re(){let r=document.createElement("div");r.id="lz-marks",r.style.cssText="position:absolute!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let a=r.attachShadow({mode:"open"});a.appendChild(t("style",{text:zt+ee}));let i=t("div.layer"),e=t("div.tip");a.append(i,e);let p=new Map,f=new Set,c=0,u=null,m=null,b=new IntersectionObserver(T=>{for(let C of T)C.isIntersecting?f.add(C.target):(f.delete(C.target),p.get(C.target)?.node.classList.remove("on"));z()},{rootMargin:"120px"});function y(){r.isConnected||document.documentElement.appendChild(r)}function z(){c||(c=requestAnimationFrame(()=>{c=0,A()}))}let v=(T,C)=>{for(let E=C;E;E=E.parentNode||E.host)if(E===T)return!0;return!1};function _(T,C){let E=C.left+C.width/2,S=C.top+C.height/2;if(E<0||S<0||E>window.innerWidth||S>window.innerHeight)return!1;let q=document.elementFromPoint(E,S);for(;q?.shadowRoot?.elementFromPoint;){let j=q.shadowRoot.elementFromPoint(E,S);if(!j||j===q)break;q=j}return!!q&&q!==T&&!v(T,q)&&!v(q,T)}function A(){let T=window.scrollX,C=window.scrollY;for(let E of f){let S=p.get(E);if(!S)continue;if(!E.isConnected){O(E);continue}let q=E.getBoundingClientRect();if(q.width<6||q.height<6||_(E,q)){S.node.classList.remove("on");continue}let j=Math.round(q.left+T),P=Math.round(q.top+C),I=Math.round(q.width),K=Math.round(q.height);(S.x!==j||S.y!==P)&&(S.node.style.transform=`translate3d(${j}px, ${P}px, 0)`,S.x=j,S.y=P),(S.w!==I||S.h!==K)&&(S.node.style.width=`${I}px`,S.node.style.height=`${K}px`,S.w=I,S.h=K,S.node.classList.toggle("small",K<26)),S.node.classList.add("on")}u&&R()}function O(T){let C=p.get(T);C&&(b.unobserve(T),f.delete(T),C.node.remove(),p.delete(T))}function N(T){y();let C=new Map;for(let E of T)E.el?.isConnected&&C.set(E.el,E);for(let E of[...p.keys()])C.has(E)||O(E);for(let[E,S]of C){let q=p.get(E);if(!q){let P=t("div.mark"),I=parseFloat(getComputedStyle(E).borderTopLeftRadius);P.style.borderRadius=`${Number.isFinite(I)&&I>0?Math.min(I,16):6}px`;let K=t("span.chip");P.appendChild(K),i.appendChild(P),q={node:P,chip:K,sig:""},p.set(E,q),b.observe(E)}let j=`${S.frame?1:0}|${S.selected?1:0}|${S.tone||""}|${S.chip||""}`;j!==q.sig&&(q.sig=j,q.node.classList.toggle("frame",!!S.frame),q.node.classList.toggle("selected",!!S.selected),q.node.classList.toggle("pos",S.tone==="pos"&&!!S.frame),q.chip.hidden=!S.chip,q.chip.textContent=S.chip||"",q.chip.className=`chip${S.tone&&S.tone!=="accent"?" "+S.tone:""}`)}z()}function R(){if(!u?.isConnected)return H();let T=u.getBoundingClientRect(),C=264,E=e.offsetHeight||140,S=T.left+T.width/2-C/2;S=Math.max(8,Math.min(S,window.innerWidth-C-8)),m&&S+C>m.left-8&&S<m.right&&(S=Math.max(8,m.left-C-10));let q=T.bottom+10;q+E>window.innerHeight-8&&(q=T.top-E-10),q<8&&(q=8),e.style.transform=`translate3d(${Math.round(S+window.scrollX)}px, ${Math.round(q+window.scrollY)}px, 0)`}function G(T,C){y(),u=T,e.replaceChildren(C),R(),e.classList.add("on")}function H(){u=null,e.classList.remove("on")}function et(T){m=T}function F(T){r.setAttribute("data-theme",T)}return window.addEventListener("scroll",z,{capture:!0,passive:!0}),window.addEventListener("resize",z,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&z()},700),{set:N,schedule:z,showTip:G,hideTip:H,setTheme:F,setAvoid:et,get tipTarget(){return u},count:()=>p.size}}var ae=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 88px 44px;
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-faint);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var V=(r,a=0)=>rt(r,a),xt=r=>`${r>0?"+":r<0?"−":""}${Math.abs(r).toFixed(1)}`;function se({bus:r,actions:a,brand:i}){let e=document.createElement("div");e.id=r.rootId,e.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=e.attachShadow({mode:"open"});p.appendChild(t("style",{text:zt+ae}));let f=t("span.dot"),c=t("button.fab",{type:"button","data-act":"toggle",title:`${i.name}: открыть панель`,"aria-label":`${i.name}: открыть панель`},W("lens",18),t("span",{text:i.name}),f),u=t("div.tabs",{role:"tablist"}),m=t("div.body"),b=t("div.foot"),y=t("small"),z=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),_=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},W("gear")),A=t("div.head",{},t("div.brand",{},t("span.logo",{},W("lens",15)),t("span",{text:i.name}),y),t("span.grow"),v,z,_,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},W("close"))),O=t("section.panel",{hidden:!0,role:"dialog","aria-label":i.name},A,u,m,b);p.append(c,O);let N=()=>{e.isConnected||document.documentElement.appendChild(e)};N(),new MutationObserver(N).observe(document.documentElement,{childList:!0});let R="",G=null,H=new Map,et=n=>{for(let o of n.composedPath()){if(o===e)break;if(o?.dataset?.act)return o}return null},F=null;r.on("ui:pointerdown",n=>{if(n.button!==0)return;let o=n.composedPath(),l=o.includes(c),h=o.includes(A)&&!o.some(w=>w?.dataset?.act);if(!l&&!h)return;let k=l?c:O,x=k.getBoundingClientRect();F={target:k,key:l?"fab":"panel",sx:n.clientX,sy:n.clientY,ox:x.left,oy:x.top,moved:!1},r.setDragging(!0)}),r.on("drag:move",n=>{if(!F)return;let o=n.clientX-F.sx,l=n.clientY-F.sy;!F.moved&&Math.hypot(o,l)<5||(F.moved=!0,F.target.classList.add("dragging"),C(F.target,F.ox+o,F.oy+l))}),r.on("drag:end",()=>{if(F){if(r.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let n=F.target.getBoundingClientRect();a.savePosition(F.key,{left:n.left,top:n.top}),T=!0,setTimeout(()=>{T=!1},60)}F=null}});let T=!1;function C(n,o,l){let h=n.offsetWidth||120,k=n.offsetHeight||40,x=Math.max(6,Math.min(o,window.innerWidth-h-6)),w=Math.max(6,Math.min(l,window.innerHeight-Math.min(k,60)-6));n.style.left=`${Math.round(x)}px`,n.style.top=`${Math.round(w)}px`,n.style.right="auto"}r.on("ui:click",n=>{if(T)return;let o=et(n);if(!o||o.disabled)return;n.preventDefault();let l=o.dataset.act;if(l==="toggle")return ht();if(l==="close")return tt();let h=a[l];h&&h(o.dataset.arg,o,p)}),r.on("ui:keydown",n=>{if(n.key==="Escape"&&tt(),n.key==="Enter"){let o=n.composedPath()[0];o?.dataset?.enter&&a[o.dataset.enter]?.(o.value,o,p)}});let E=(n,o)=>t("span.form",{},[...String(n||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function S(n){let o=n.live,l=o?t("div.center",{},o.score?.length===2?t("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,t("span.badge.live",{text:o.state||"Лайв"})):t("div.center",{},t("span",{text:n.start||"до матча"})),h=o?.periods?.length?t("div.periods",{text:o.periods.map(x=>x.raw?`${x.label} ${x.raw}`:`${/^\d+$/.test(x.label)?`${x.label}-й отрезок`:x.label} ${x.home}:${x.away}`).join(" · ")}):null,k=o?.extras?.length?t("div.periods",{text:o.extras.map(x=>`${x.kind} ${x.home}:${x.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:n.league||n.sportName||"",title:n.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:n.home,title:n.home}),n.form?.home?E(n.form.home):null),l,t("div.team.away",{},t("b",{text:n.away,title:n.away}),n.form?.away?E(n.form.away):null)),h,k)}function q(n){let o=n.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:n.title}),Number.isFinite(n.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${V(n.margin,1)}`}):null),n.rows.map(l=>{let h=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:Z(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},V(o&&Number.isFinite(l.model)?l.model:l.fair),h!=null&&Math.abs(h)>=.05?t(`small${h>0?".pos":".neg"}`,{text:`${xt(h)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),o?t("span.model",{text:"оценка модели"}):null))}function j(n){let o=n.analysis;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},o.steps.map((w,L)=>t(`div.step${L===o.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:w})))));if(o.status==="error")return t("div.card",{},t("div.note.warn",{},W("alert"),t("span",{text:o.error})),o.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},W("gear"),"Открыть настройки")):null);if(o.status!=="done"||!o.result)return null;let l=o.result,h={home:n.match?.home,away:n.match?.away,draw:"ничья"}[l.lean],k=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:n.match?.home,away:n.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,x=new Map((l.facts||[]).map(w=>[w.id,w]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:h?`Данные сдвигают оценку в сторону: ${h}`:k?`Данные слегка склоняют в сторону: ${k.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),k?t("div.note",{style:"margin-bottom:10px"},W("info"),t("span",{text:`Модель предложила сдвиг на ${k.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(w=>t(`li.factor${w.side==="home"?".home":w.side==="away"?".away":""}`,{},t("div",{},t("p",{text:w.text}),t("div.src",{},(w.facts||[]).map(L=>x.get(L)).filter(Boolean).map(L=>t("span.tag",{text:`${L.id} · ${L.source}`,title:L.text}))))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},W("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:H.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(w=>t("li",{},t("b",{text:w.id}),t("span",{},w.text," ",t("em",{text:`— ${w.source}`})))))),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function P(n){let o=n.compare?.consensus||n.analysis?.result?.consensus;if(!o?.consensus||!n.line?.rows?.length)return null;let l=o.consensus.length===2&&n.line.rows.length===3;if(!l&&n.line.rows.length!==o.consensus.length)return null;let h=l?[n.line.rows[0],n.line.rows[2]].map(x=>({...x,fair:null})):n.line.rows,k=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${o.count} контор`})),h.map((x,w)=>{let L=o.consensus[w],$=x.odd*L-1,D=Number.isFinite(x.fair)?(x.fair-L)*100:0;return t("div.prob",{},t("span.name",{text:x.name,title:x.name}),t("span.odd",{text:Z(1/L),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(L*100)}%`}),t("u",{style:`left:${Math.round((x.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},V(L),$>.005?t("small.pos",{text:`кэф выше рынка ${xt($*100)}%`}):Math.abs(D)>=2?t(`small${D>0?".neg":""}`,{text:`${xt(D)} п.п. к рынку`,title:D>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l?null:t("span.model",{text:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l?"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(Z).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(Z).join(" / ")}. `:""}Цены ${o.count} контор без маржи${k?`, обновлено в ${k}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}function I(n){let o=n.compare?.model||n.analysis?.result?.model;if(!o?.p1||!n.line?.rows?.length||n.line.rows.length!==2)return null;let l=[o.p1,o.p2],h=o.backtest,k=(h?.calibration||[]).filter(w=>[60,70,80].includes(w.threshold)),x=k.length?`На проверке ${h.test} сыгранных матчей: ${k.map(w=>`при уверенности ≥${w.threshold}% сбывалось ${w.hit}%`).join(", ")}`:h?`На проверке ${h.test} матчей угадано ${Math.round(h.acc*100)}%`:"Точность ещё измеряется";return t("div.card",{},t("div.kicker",{},t("span",{text:"Прогноз модели"}),t("span.badge",{text:`уверенность: ${o.confidence}`})),n.line.rows.map((w,L)=>{let $=l[L],D=Number.isFinite(w.fair)?($-w.fair)*100:0;return t("div.prob",{},t("span.name",{text:w.name,title:w.name}),t("span.odd",{text:Z(1/$),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round($*100)}%`}),t("u",{style:`left:${Math.round((w.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},V($),Math.abs(D)>=3?t(`small${D>0?".pos":".neg"}`,{text:`${xt(D)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),o.factors?.length?t("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,4).map(w=>t("li",{},t("span",{text:w})))):null,t("div.hint",{style:"margin-top:8px",text:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} карт у менее опытной команды). ${x}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function K(n){if(n.status==="idle")return null;if(n.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let o=n.labels||[];if(!n.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:n.note||"В открытых линиях этой пары нет."}));let l=o.map((h,k)=>Math.max(...n.rows.map(x=>x.odds[k]||0)));return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),o.map(h=>t("th",{text:h}))),n.rows.map(h=>t("tr",{},t("td.name",{text:h.name,title:h.sharp?"Цена с мирового рынка, для сравнения":""}),h.odds.map((k,x)=>t(`td${k&&k===l[x]&&n.rows.length>1?".best":""}`,{text:k?Z(k):"—"}))))),n.note?t("div.hint",{style:"margin-top:8px",text:n.note}):null)}function X(n){let o=[],l=(h,k,x)=>o.push(t("dt",{text:h}),t(`dd${x?"."+x:""}`,{text:k}));return Number.isFinite(n.fair)?(l("Шанс по линии без маржи",V(n.fair,1)),l("Кэф без маржи конторы",Z(n.fairOdd)),l("Маржа конторы в этом рынке",V(n.margin,1))):l("Заложено в кэфе (с маржой)",V(1/n.odd,1)),Number.isFinite(n.model)&&(l("Оценка модели",V(n.model,1)),l("Ожидание на рубль по модели",`${xt(n.ev*100)}%`,n.ev>.005?"pos":n.ev<-.005?"neg":"")),n.best&&l(`Лучшая цена: ${n.best.name}`,Z(n.best.odd),n.best.odd>n.odd?"pos":""),t("div.card.accent",{},t("div.kicker",{},t("span",{text:n.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},W("close",13))),t("div.pick-head",{},t("span.big",{text:Z(n.odd)}),t("span.what",{text:n.label,title:n.label})),t("dl.kv",{},o),n.note?t("div.hint",{style:"margin-top:8px",text:n.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!n.canAdd,title:n.canAdd?"":"Нужен рынок с полным набором исходов"},W("plus",14),n.inExpress?"Уже в экспрессе":"В расчёт экспресса")))}function J(n){let o=(l,h)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),h.map(k=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:k.nick}),t("span",{style:"color:var(--lz-muted)",text:k.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(n.homeName,n.home),o(n.awayName,n.away)))}function Q(n,o){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:o.home}),t("th",{text:o.away})),n.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),n.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${n.samples[0]} и ${n.samples[1]} карт.`}):null)}function ft(n){let o=[];if(n.pick&&o.push(X(n.pick)),!n.match)return o.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(S(n.match)),n.esports&&o.push(J(n.esports)),n.match.stats?.rows?.length&&o.push(Q(n.match.stats,n.match)),n.line&&o.push(q(n.line));let l=P(n);l&&o.push(l);let h=I(n);h&&o.push(h);let k=n.analysis.status==="loading";o.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:k},W("spark"),k?"Разбираю…":n.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:n.compare.status==="loading"},W("scale"),"Сравнить цены"))),n.quota&&o.push(t("div.hint.center-text",{text:n.quota}));let x=j(n);x&&o.push(x);let w=K(n.compare);return w&&o.push(w),o}function ct(n){let o=n.scan;return o?.rows?.length?[t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),t("span.badge",{text:`средняя маржа ${V(o.average,1)}`})),t("table",{},t("tr",{},t("th",{text:o.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),o.rows.map(l=>t("tr.click",{"data-act":"scan-go","data-arg":String(l.index),title:"Показать на странице"},t("td.name",{},l.name,l.sub?t("span.sub",{text:l.sub}):null),t("td",{},l.fav,t("span.sub",{text:V(l.favPct)})),t(`td${l.low?".best":""}`,{text:V(l.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:o.note}))]:[t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function st(n){let o=n.express;if(!o.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${o.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},W("trash",13),"Очистить")),o.legs.map(h=>t("div.leg",{},t("div.t",{},t("b",{text:h.label,title:h.label}),t("span",{text:h.title,title:h.title})),t("span.o",{text:Z(h.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":h.id,title:"Убрать",style:"width:24px;height:24px"},W("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:Z(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:V(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:Z(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:V(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function Y(n){let o=n.edges||{status:"idle"},l=$=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),$?t("span.badge",{text:$}):null);if(o.status==="loading"&&!o.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[t("div.card",{},l(),t("div.note.warn",{},W("alert"),t("span",{text:o.error})))];let h=o.data;if(!h)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let k=$=>$==null?"—":`${$>=0?"+":"−"}${(Math.abs($)*100).toFixed(1)}%`,x=$=>new Date($).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),w=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(h.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(h.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:k(h.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:h.positiveWeek==null?"—":V(h.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),L=(h.signals||[]).map($=>t("tr",{},t("td.name",{},`${$.home} — ${$.away}`,t("span.sub",{text:`${$.league} · ${x($.start)}`})),t("td",{},$.label,t("span.sub",{text:$.book})),t("td",{text:Z($.odds)}),t("td",{text:Z(1/$.p),title:`Честная цена по ${$.count} конторам`}),t("td.best",{text:`+${($.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(h.full?"тариф «Макс»":"витрина"),L.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),L):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),h.note?t("div.hint",{style:"margin-top:8px"},h.note," ",i.bot?t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),w]}function nt(n){let o=n.settings,l=(h,k,x)=>t("div.seg",{},x.map(([w,L])=>t(`button${k===w?".on":""}`,{type:"button","data-act":h,"data-arg":w,text:L})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]]))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),i.bot&&!o.licenseMask?[" ",t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function dt(n){G=n;let o=JSON.stringify(n);if(o===R)return;R=o;for(let x of m.querySelectorAll("details[data-key]"))H.set(x.dataset.key,x.open);let l=m.scrollTop;y.textContent=n.bookName?`· ${n.bookName}`:"",f.classList.toggle("off",n.settings.overlay==="off"),z.replaceChildren(W(n.theme==="dark"?"sun":"moon")),v.replaceChildren(W(n.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",n.settings.overlay!=="off"),_.classList.toggle("on",n.tab==="settings"),_.dataset.arg=n.tab==="settings"?n.backTab:"settings";let h=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];u.replaceChildren(...h.map(([x,w])=>t(`button.tab${n.tab===x?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":x},w,x==="express"&&n.express.legs.length?t("span.count",{text:String(n.express.legs.length)}):null)));let k=n.tab==="settings"?nt(n):n.tab==="scan"?ct(n):n.tab==="express"?st(n):n.tab==="edges"?Y(n):ft(n);m.replaceChildren(...k.filter(Boolean)),m.scrollTop=l,b.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function yt(n){e.setAttribute("data-theme",n)}function mt(){O.hidden=!1,a.opened?.()}function tt(){O.hidden=!0}function ht(){O.hidden?mt():tt()}function s(n){n?.fab&&C(c,n.fab.left,n.fab.top),n?.panel&&C(O,n.panel.left,n.panel.top)}let d=0;function g(n){p.querySelector(".toast")?.remove();let o=t("div.toast",{text:n,role:"status"});p.appendChild(o),clearTimeout(d),d=setTimeout(()=>o.remove(),2600)}return{render:dt,setTheme:yt,open:mt,close:tt,toggle:ht,restore:s,toast:g,shadow:p,rect:()=>O.hidden?null:O.getBoundingClientRect(),get isOpen(){return!O.hidden},get view(){return G}}}var ie="Расширение обновилось. Обновите эту вкладку (F5).";function at(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function U(r,a={}){if(!at())return{ok:!1,error:ie,code:"reload"};try{return await chrome.runtime.sendMessage({type:r,...a})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(i){let e=String(i?.message||i);return/context invalidated|message port closed|receiving end does not exist/i.test(e)||!at()?{ok:!1,error:ie,code:"reload"}:{ok:!1,error:e}}}function le(r){if(at())try{chrome.runtime.onMessage.addListener(a=>{r(a)})}catch{}}async function At(r){if(!at())return{};try{return await chrome.storage.local.get(r)}catch{return{}}}function pt(r){if(at())try{chrome.storage.local.set(r)}catch{}}var _t=globalThis.__lzBus,Ot=_t&&window.top===window?te(location.hostname):null;Ot&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Re(Ot.adapter,Ot.book));async function Re(r,a){let i=await At(["lz.settings","lz.positions","lz.express"]),e={settings:{...$t,...i["lz.settings"]||{}},positions:(i["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Pe(i["lz.express"]),analysis:new Map,compare:new Map,edges:{status:"idle",data:null,error:"",at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,f=new WeakMap,c=re(),u=se({bus:_t,brand:Et,actions:ct()});u.restore(e.positions);function m(s){let d=s.outcomes.map(o=>o.odd).join("/"),g=p.get(s);if(g?.sig===d)return g.set;let n=Mt(s.outcomes.map(o=>o.odd));return p.set(s,{sig:d,set:n}),n}function b(){return e.match?e.analysis.get(e.match.key):null}function y(s){let d=b()?.result;if(!d?.model||s.scope==="list"||!e.match||!Object.values(d.shift||{}).some(h=>Math.abs(h)>=.5))return null;let{home:g,draw:n,away:o}=d.model,l=s.outcomes.length;if(s.kind==="1x2"&&s.main&&l===3)return[g,n,o];if(s.kind==="12"&&s.main&&l===2&&n<.005)return[g,o];if(s.kind==="dc"&&s.main&&l===3)return[g+n,g+o,n+o];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&l===2){let h=s.period===e.match.home?g:s.period===e.match.away?o:null;if(h!=null)return[h,1-h]}return null}function z(){let s=e.markets.filter(d=>d.scope!=="list"&&d.main&&(d.kind==="1x2"||d.kind==="12"));return s.find(d=>d.scope==="top")||s[0]||null}function v(s,d){let g=s.outcomes[d].label;return s.scope==="list"?!s.event||!s.main?g:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][d]||g:s.kind==="12"&&[s.event.home,s.event.away][d]||g:e.match?s.kind==="1x2"?[e.match.home,"Ничья",e.match.away][d]||g:s.kind==="12"&&[e.match.home,e.match.away][d]||g:g}function _(){let s=e.settings.overlay,d=[];for(let n of e.markets){if(n.outcomes.forEach((L,$)=>f.set(L.el,{market:n,index:$})),s==="off")continue;let o=m(n);if(o.kind==="partial")continue;let l=y(n),h=l||o.fair,k=0;for(let L=1;L<o.fair.length;L+=1)o.fair[L]>o.fair[k]&&(k=L);let x="accent";if(l){let L=0;for(let $=1;$<l.length;$+=1)l[$]-o.fair[$]>l[L]-o.fair[L]&&(L=$);l[L]-o.fair[L]>=.015&&(k=L,x="pos")}let w=n.scope!=="list"||n.main&&(n.kind==="1x2"||n.kind==="12");n.outcomes.forEach((L,$)=>{let D=$===k&&w;!D&&s!=="all"||d.push({el:L.el,frame:D,chip:rt(h[$]),tone:D?x:"quiet"})})}let g=A();if(g){let n=d.find(o=>o.el===g.item.el);n?n.selected=!0:d.push({el:g.item.el,frame:!1,selected:!0,chip:null})}c.set(d)}function A(){if(!e.selected)return null;let s=e.markets.find(g=>g.id===e.selected.id),d=s?.outcomes[e.selected.index];return d?.el?.isConnected?{market:s,item:d,index:e.selected.index}:null}function O(){if(e.settings.theme!=="auto")return e.settings.theme;for(let s of[document.body,document.documentElement]){let g=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!g||g[4]==="0")continue;return(.2126*g[1]+.7152*g[2]+.0722*g[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function N(){location.href!==e.url&&(e.url=location.href,e.selected=null,c.hideTip());let s="other",d=[],g=null;try{s=r.pageType(document,location),d=r.collect(document,location),g=r.readMatch(document,location)}catch(o){console.error("[Линза] страница не прочитана",o)}s!==e.pageType&&(e.pageType=s,e.tab!=="settings"&&e.tab!=="express"&&(e.tab=s==="match"?"match":"scan")),e.markets=d,e.match=g;let n=O();n!==e.theme&&(e.theme=n),c.setTheme(e.theme),u.setTheme(e.theme),_(),Q(),H(),u.isOpen&&u.render(j())}let R=new Set,G=null;function H(){if(r.observeTargets)for(let s of r.observeTargets(document))R.has(s)||(R.add(s),G=G||new MutationObserver(T),G.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let et=0,F=0;function T(){let s=Date.now();F||(F=s),clearTimeout(et);let d=s-F>900?0:220;et=setTimeout(()=>{F=0,!document.hidden&&N()},d)}function C(){let s=z();if(!s)return null;let d=m(s);if(d.kind!=="full")return null;let g=y(s);return{title:"Что заложено в цене",margin:d.margin,rows:s.outcomes.map((n,o)=>({name:v(s,o),odd:n.odd,fair:d.fair[o],model:g?g[o]:null}))}}function E(){let s=A();if(!s)return null;let{market:d,item:g,index:n}=s,o=m(d),l=y(d),h=o.fair?o.fair[n]:null,k=d.event?`${d.event.home} — ${d.event.away}`:e.match?`${e.match.home} — ${e.match.away}`:"",x=e.match?e.compare.get(e.match.key):null,w=null;if(x?.rows?.length&&d.main&&(d.kind==="1x2"||d.kind==="12")&&d.scope!=="list")for(let $ of x.rows){let D=$.odds[n];D&&(!w||D>w.odd)&&(w={name:$.name,odd:D})}let L=`${d.id}#${n}`;return{market:[d.title,d.period,d.line].filter(Boolean).join(" · "),label:[v(d,n),k].filter(Boolean).join(" · "),odd:g.odd,fair:h,margin:o.margin,fairOdd:h?1/h:null,model:l?l[n]:null,ev:l?Dt(l[n],g.odd):null,best:w,canAdd:Number.isFinite(h)&&!e.express.some($=>$.id===L),inExpress:e.express.some($=>$.id===L),note:o.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":l?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function S(){let s=[];if(e.pageType==="match"?e.markets.forEach((o,l)=>{if(o.scope==="list")return;let h=m(o);if(h.kind!=="full")return;let k=0;for(let x=1;x<h.fair.length;x+=1)h.fair[x]>h.fair[k]&&(k=x);s.push({index:l,name:o.title,sub:[o.period,o.line].filter(Boolean).join(" · "),margin:h.margin,fav:o.outcomes[k].label,favPct:h.fair[k]})}):e.markets.forEach((o,l)=>{if(!o.event||!o.main||o.kind!=="1x2"&&o.kind!=="12")return;let h=m(o);if(h.kind!=="full")return;let k=0;for(let w=1;w<h.fair.length;w+=1)h.fair[w]>h.fair[k]&&(k=w);let x=o.kind==="1x2"?[o.event.home,"Ничья",o.event.away][k]:[o.event.home,o.event.away][k];s.push({index:l,name:`${o.event.home} — ${o.event.away}`,sub:o.event.league||o.event.time,margin:h.margin,fav:x,favPct:h.fair[k]})}),!s.length)return null;let d=new Set;for(let o=s.length-1;o>=0;o-=1){let l=`${s[o].name}|${s[o].sub}`;d.has(l)?s.splice(o,1):d.add(l)}let g=s.reduce((o,l)=>o+l.margin,0)/s.length;s.sort((o,l)=>o.margin-l.margin);let n=s.slice(0,16);return n.forEach(o=>{o.low=o.margin<=g*.8}),{title:e.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:e.pageType==="match"?"Рынок":"Матч",average:g,rows:n,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${n.length} из ${s.length}, сначала самые дешёвые.`}}function q(){let s=e.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function j(){let s=e.match?.key,d=s&&e.analysis.get(s)||{status:"idle",steps:[]},g=s&&e.compare.get(s)||{status:"idle"},n=e.match?.live&&r.readEsportsWidget?r.readEsportsWidget(document):null,o=e.status;return{tab:e.tab,backTab:e.backTab,theme:e.theme,bookName:a.name,pageType:e.pageType,match:e.match?{...e.match,sportName:Bt[e.match.sport]||""}:null,esports:n?{...n,homeName:e.match.home,awayName:e.match.away}:null,line:C(),analysis:{status:d.status,steps:d.steps||[],result:d.result||null,error:d.error||"",needKey:!!d.needKey},compare:g,pick:E(),scan:e.tab==="scan"?S():null,edges:e.edges,express:{legs:e.express,stats:jt(e.express)},quota:q(),settings:{overlay:e.settings.overlay,theme:e.settings.theme,mode:o.mode,proxy:o.proxy,ready:o.ready,hasKey:o.hasKey,keyMask:o.keyMask,licenseMask:o.licenseMask,plan:o.plan==="free"||!o.plan?"":`Тариф «${o.plan==="max"?"Макс":"Про"}»${o.until?` до ${o.until.split("-").reverse().join(".")}`:""}.`,usage:o.limit?`Сегодня разборов: ${o.used} из ${o.limit}.`:""}}}let P=()=>{u.isOpen&&u.render(j())};function I(s){Object.assign(e.settings,s),pt({"lz.settings":e.settings}),N(),u.render(j())}async function K(){e.edges={...e.edges,status:"loading",error:""};let s=await U("lz:edges",{sport:e.match?.sport||""});e.edges=s.ok?{status:"done",data:s.data,error:"",at:Date.now()}:{status:"error",data:e.edges.data,error:s.error,at:Date.now()},P()}async function X(){let s=await U("lz:status");s.ok&&(e.status=s.data),P()}function J(){let s=z(),d=s?m(s):null;return{book:a.name,match:e.match,market:s&&d?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((g,n)=>v(s,n)),odds:s.outcomes.map(g=>g.odd)}:null}}function Q(){if(!e.match||!at())return;let s=J();if(!s.market)return;let d=`${e.match.key}|${s.market.odds.join("/")}`;d!==Q.last&&(Q.last=d,U("lz:quote",s))}async function ft(){let s=e.match;if(!s||e.analysis.has(s.key))return;let d=await U("lz:cached",{match:s});!d.ok||!d.data||e.analysis.has(s.key)||(e.analysis.set(s.key,{status:"done",steps:[],result:d.data}),N(),P())}function ct(){return{opened(){X(),N(),ft(),u.render(j())},tab(s){s==="settings"&&(e.backTab=e.tab==="settings"?e.backTab:e.tab),e.tab=s||"match",s==="edges"&&e.edges.status!=="loading"&&Date.now()-e.edges.at>300*1e3&&K(),u.render(j())},"edges-refresh"(){K(),u.render(j())},theme(){I({theme:e.theme==="dark"?"light":"dark"})},"overlay-toggle"(){I({overlay:e.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){I({overlay:s})},"set-theme"(s){I({theme:s})},async"set-mode"(s){await U("lz:settings",{mode:s}),X()},async"save-key"(s,d,g){let n=g.getElementById("lz-key"),o=(n?.value||"").trim();if(o.length<8)return u.toast("Вставьте ключ целиком");let l=await U("lz:settings",{apiKey:o});u.toast(l.ok?"Ключ сохранён":l.error),n&&(n.value=""),X()},async"clear-key"(){await U("lz:settings",{apiKey:""}),u.toast("Ключ удалён"),X()},async"save-license"(s,d,g){let n=g.getElementById("lz-license"),o=(n?.value||"").trim();if(o.length<6)return u.toast("Вставьте ключ целиком");let l=await U("lz:settings",{licenseKey:o});u.toast(l.ok?"Ключ принят":l.error),n&&(n.value=""),X()},async"clear-license"(){await U("lz:settings",{licenseKey:""}),u.toast("Ключ удалён"),X()},savePosition(s,d){e.positions[s]=d,At(["lz.positions"]).then(g=>{let n=g["lz.positions"]||{};n[location.hostname]=e.positions,pt({"lz.positions":n})})},async analyze(){if(!e.match)return;let s=e.match.key,d={status:"loading",steps:[`${e.match.home} — ${e.match.away}`]};e.analysis.set(s,d),P();let g=await U("lz:analyze",{...J(),force:!0});g.ok?e.analysis.set(s,{status:"done",steps:d.steps,result:g.data}):e.analysis.set(s,{status:"error",steps:d.steps,error:g.error,needKey:g.code==="no-access"}),X(),N(),u.render(j())},async compare(){if(!e.match)return;let s=e.match.key;e.compare.set(s,{status:"loading"}),P();let d=await U("lz:compare",J());e.compare.set(s,d.ok?{status:"done",...d.data}:{status:"done",rows:[],labels:[],note:d.error}),P()},"pick-clear"(){e.selected=null,_(),P()},"leg-add"(){let s=E(),d=A();!s?.canAdd||!d||(e.express.push({id:`${d.market.id}#${d.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),pt({"lz.express":e.express}),u.toast("Добавлено в расчёт экспресса"),P())},"leg-remove"(s){e.express=e.express.filter(d=>d.id!==s),pt({"lz.express":e.express}),P()},"leg-clear"(){e.express=[],pt({"lz.express":e.express}),P()},"scan-go"(s){let d=e.markets[Number(s)],g=d?.outcomes[0]?.el;g?.isConnected&&(g.scrollIntoView({behavior:"smooth",block:"center"}),e.selected={id:d.id,index:0},setTimeout(_,400))}}}function st(s){let d=s.composedPath();for(let g=0;g<Math.min(d.length,6);g+=1){let n=d[g]instanceof Element?f.get(d[g]):null;if(n&&n.market.outcomes[n.index]?.el===d[g])return n}return null}let Y=new Map;function nt(s){if(!s.event||!s.main||!["1x2","12"].includes(s.kind)||s.scope!=="list"||s.event.live)return null;let d=s.event.key;if(Y.has(d))return Y.get(d);let g={home:s.event.home,away:s.event.away,sport:dt(s),league:s.event.league||""},n=U("lz:consensus",{match:g,size:s.outcomes.length}).then(o=>((!o.ok||!o.data?.consensus)&&console.debug("[lz] рынок для списка:",o.error||o.data?.error||"нет данных"),o.ok&&o.data?.consensus?o.data:null)).catch(o=>(console.debug("[lz] рынок для списка:",String(o?.message||o)),null));return Y.set(d,n),n.then(o=>Y.set(d,o)),n}let dt=s=>s.event?.sport||e.match?.sport||ut(location.pathname,document.title,s.event?.league);function yt({market:s,index:d},g=null){let n=m(s),o=y(s),l=s.event?`${s.event.home} — ${s.event.away}`:"",h=s.outcomes.map((w,L)=>{let $=n.fair?n.fair[L]:1/w.odd;return t(`div.tip-row${L===d?".hot":""}`,{},t("span",{text:v(s,L)}),t("span.odd",{text:Z(w.odd)}),t("span.pct",{text:rt($,$<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round($*100)}%`})))}),k=n.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:rt(n.margin,1)}),o?t("span",{}," · модель: ",t("b",{text:rt(o[d],1)})):null),x=null;if(g?.consensus){let w=g.consensus.length===s.outcomes.length,L=!w&&g.consensus.length===2&&s.outcomes.length===3;if(w||L){let $=w?g.consensus[d]:null,D=$?s.outcomes[d].odd*$-1:0;x=t("div.tip-foot",{},`Рынок, ${g.count} контор${L?", с овертаймом":""}: `,t("b",{text:g.consensus.map(ce=>rt(ce,0)).join(" / ")}),D>.005?t("span.pos",{text:` · кэф выше рынка на ${(D*100).toFixed(1)}%`}):null)}}else g===void 0&&(x=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),l?t("div.tip-sub",{text:l}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),h.slice(0,8),k,x)}let mt=0,tt=null;_t.on("page:pointerover",s=>{if(e.settings.overlay==="off")return;let d=st(s),g=d?d.market.outcomes[d.index].el:null;if(g!==tt){if(tt=g,clearTimeout(mt),!d)return c.hideTip();mt=setTimeout(()=>{if(tt!==g||!g.isConnected)return;c.setAvoid(u.rect());let n=nt(d.market);c.showTip(g,yt(d,n instanceof Promise?void 0:n)),n instanceof Promise&&n.then(o=>{tt===g&&g.isConnected&&c.showTip(g,yt(d,o))})},280)}}),_t.on("page:click",s=>{let d=st(s);d&&(e.selected={id:d.market.id,index:d.index},_(),P())}),le(s=>{if(s.type!=="lz:progress")return;let d=e.analysis.get(s.key);!d||d.status!=="loading"||(d.steps=[...d.steps,s.text].slice(-7),P())});let ht=()=>{N(),new MutationObserver(T).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||N()}),setInterval(()=>{!document.hidden&&location.href!==e.url&&N()},600),setInterval(()=>{!document.hidden&&u.isOpen&&T()},4e3),at()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(e.settings={...$t,...s["lz.settings"].newValue||{}},N())}),X()};document.body?ht():document.addEventListener("DOMContentLoaded",ht,{once:!0}),document.documentElement.setAttribute("data-lz",a.id),globalThis.__lz={state:e,view:j,refresh:N,overlay:c,panel:u}}function Pe(r){let a=Date.now()-432e5;return(Array.isArray(r)?r:[]).filter(i=>i&&i.at>a&&i.odd>1)}})();
