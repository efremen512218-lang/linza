(()=>{var Wt=r=>typeof r=="string"?r:"",Vt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Wt("https://efremen512218-lang.github.io/linza/"),telegram:Wt("https://t.me/linza_odds"),bot:Wt("https://t.me/linza_keys_bot?start=ext")},go=Wt("https://185-72-145-3.sslip.io"),vn={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var kn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function ze(r){let a=String(r||"").toLowerCase();return kn.find(i=>i.hosts.some(n=>a===n||a.endsWith(`.${n}`)))||null}var pe={overlay:"picks",theme:"auto",mode:"own",model:vn.model,stake:1e3},Me={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function gt(r){let a=String(r??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(a))return null;let i=parseFloat(a.replace(",","."));return i>=1.001&&i<=1e3?i:null}var Se=r=>r.reduce((a,i)=>a+1/i,0);function zt(r){let a=(r||[]).filter(n=>Number.isFinite(n)&&n>1);if(a.length<2||a.length!==(r||[]).length)return{kind:"partial",margin:null,fair:null};let i=Se(a);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:a.map(n=>1/n/i)};if(a.length===3&&i>=1.97&&i<=2.4){let n=i/2;return{kind:"double",margin:n-1,fair:a.map(u=>Math.min(.995,1/u/n))}}return{kind:"partial",margin:null,fair:null}}function _e(r){let a=(r||[]).map(h=>h||[]).filter(h=>h.length),i=a.flat().filter(Boolean);if(i.length<2)return{sets:[],rest:i};let n=h=>h.length>=2&&h.every(Boolean)&&zt(h.map(g=>g.odd)).kind!=="partial",u=h=>{let g=h.filter(v=>v.some(Boolean));if(!g.length)return null;let $=g.filter(n);if($.length/g.length<.6)return null;let w=new Set($.flat());return{sets:$,rest:i.filter(v=>!w.has(v))}},p=h=>{let g=[];for(let $=0;$<a.length;$+=h)g.push(a.slice($,$+h).flat());return g},c=()=>{let h=[];for(let g=0;g+1<a.length;g+=2){let $=Math.max(a[g].length,a[g+1].length);for(let w=0;w<$;w+=1)h.push([a[g][w]??null,a[g+1][w]??null])}return h},d=[()=>p(1)];a.length>=2&&a.length%2===0&&d.push(c,()=>p(2)),a.length>=3&&a.length%3===0&&d.push(()=>p(3)),a.length>1&&d.push(()=>[a.flat()]);for(let h of d){let g=u(h());if(g)return g}return{sets:[],rest:i}}function Ne(r,a=1.13){let i=d=>{let h=Se(d.map(g=>g.odd));return h>=.995&&h<=a?!0:d.length===3&&h>=1.99&&h<=a*2},n=d=>Math.abs(d*4-Math.round(d*4))<1e-9,u=[],p=[],c=0;for(;c<r.length;){let d=r.slice(c,c+3),h=r.slice(c,c+2);d.length===3&&i(d)?(u.push(d),c+=3):h.length===2&&i(h)?(u.push(h),c+=2):r[c+2]&&n(r[c+1].odd)&&i([r[c],r[c+2]])?(u.push([r[c],r[c+2]]),p.push(r[c+1]),c+=3):(p.push(r[c]),c+=1)}return{sets:u,rest:p}}function Te(r){let a=(r||[]).filter(u=>u&&u.odd>1&&u.fair>0&&u.fair<1);if(!a.length)return null;let i=a.reduce((u,p)=>u*p.odd,1),n=a.reduce((u,p)=>u*p.fair,1);return{legs:a.length,odd:i,chance:n,fairOdd:1/n,margin:1-i*n}}function Fe(r,a){return r*a-1}function Z(r){return Number.isFinite(r)?r>=100?r.toFixed(0):r>=10?r.toFixed(1):r.toFixed(2):"—"}function bt(r,a=0){if(!Number.isFinite(r))return"—";let i=r*100;return i>0&&i<1&&a===0?"<1%":`${i.toFixed(a)}%`}function me(r){return String(r??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var wn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Le(r){return String(r??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(a=>a.length>=2&&!wn.has(a))}function Et(r,a){let i=me(r),n=me(a);if(i.length<2||n.length<2)return 0;if(i===n)return 1;let u=i.length<=n.length?i:n,p=u===i?n:i;if(u.length>=4&&p.includes(u))return .85;let c=Le(r),d=Le(a),h=$=>String($??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[$,w]of[[r,d],[a,c]]){let v=h($);if(v&&w.length>=2&&w.includes(v[1])&&w.some(M=>M!==v[1]&&M[0]===v[2]))return .8}if(c.length&&d.length){let w=c.filter(v=>d.some(M=>M===v||v.length>=5&&M.startsWith(v.slice(0,5)))).length/Math.max(c.length,d.length);if(w>=.5)return .6+.3*w}let g=0;for(;g<i.length&&g<n.length&&i[g]===n[g];)g+=1;return g>=5?Math.min(.8,.45+g*.04):0}function $n(r){let a=String(r??"").toLowerCase(),i=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(a)&&i.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(a)&&i.push("women"),/\(рез|\(р\)|резерв|reserve/.test(a)&&i.push("reserve"),/люб/.test(a)&&i.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(a)&&i.push("cyber"),i.join("+")}function Mt(r,a){let i=p=>{let c=me(p),d=$n(p);return c.length<2?"":d?`${c}~${d}`:c},n=i(r),u=i(a);return!n||!u?"":[n,u].sort().join("|")}var j=r=>(r?.textContent||"").replace(/[ \s]+/g," ").trim(),fe=r=>r.offsetParent===null&&r.tagName!=="BODY";function zn(r){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(r||"").trim())}function Mn(r){let a=String(r||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return a?a[0]:""}function jt(r,a){let i=String(r||"").toLowerCase();return/двойной шанс/.test(i)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(i)?"other":/фор[аы]|гандикап/.test(i)?"handicap":/тотал/.test(i)?"total":/обе забьют/.test(i)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(i)?a===3?"1x2":a===2?"12":"other":"other"}var Sn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function Lt(...r){let a=r.filter(Boolean).join(" ");for(let[i,n]of Sn)if(i.test(a))return n;return""}function he(r){if(!r)return null;let a=gt(j(r));if(a)return a;let i=j(r).split(" ");return gt(i[i.length-1])}var _n=0;function St({scope:r,title:a,period:i="",line:n="",kind:u,outcomes:p,event:c=null,anchor:d=null,eventKey:h=""}){let g=p.length;return{id:`${r}|${h}|${a}|${i}|${n}|${p.map($=>$.label).join("/")}`,serial:_n+=1,scope:r,title:a,period:i,line:n,kind:u||jt(a,g),main:zn(i)&&!Mn(a),outcomes:p,event:c,anchor:d||p[0]?.el||null}}var H=(r,a)=>[...r.querySelectorAll(a)];function je(r){return(String(r||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function ge(r){return r.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":r.querySelector(".card")?"list":"other"}var Ce={win:"В",loose:"П",lose:"П",draw:"Н"};function Oe(r){return H(r,".competitor-form__value").map(a=>Ce[[...a.classList].find(i=>Ce[i])]||j(a).slice(0,1)).filter(Boolean).join("")}function Nn(r){let a=r.querySelector(".marketbook-header--live");if(a){let n=H(a,".game-scoring__item").map(c=>j(c)),u=H(a,".game-periods .period").map(c=>{let d=H(c,"span");return{label:j(c.querySelector("i")),home:j(d[0]),away:j(d[1])}}).filter(c=>c.home!==""&&c.away!==""),p=H(a,".game-specials > div").map(c=>{let d=H(c,"span"),h=c.querySelector("i"),g=h?.classList.contains("yellow-card")?"жёлтые":h?.classList.contains("red-card")?"красные":h?.classList.contains("penalty-card")?"угловые":"";return g?{kind:g,home:j(d[0]),away:j(d[1])}:null}).filter(Boolean);return{state:j(a.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:u,extras:p}}let i=r.querySelector(".match-card");if(i&&!i.querySelector(".match-card__timer--prematch")){let n=j(i.querySelector(".match-card__main-score")).replace(/\s/g,""),u=H(i,".match-card__score").map(c=>j(c)).filter(c=>/^\d{1,2}$/.test(c)),p=H(r,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(c=>j(c)).filter(c=>/\d\s*:\s*\d/.test(c)).slice(0,5);return{state:j(i.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:u.length>=2?u.slice(0,2):[],periods:p.map((c,d)=>({label:`${d+1} карта`,raw:c})),extras:[]}}return null}function Ae(r,a){if(ge(r)!=="match")return null;let i=H(r,".breadcrumbs .breadcrumbs__item").map(g=>j(g)).filter(Boolean),n=j(r.querySelector(".event-breadcrumbs")),u=H(r,".marketbook-header--prematch .competitor-name").map(g=>j(g));if(u.length<2&&(u=H(r,".marketbook-header--live .competitors-desc__name").map(g=>j(g))),u.length<2&&(u=H(r,".match-card .match-card__team-name").map(g=>j(g))),u.length<2||!u[0]||!u[1])return null;let p=Lt(i[1]&&/киберспорт/i.test(i[0])?i[1]:"",i[0],n),c=/киберспорт/i.test(i[0]||"")?i.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():i.slice(1).join(", "),d=[j(r.querySelector(".prematch-date")),j(r.querySelector(".prematch-time"))].filter(Boolean).join(" ")||j(r.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),h=Nn(r);return{book:"Winline",id:je(a?.pathname),key:Mt(u[0],u[1]),home:u[0],away:u[1],sport:p,league:c,start:h?"":d,live:h,form:{home:Oe(r.querySelector(".competitor-form--left")||r.createElement("div")),away:Oe(r.querySelector(".competitor-form--right")||r.createElement("div"))},stats:An(En(r),u[0],u[1]),url:a?.href||""}}function Tn(r,a){let i=[];for(let n of H(r,".bet-line")){if(fe(n))continue;let u=j(n.querySelector(".bet-line__market-name")),p=j(n.querySelector(".bet-line__period")),c=H(n,".odd-btn"),d=c.map((g,$)=>{let w=j(g.querySelector(".odd-btn__label")),v=H(g,"span").map(M=>gt(j(M))).find(Boolean)||null;return v?{el:g,odd:v,label:w||be(c.length,$,u),locked:!1}:null});if(d.length<2||d.some(g=>!g))continue;let h=j(n.querySelector(".coef-btn")).replace(/\s+/g," ");i.push(St({scope:"top",title:u,period:p,line:h,outcomes:d,anchor:n,eventKey:a}))}return i}function be(r,a,i){return/тотал/i.test(i)?["Меньше","Больше"][a]||"":r===3?["П1","Х","П2"][a]:r===2?["1","2"][a]:String(a+1)}function Fn(r,a){let i=[];for(let n of H(r,".market")){let u=H(n,".market__row");if(!u.length)continue;let p=j(n.querySelector(".market-title")),c=u.map(h=>{let g=j(h.querySelector(".market__row-text"));return H(h,".market-row-btn").map($=>{let w=gt(j($.querySelector(".market-row-btn__coef")));if(!w||$.hasAttribute("disabled"))return null;let v=$.getAttribute("title")||j($.querySelector(".market-row-btn__text"));return{el:$,odd:w,label:v.replace(/\s+/g," ").trim(),rowLabel:g,locked:!1}})}),{sets:d}=_e(c);for(let h of d){let g=[...new Set(h.map(M=>M.rowLabel).filter(Boolean))],$=g.length<=1,w=$?"":(h[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=h.map(M=>({el:M.el,odd:M.odd,label:$?M.label:M.rowLabel||M.label,locked:!1}));i.push(St({scope:"board",title:p,period:$&&g[0]||"",line:w,kind:jt(p,v.length),outcomes:v,anchor:n,eventKey:a}))}}return i}var Ln=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Cn(r){let a=H(r,".card__competitors .name .name, .half__names .name").map(n=>j(n));if(a.length<2)return null;let i=r.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:je(i),key:Mt(a[0],a[1]),home:a[0],away:a[1],href:i,live:/card--live/.test(r.className)||!!r.querySelector(".card__body-live"),time:j(r.querySelector(".header-left__time, .footer__time")),league:j(r.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:r}}function Ee(r){let a=[];for(let i of H(r,".card")){if(fe(i))continue;let n=Cn(i);if(n){for(let u of H(i,".card__body")){let p=j(u.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(u.className)?"отрезок":"");for(let c of H(u,".card__market")){let d=H(c,".coefficient-button");if(d.length<2)continue;let h=(Ln.find(([$])=>$.test(d[0].className))||[])[1]||"other",g=d.map(($,w)=>{let v=/--is-blank/.test($.className)?null:he($);return v?{el:$,odd:v,label:h==="total"?["Меньше","Больше"][w]:be(d.length,w,""),locked:/coefficient-button_locked/.test($.className)}:null});g.some($=>!$)||a.push(St({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[h]||"Рынок",period:/^матч$/i.test(p)?"":p,line:j(c.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:h,outcomes:g,event:n,anchor:i,eventKey:n.key}))}}for(let u of H(i,".half__coef-buttons")){let p=H(u,".coef-buttons__button"),c=p.map((d,h)=>{let g=he(d.querySelector(".button__coef-title")||d);return g?{el:d,odd:g,label:be(p.length,h,""),locked:!1}:null});c.length<2||c.some(d=>!d)||a.push(St({scope:"list",title:c.length===3?"Исход":"Победитель",kind:c.length===3?"1x2":"12",outcomes:c,event:n,anchor:i,eventKey:n.key}))}}}return a}function On(r){if(!r?.body)return null;let a=h=>/^\d{1,3}\s?%$/.test(h),i=H(r,"h4").map(h=>{let g=[...h.nextElementSibling?.children||[]],$=j(g[0]),w=j(g[g.length-1]);return a($)&&a(w)?{label:j(h),home:$.replace(/\s/g,""),away:w.replace(/\s/g,"")}:null}).filter(Boolean);if(!i.length)return null;let n=(r.body.innerText||r.body.textContent||"").replace(/\s+/g," "),u=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(h=>Number(h[1])),c=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(h=>h[1].replace(/\s/g,""));return{names:j(r.querySelector("h3")).split(/\s+vs\s+/i).map(h=>h.trim()).filter(Boolean),rows:i,samples:u.slice(0,2),form:c.length>=2?{home:c[0],away:c[1]}:null}}function An(r,a,i){if(!r||r.names.length<2)return r;let n=Et(r.names[0],a)+Et(r.names[1],i);return Et(r.names[0],i)+Et(r.names[1],a)<=n?r:{names:[r.names[1],r.names[0]],rows:r.rows.map(p=>({label:p.label,home:p.away,away:p.home})),samples:r.samples.slice().reverse(),form:r.form?{home:r.form.away,away:r.form.home}:null}}function En(r){let a=r.querySelector("iframe.stats__iframe");if(!a)return null;try{return On(a.contentDocument)}catch{return null}}function jn(r){let a=["one","two"].map(p=>r.querySelector(`.event-live-center__team-widget--${p}`));if(!a[0]||!a[1])return null;let i=p=>{let c=p;try{c=p.querySelector("iframe")?.contentDocument?.body||p}catch{c=p}let d=H(c,'[class*="player"]').filter(g=>!H(g,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(g.className)),h=[];for(let g of d){let $=j(g).split(" ").filter(Boolean),w=$.find(M=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(M)&&/[A-Za-z]/.test(M));if(!w||h.some(M=>M.nick===w))continue;let v=$.filter(M=>/^\d{1,3}$/.test(M)).map(Number);h.push({nick:w,numbers:v.slice(0,4)})}return h.slice(0,5)},n=i(a[0]),u=i(a[1]);return n.length<3||u.length<3?null:{home:n,away:u}}var Be={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:ge,readMatch:Ae,readEsportsWidget:jn,observeTargets(r){try{let a=r.querySelector("iframe.stats__iframe")?.contentDocument?.body;return a?[a]:[]}catch{return[]}},collect(r,a){if(ge(r)==="match"){let u=Ae(r,a)?.key||"";return[...Tn(r,u),...Fn(r,u),...Ee(r)]}return Ee(r)}};var Zt=(r,a)=>{try{return[...r.querySelectorAll(a)]}catch{return[]}};function qe(r,a){let i=[r];if(a.shadow)for(let n of Zt(r,a.shadow))n.shadowRoot&&i.push(n.shadowRoot);return i}var Kt=r=>(r.defaultView?.innerWidth||0)>0,Bn='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function qn(r){let a=[],i=r.ownerDocument.createTreeWalker(r,4);for(;i.nextNode();){let n=i.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&a.push(...n.split(" ")),a.length>5)return null}return a}function Pn(r,a){if(a.label){let i=r.querySelector(a.label),n=i?i.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(a.cell&&a.headerRow){let i=r.closest(a.cell),n=i?.parentElement,u=n?.parentElement?.querySelector(a.headerRow);if(u&&u!==n){let p=[...n.children].indexOf(i),c=u.children[p]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(c)return c.charAt(0).toUpperCase()+c.slice(1).toLowerCase()}}return""}function In(r,a){if(!a.cell||!a.lineCell)return"";let i=r.closest(a.cell);for(;i&&(i=i.previousElementSibling);){if(!i.matches?.(a.lineCell))continue;let n=i.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function Rn(r,a){if(r.disabled||r.hasAttribute?.("disabled"))return null;let i=a.value&&r.querySelector(a.value)||r,n=qn(i);if(!n||!n.length||n.join(" ").length>28)return null;let u=n[n.length-1];if(!(a.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(u))return null;let p=gt(u);if(!p||p>500||n.slice(0,-1).some(d=>/^\d{1,3}[.,]\d{1,3}$/.test(d)))return null;let c=n.slice(0,-1).join(" ");return!a.outcome&&/[+−]|^-/.test(c)?null:{odd:p,label:c}}function Dn(r,a){let i=[],n=new Set,u=qe(r,a).flatMap(p=>Zt(p,a.outcome||Bn));for(let p of u){if(n.has(p)||a.skip&&p.closest(a.skip)||p.closest("#lz-root, #lz-marks"))continue;let c=Rn(p,a);if(c){if(!a.outcome&&Kt(r)){let d=p.getBoundingClientRect();if(d.width<26||d.width>320||d.height<16||d.height>90)continue}n.add(p),i.push({el:p,odd:c.odd,label:c.label||Pn(p,a),line:In(p,a),locked:!1})}}return a.outcome?i:i.filter(p=>!i.some(c=>c.el!==p.el&&c.el.contains(p.el)))}function Un(r,a,i){if(a.row)return r.closest(a.row);let n=r.parentElement;for(let u=0;u<6&&n&&n!==n.ownerDocument.body;u+=1){let p=i(n);if(p>=2&&p<=16){if(!Kt(n.ownerDocument))return n;let c=n.getBoundingClientRect();if(c.height<=130&&c.width>=120)return n}if(p>16)break;n=n.parentElement}return null}var Pe=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function Gn(r,a){let i=a.length,n=r;for(let $=0;$<7;$+=1){let w=n.parentElement;if(!w||a.some(O=>!w.contains(O.el))||w.querySelectorAll("*").length>400||[...w.querySelectorAll('button, a, td, [role="button"]')].filter(O=>!a.some(L=>L.el===O||L.el.contains(O)||O.contains(L.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(j(O))).length>i)break;n=w}let u=a[0].el,p=[],c=n.ownerDocument.createTreeWalker(n,4);for(;c.nextNode();){let $=c.currentNode;if(u.contains($))break;let w=$.textContent.replace(/[ \s]+/g," ").trim();w.length<2||w.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(w)||/\d{1,2}:\d{2}|^\d|['′]$/.test(w)||Pe.test(w)||p.push(w)}let d=p.slice(-2),h=p.map($=>$.split(/\s+[—–-]\s+/)).filter($=>$.length===2).pop();if(h&&(d=h),d.length<2||d[0]===d[1])return null;let g=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Mt(d[0],d[1]),home:d[0],away:d[1],href:g,live:!1,time:"",league:"",card:n}}function Wn(r,a,i){if(!a.names)return Gn(r,i);let n=a.event&&r.closest(a.event)||r,u=[...new Set(Zt(n,a.names).map(d=>j(d)).filter(Boolean))],p=u;if(u.length===1&&(p=u[0].split(/\s+[—–-]\s+/)),p.length<2||!p[0]||!p[1])return null;let c=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Mt(p[0],p[1]),home:p[0],away:p[1],href:c,live:!1,time:"",league:"",card:n}}function Vn(r){let i=String(r.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!i)return null;let n=[i[1].trim(),i[2].trim()];return n.some(u=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(u))?null:n}function Ie(r,a={}){function i(v,M){return a.matchUrl&&a.matchUrl.test(M?.pathname||"")||a.matchPage&&v.querySelector(a.matchPage)?"match":"list"}function n(v){let M=v.defaultView;if(!M||!Kt(v))return[];let O=[];for(let L of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if(L.children.length)continue;let q=j(L);if(q.length<3||q.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(q)||/\d{1,2}[:.]\d{2}/.test(q)||Pe.test(q))continue;let D=L.getBoundingClientRect();if(!(D.top<60||D.top>450||D.width<30||parseFloat(M.getComputedStyle(L).fontSize)<15)&&(O.includes(q)||O.push(q),O.length===2))break}return O}function u(v,M){if(i(v,M)!=="match")return null;let O=a.matchNames?Zt(v,a.matchNames).map(q=>j(q)).filter(Boolean):[];if(O.length===1&&(O=O[0].split(/\s+[—–-]\s+/)),O.length<2&&(O=Vn(v)||[]),O.length<2&&(O=n(v)),O.length<2)return null;let L=a.matchLeague?j(v.querySelector(a.matchLeague)):"";return{book:r.name,id:(String(M?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Mt(O[0],O[1]),home:O[0],away:O[1],sport:Lt(M?.pathname,L,v.title,j(v.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:L,start:"",live:/(^|\/)live(\/|$)/i.test(M?.pathname||"")?!0:null,form:{home:"",away:""},url:M?.href||""}}function p(v,M){return!v||!M?"":M.startsWith("attr:")?String(v.getAttribute(M.slice(5))||"").trim():j(v.querySelector(M))}function c(v,M){if(!Kt(M))return[v];let O=v.map(q=>{let D=q.el.getBoundingClientRect();return{cell:q,top:D.top,left:D.left}}).sort((q,D)=>Math.abs(q.top-D.top)>8?q.top-D.top:q.left-D.left),L=[];for(let q of O){let D=L[L.length-1];D&&Math.abs(D.top-q.top)<=8?D.cells.push(q.cell):L.push({top:q.top,cells:[q.cell]})}return L.map(q=>q.cells)}let d=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],h=v=>(d.find(([M])=>M.test(v.join("/").toLowerCase()))||[])[1]||"other";function g(v,M){let O=i(v,M),L=O==="match"&&a.match?{...a,...a.match}:a;return $(v,M,O,L)}function $(v,M,O,L){let q=Dn(v,L);if(q.length<2)return[];let D=new Set(q.map(C=>C.el)),ot=C=>{let T=0;for(let A of D)C.contains(A)&&(T+=1);return T},G=new Map;for(let C of q){let T=Un(C.el,L,ot);T&&(G.has(T)||G.set(T,[]),G.get(T).push(C))}let at=O==="match"?u(v,M):null,I=[];for(let[C,T]of G){let A=O==="match"?null:Wn(C,L,T),B=L.group?C.closest(L.group):null,P=p(B,L.groupTitle),V=p(B,L.groupPeriod),W=L.visualRows?c(T,v):[T],J=0;for(let X of W)for(let Q of Ne(X).sets){let Y=J===0,tt=Q.length,ut=tt===3?["П1","Х","П2"]:["1","2"],vt=Q.map((st,it)=>({...st,label:st.label||ut[it]||String(it+1)})),mt=Y&&tt===3?"Исход":Y?"Победитель":`Рынок ${J+1}`,ct=Y?tt===3?"1x2":"12":"other";P&&(mt=P,ct=jt(P,tt),ct==="other"&&(ct=h(vt.map(st=>st.label)))),tt===3&&vt.every(st=>/\sили\s/i.test(st.label))&&(ct="dc"),I.push(St({scope:O==="match"?"board":"list",title:mt,period:V,line:Q[0].line&&Q.every(st=>st.line===Q[0].line)?Q[0].line:"",kind:ct,outcomes:vt,event:A,anchor:C,eventKey:A?.key||at?.key||`row${I.length}`})),J+=1}}return I}let w=v=>qe(v,a).slice(1);return{id:r.id,name:r.name,hosts:r.hosts,generic:!0,pageType:i,readMatch:u,collect:g,observeTargets:w,readEsportsWidget:()=>null}}var Re={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},De={fonbet:Re,pari:Re,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function Ue(r){let a=ze(r);return a?a.id==="winline"?{adapter:Be,book:a}:{adapter:Ie(a,De[a.id]||{}),book:a}:null}var Ht=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var Ge=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(r,a,...i){let[n,...u]=r.split("."),p=document.createElement(n||"div");u.length&&(p.className=u.join(" "));for(let[c,d]of Object.entries(a||{}))if(!(d==null||d===!1))if(c==="class")p.className=[p.className,d].filter(Boolean).join(" ");else if(c==="style")p.style.cssText=d;else if(c==="text")p.textContent=d;else{if(c==="html")throw new Error("html запрещён");c.startsWith("data-")||c.startsWith("aria-")||c==="role"||c==="title"||c==="type"||c==="href"||c==="target"||c==="rel"||c==="placeholder"||c==="value"||c==="for"||c==="name"||c==="maxlength"||c==="autocomplete"||c==="spellcheck"||c==="tabindex"?p.setAttribute(c,d===!0?"":String(d)):c==="disabled"||c==="hidden"||c==="checked"||c==="selected"?p[c]=!!d:p[c]=d}return Ve(p,i),p}function Ve(r,a){for(let i of a)i==null||i===!1||(Array.isArray(i)?Ve(r,i):r.appendChild(i instanceof Node?i:document.createTextNode(String(i))))}var We="http://www.w3.org/2000/svg";function nt(r,a=16){let i=document.createElementNS(We,"svg");i.setAttribute("viewBox","0 0 20 20"),i.setAttribute("width",a),i.setAttribute("height",a),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.7"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("aria-hidden","true");for(let n of Hn[r]||[]){let u=document.createElementNS(We,"path");u.setAttribute("d",n),i.appendChild(u)}return i}var Hn={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function Ke(){let r=document.createElement("div");r.id="lz-marks",r.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let a=r.attachShadow({mode:"open"});a.appendChild(t("style",{text:Ht+Ge}));let i=t("div.layer"),n=t("div.tip");a.append(i,n);let u=new Map,p=new Set,c=0,d=null,h=null,g=new IntersectionObserver(C=>{for(let T of C)T.isIntersecting?p.add(T.target):(p.delete(T.target),u.get(T.target)?.node.classList.remove("on"));w()},{rootMargin:"120px"});function $(){r.isConnected||document.documentElement.appendChild(r)}function w(){c||(c=requestAnimationFrame(()=>{c=0,O()}))}let v=(C,T)=>{for(let A=T;A;A=A.parentNode||A.host)if(A===C)return!0;return!1};function M(C,T){let A=T.left+T.width/2,B=T.top+T.height/2;if(A<0||B<0||A>window.innerWidth||B>window.innerHeight)return!1;let P=document.elementFromPoint(A,B);for(;P?.shadowRoot?.elementFromPoint;){let V=P.shadowRoot.elementFromPoint(A,B);if(!V||V===P)break;P=V}return!!P&&P!==C&&!v(C,P)&&!v(P,C)}function O(){for(let C of p){let T=u.get(C);if(!T)continue;if(!C.isConnected){L(C);continue}let A=C.getBoundingClientRect();if(A.width<6||A.height<6||M(C,A)){T.node.classList.remove("on");continue}let B=Math.round(A.left),P=Math.round(A.top),V=Math.round(A.width),W=Math.round(A.height);(T.x!==B||T.y!==P)&&(T.node.style.transform=`translate3d(${B}px, ${P}px, 0)`,T.x=B,T.y=P),(T.w!==V||T.h!==W)&&(T.node.style.width=`${V}px`,T.node.style.height=`${W}px`,T.w=V,T.h=W,T.node.classList.toggle("small",W<26)),T.node.classList.add("on")}d&&D()}function L(C){let T=u.get(C);T&&(g.unobserve(C),p.delete(C),T.node.remove(),u.delete(C))}function q(C){$();let T=new Map;for(let A of C)A.el?.isConnected&&T.set(A.el,A);for(let A of[...u.keys()])T.has(A)||L(A);for(let[A,B]of T){let P=u.get(A);if(!P){let W=t("div.mark"),J=parseFloat(getComputedStyle(A).borderTopLeftRadius);W.style.borderRadius=`${Number.isFinite(J)&&J>0?Math.min(J,16):6}px`;let X=t("span.chip");W.appendChild(X),i.appendChild(W),P={node:W,chip:X,sig:""},u.set(A,P),g.observe(A)}let V=`${B.frame?1:0}|${B.selected?1:0}|${B.tone||""}|${B.chip||""}`;V!==P.sig&&(P.sig=V,P.node.classList.toggle("frame",!!B.frame),P.node.classList.toggle("selected",!!B.selected),P.node.classList.toggle("pos",B.tone==="pos"&&!!B.frame),P.chip.hidden=!B.chip,P.chip.textContent=B.chip||"",P.chip.className=`chip${B.tone&&B.tone!=="accent"?" "+B.tone:""}`)}w()}function D(){if(!d?.isConnected)return G();let C=d.getBoundingClientRect(),T=264,A=n.offsetHeight||140,B=C.left+C.width/2-T/2;B=Math.max(8,Math.min(B,window.innerWidth-T-8)),h&&B+T>h.left-8&&B<h.right&&(B=Math.max(8,h.left-T-10));let P=C.bottom+10;P+A>window.innerHeight-8&&(P=C.top-A-10),P<8&&(P=8),n.style.transform=`translate3d(${Math.round(B)}px, ${Math.round(P)}px, 0)`}function ot(C,T){$(),d=C,n.replaceChildren(T),D(),n.classList.add("on")}function G(){d=null,n.classList.remove("on")}function at(C){h=C}function I(C){r.setAttribute("data-theme",C)}return window.addEventListener("scroll",w,{capture:!0,passive:!0}),window.addEventListener("resize",w,{passive:!0}),setInterval(()=>{u.size&&!document.hidden&&w()},700),{set:q,schedule:w,showTip:ot,hideTip:G,setTheme:I,setAvoid:at,get tipTarget(){return d},count:()=>u.size}}var Ze=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var Qt=r=>Math.min(.999,Math.max(.001,r));function xe(r,a,i=0,n=0){let u=Math.ceil(a/2),p=new Map,c=(d,h)=>{if(d>=u)return 1;if(h>=u)return 0;let g=d*16+h;return p.has(g)||p.set(g,r*c(d+1,h)+(1-r)*c(d,h+1)),p.get(g)};return c(i,n)}function te(r,a){let i=.001,n=.999;for(let u=0;u<50;u++){let p=(i+n)/2;r(p)<a?i=p:n=p}return(i+n)/2}function Yn(r,a){let i=Qt(r);return Math.ceil(a/2)<=1?i:te(n=>xe(n,a),i)}function Yt(r,a,i,n=new Map){if(a>=4)return[1,0];if(i>=4)return[0,0];if(a===3&&i===3)return[0,1];let u=a*8+i;if(!n.has(u)){let[p,c]=Yt(r,a+1,i,n),[d,h]=Yt(r,a,i+1,n);n.set(u,[r*p+(1-r)*d,r*c+(1-r)*h])}return n.get(u)}function He(r){let[a,i]=Yt(r,0,0);return a/(1-i)}function Xt(r,a,i){if(a=Math.max(0,Math.floor(a)),i=Math.max(0,Math.floor(i)),Math.min(a,i)>=12){let p=Math.floor((Math.min(a,i)-12)/3),c=a-12-3*p,d=i-12-3*p,[h,g]=Yt(r,c,d);return h+g*He(r)}let n=new Map,u=(p,c)=>{if(p>=13)return 1;if(c>=13)return 0;if(p===12&&c===12)return He(r);let d=p*32+c;return n.has(d)||n.set(d,r*u(p+1,c)+(1-r)*u(p,c+1)),n.get(d)};return u(a,i)}function Jn(r){return te(a=>Xt(a,0,0),Qt(r))}var Qn=24,Jt=Array.from({length:101},(r,a)=>(a+.5)/101),Xe=null;function Ye(r,a){let i=Jt.map(c=>(r-1)*Math.log(c)+(a-1)*Math.log(1-c)),n=Math.max(...i),u=i.map(c=>Math.exp(c-n)),p=u.reduce((c,d)=>c+d,0);return u.map(c=>c/p)}function Je(r,a,i=0,n=0){if(!Number.isFinite(a))return Xt(r,i,n);let u=Ye(r*a+i,(1-r)*a+n);return!i&&!n?(Xe||=Jt.map(p=>Xt(p,0,0)),u.reduce((p,c,d)=>p+c*Xe[d],0)):u.reduce((p,c,d)=>p+c*Xt(Jt[d],i,n),0)}function to(r,a){return Number.isFinite(a)?te(i=>Je(i,a),Qt(r)):Jn(r)}var eo={cs:8,dota:1/0};function Qe(r,a,i,n=0,u=0){return Number.isFinite(a)?Ye(r*a+n,(1-r)*a+u).reduce((c,d,h)=>c+d*xe(Jt[h],i,n,u),0):xe(r,i,n,u)}function no(r,a,i){return Number.isFinite(i)?te(n=>Qe(n,i,a),Qt(r)):Yn(r,a)}function oo(r,a){let i=Math.max(r,a),n=Math.min(r,a);return n<12?i>=13:i-12-3*Math.floor((n-12)/3)>=4}function tn({pre:r,bo:a=3,maps:i=[0,0],rounds:n=null,game:u="cs",kappa:p=Qn,kappaMap:c=eo[u]??1/0}){let d=Math.ceil(a/2),[h,g]=(i||[0,0]).map(q=>Math.max(0,Number(q)||0));if(h>=d)return{p:1,map:null};if(g>=d)return{p:0,map:null};let $=no(r,a,c),w=(q,D)=>Qe($,c,a,q,D),[v,M]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(v)||!Number.isFinite(M)||v===0&&M===0||oo(v,M))return{p:w(h,g),map:null};let O=Number.isFinite(c)?($*c+h)/(c+h+g):$,L=Je(to(O,p),p,v,M);return{p:L*w(h+1,g)+(1-L)*w(h,g+1),map:L}}var K=(r,a=0)=>bt(r,a),dt=r=>`${r>0?"+":r<0?"−":""}${Math.abs(r).toFixed(1)}`;function en({bus:r,actions:a,brand:i}){let n=document.createElement("div");n.id=r.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let u=n.attachShadow({mode:"open"});u.appendChild(t("style",{text:Ht+Ze}));let p=t("span.dot"),c=t("button.fab",{type:"button","data-act":"toggle",title:`${i.name}: открыть панель`,"aria-label":`${i.name}: открыть панель`},nt("lens",18),t("span",{text:i.name}),p),d=t("div.tabs",{role:"tablist"}),h=t("div.body"),g=t("div.foot"),$=t("small"),w=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),M=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},nt("gear")),O=t("div.head",{},t("div.brand",{},t("span.logo",{},nt("lens",15)),t("span",{text:i.name}),$),t("span.grow"),v,w,M,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},nt("close"))),L=t("section.panel",{hidden:!0,role:"dialog","aria-label":i.name},O,d,h,g);u.append(c,L);let q=()=>{n.isConnected||document.documentElement.appendChild(n)};q(),new MutationObserver(q).observe(document.documentElement,{childList:!0});let D="",ot=null,G=new Map,at=e=>{for(let o of e.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},I=null;r.on("ui:pointerdown",e=>{if(e.button!==0)return;let o=e.composedPath(),l=o.includes(c),f=o.includes(O)&&!o.some(k=>k?.dataset?.act);if(!l&&!f)return;let b=l?c:L,x=b.getBoundingClientRect();I={target:b,key:l?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:x.left,oy:x.top,moved:!1},r.setDragging(!0)}),r.on("drag:move",e=>{if(!I)return;let o=e.clientX-I.sx,l=e.clientY-I.sy;!I.moved&&Math.hypot(o,l)<5||(I.moved=!0,I.target.classList.add("dragging"),T(I.target,I.ox+o,I.oy+l))}),r.on("drag:end",()=>{if(I){if(r.setDragging(!1),I.target.classList.remove("dragging"),I.moved){let e=I.target.getBoundingClientRect();a.savePosition(I.key,{left:e.left,top:e.top}),C=!0,setTimeout(()=>{C=!1},60)}I=null}});let C=!1;function T(e,o,l){let f=e.offsetWidth||120,b=e.offsetHeight||40,x=Math.max(6,Math.min(o,window.innerWidth-f-6)),k=Math.max(6,Math.min(l,window.innerHeight-Math.min(b,60)-6));e.style.left=`${Math.round(x)}px`,e.style.top=`${Math.round(k)}px`,e.style.right="auto"}r.on("ui:click",e=>{if(C)return;let o=at(e);if(!o||o.disabled)return;e.preventDefault();let l=o.dataset.act;if(l==="toggle")return $t();if(l==="close")return wt();let f=a[l];f&&f(o.dataset.arg,o,u)}),r.on("ui:keydown",e=>{if(e.key==="Escape"&&wt(),e.key==="Enter"){let o=e.composedPath()[0];o?.dataset?.enter&&a[o.dataset.enter]?.(o.value,o,u)}});let A=(e,o)=>t("span.form",{},[...String(e||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function B(e){let o=e.live,l=o?t("div.center",{},o.score?.length===2?t("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,t("span.badge.live",{text:o.state||"Лайв"})):t("div.center",{},t("span",{text:e.start||"до матча"})),f=o?.periods?.length?t("div.periods",{text:o.periods.map(x=>x.raw?`${x.label} ${x.raw}`:`${/^\d+$/.test(x.label)?`${x.label}-й отрезок`:x.label} ${x.home}:${x.away}`).join(" · ")}):null,b=o?.extras?.length?t("div.periods",{text:o.extras.map(x=>`${x.kind} ${x.home}:${x.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:e.league||e.sportName||"",title:e.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:e.home,title:e.home}),e.form?.home?A(e.form.home):null),l,t("div.team.away",{},t("b",{text:e.away,title:e.away}),e.form?.away?A(e.form.away):null)),f,b)}function P(e){let o=e.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:e.title}),Number.isFinite(e.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(e.margin,1)}`}):null),e.rows.map(l=>{let f=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:Z(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},K(o&&Number.isFinite(l.model)?l.model:l.fair),f!=null&&Math.abs(f)>=.05?t(`small${f>0?".pos":".neg"}`,{text:`${dt(f)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),o?t("span.model",{text:"оценка модели"}):null))}function V(e){let o=e.analysis;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},o.steps.map((k,y)=>t(`div.step${y===o.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:k})))));if(o.status==="error")return t("div.card",{},t("div.note.warn",{},nt("alert"),t("span",{text:o.error})),o.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},nt("gear"),"Открыть настройки")):null);if(o.status!=="done"||!o.result)return null;let l=o.result,f={home:e.match?.home,away:e.match?.away,draw:"ничья"}[l.lean],b=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,x=new Map((l.facts||[]).map(k=>[k.id,k]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:f?`Данные сдвигают оценку в сторону: ${f}`:b?`Данные слегка склоняют в сторону: ${b.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),b?t("div.note",{style:"margin-bottom:10px"},nt("info"),t("span",{text:`Модель предложила сдвиг на ${b.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(k=>t(`li.factor${k.side==="home"?".home":k.side==="away"?".away":""}`,{},t("div",{},t("p",{text:k.text}),t("div.src",{},(k.facts||[]).map(y=>x.get(y)).filter(Boolean).map(y=>t("span.tag",{text:`${y.id} · ${y.source}`,title:y.text}))))))):null,l.scenarios?.length?t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Как может пойти игра"})),t("ul.facts",{},l.scenarios.map(k=>t("li",{},t("span",{text:k.text})," ",t("em",{text:`— ${k.facts.join(", ")}`}))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},nt("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:G.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(k=>t("li",{},t("b",{text:k.id}),t("span",{},k.text," ",t("em",{text:`— ${k.source}`})))))),W(l.research),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function W(e){return e?e.skipped==="plan"?t("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):e.sources?.length?t("div.hint",{style:"margin-top:8px"},`${e.note} Прочитано: `,e.sources.map((o,l)=>[l?", ":"",t("a",{href:o.url,target:"_blank",rel:"noopener",text:o.domain})])):e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null:null}function J(e){let o=e.compare?.consensus||e.analysis?.result?.consensus||e.consensus;if(!o?.consensus||!e.line?.rows?.length)return null;let l=o.consensus.length===2&&e.line.rows.length===3;if(!l&&e.line.rows.length!==o.consensus.length)return null;let f=l?e.line.overtime:null,b=f?f.rows:l?[e.line.rows[0],e.line.rows[2]].map(y=>({...y,odd:null,fair:null})):e.line.rows,x=e.match?.sport==="mma",k=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?x?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${o.count} контор`})),b.map((y,z)=>{let N=o.consensus[z],F=y.odd?y.odd*N-1:0,S=Number.isFinite(y.fair)?(y.fair-N)*100:0;return t("div.prob",{},t("span.name",{text:y.name,title:y.name}),t("span.odd",{text:Z(1/N),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(N*100)}%`}),t("u",{style:`left:${Math.round((y.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},K(N),F>.005?t("small.pos",{text:`кэф выше рынка ${dt(F*100)}%`}):Math.abs(S)>=2?t(`small${S>0?".neg":""}`,{text:`${dt(S)} п.п. к рынку`,title:S>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!f?null:t("span.model",{text:f?`шанс по рынку «${f.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l&&x?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?f?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(Z).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(Z).join(" / ")}. `:""}Цены ${o.count} контор без маржи${k?`, обновлено в ${k}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let X=new Map;function Q(e,o){let l=e.match?.live;if(!l||!["cs","dota"].includes(o.game)||l.score?.length!==2)return null;let f=l.score.map(Number),b=Number(o.bo)||3;if(f.some(y=>!Number.isFinite(y)||y<0)||Math.max(...f)>=Math.ceil(b/2))return null;let x=o.game==="cs"&&l.rounds?.length===2&&l.rounds.every(y=>/^[0-9]{1,2}$/.test(String(y)))?l.rounds.map(Number):null,k=`${o.p1}|${b}|${f}|${x}`;return X.has(k)||(X.size>50&&X.clear(),X.set(k,{...tn({pre:o.p1,bo:b,maps:f,rounds:x,game:o.game}),bo:b,maps:f,rounds:x})),X.get(k)}function Y(e){let o=e.compare?.model||e.analysis?.result?.model||e.model;if(!o?.p1||!e.line?.rows?.length)return null;let l=e.line.rows.length===3&&(o.overtime||o.drawless);if(!l&&e.line.rows.length!==2)return null;let f=l?e.line.overtime:null,b=f?f.rows:l?[e.line.rows[0],e.line.rows[2]].map(_=>({..._,fair:null})):e.line.rows,x=Q(e,o),k=x?[x.p,1-x.p]:[o.p1,o.p2],y=o.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${o.samples} матчей у менее опытного игрока)`:o.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${o.samples} игр у менее опытной команды)${o.regulation?`. Основное время: ${Math.round(o.regulation.p1*100)}% / ничья ${Math.round(o.regulation.px*100)}% / ${Math.round(o.regulation.p2*100)}%`:""}`:o.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${o.samples} боёв в UFC у менее опытного бойца)`:o.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${o.samples} игр у менее опытной команды)`:o.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${o.samples} ${ht(o.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} ${ht(o.samples,"карта","карты","карт")} у менее опытной команды)`,z=o.backtest,N=(z?.calibration||[]).filter(_=>[60,70,80].includes(_.threshold)),F=z?.labels?.[o.confidence],S=(F?`С подписью «${o.confidence}» на проверке сбывалось ${K(F.hit/100,1)} (${F.n} ${ht(F.n,"матч","матча","матчей")}). `:"")+(N.length?`На проверке ${z.test} сыгранных матчей: ${N.map(_=>`при уверенности ≥${_.threshold}% сбывалось ${_.hit}%`).join(", ")}`:z?`На проверке ${z.test} матчей угадано ${Math.round(z.acc*100)}%`:"Точность ещё измеряется");return t("div.card",{},t("div.kicker",{},t("span",{text:x?`Модель по счёту · bo${x.bo}`:l?o.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:x?`до матча: ${o.confidence}`:`уверенность: ${o.confidence}`})),b.map((_,E)=>{let R=k[E],U=Number.isFinite(_.fair)?(R-_.fair)*100:0;return t("div.prob",{},t("span.name",{text:_.name,title:_.name}),t("span.odd",{text:Z(1/R),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(R*100)}%`}),t("u",{style:`left:${Math.round((_.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},K(R),Math.abs(U)>=3?t(`small${U>0?".pos":".neg"}`,{text:`${dt(U)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:x?"шанс серии по счёту":"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),x?t("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${x.maps.join(":")}${x.rounds?`, на карте ${x.rounds.join(":")} — шанс текущей карты ${K(x.map??.5)}`:""}. До матча модель давала ${K(o.p1)} / ${K(o.p2)}.`}):null,st(o,b),o.factors?.length?t("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,o.sport==="mma"?12:4).map(_=>t("li",{},t("span",{text:_})))):null,t("div.hint",{style:"margin-top:8px",text:x?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${o.game==="cs"?" и раунды":""} уточняют силу команд. ${o.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${y}. ${S}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function tt(e){let[o,l]=e.names,f=["0","15","30","40","Б"],b=e.tiebreak?e.points.join(":"):e.points.map(y=>f[Math.min(4,y)]||y).join(":"),x=e.sets.map(([y,z])=>`${y}:${z}`).concat(`${e.games[0]}:${e.games[1]}`).join(" "),k=e.serving==null?"":` · подаёт ${e.names[e.serving]}`;return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} по сетам · ${x} · ${b}${e.tiebreak?" (тай-брейк)":""}`})),e.names.map((y,z)=>{let N=e.probs[z],F=e.book?e.book[z]:null,S=e.compare&&Number.isFinite(F)?(N-F)*100:0;return t("div.prob",{},t("span.name",{text:y,title:y}),t("span.odd",{text:Z(1/N),title:"Честный кэф на матч по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(N*100)}%`}),Number.isFinite(F)?t("u",{style:`left:${Math.round(F*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(N),Math.abs(S)>=3?t(`small${S>0?".pos":".neg"}`,{text:`${dt(S)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс матча по счёту"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Текущий сет: ${o} ${K(e.set[0])} (кэф ${Z(1/e.set[0])}) · ${l} ${K(e.set[1])} (${Z(1/e.set[1])})`})),t("li",{},t("span",{text:`Текущий ${e.tiebreak?"тай-брейк":"гейм"}${k}: ${o} ${K(e.game[0])} · ${l} ${K(e.game[1])}`})),t("li",{},t("span",{text:`Очко на своей подаче (под довоенную силу): ${o} ${e.serve[0]}%, ${l} ${e.serve[1]}%; матч до ${e.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),t("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ut(e){let[o,l]=e.names,f=F=>F?Z(F):"—",b=e.sport==="hockey"?"период":"тайм",x=`${e.minute}' · ${Math.min(e.period,e.periods)}-й ${b}`,k=[o,"Ничья",l],y=F=>F>0?`+${F}`:`${F}`,z=(F,S,_,E,R,U)=>S?.length?t("details",{"data-key":`live-${F}`,open:G.get(`live-${F}`)||!1},t("summary",{text:F}),t("ul.facts",{},S.map(rt=>t("li",{},t("span",{text:`${R(rt)} — ${f(rt[_])} · ${U(rt)} — ${f(rt[E])}`}))))):null,N=e.red[0]||e.red[1]?` · удаления ${e.red.join(":")}`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} · ${x}${N}`})),k.map((F,S)=>{let _=e.probs[S],E=e.book?e.book[S]:null,R=e.compare&&Number.isFinite(E)?(_-E)*100:0;return t("div.prob",{},t("span.name",{text:F,title:F}),t("span.odd",{text:Z(1/_),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(_*100)}%`}),Number.isFinite(E)?t("u",{style:`left:${Math.round(E*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(_),Math.abs(R)>=3?t(`small${R>0?".pos":".neg"}`,{text:`${dt(R)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (основное время)"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Следующий гол: ${o} ${K(e.nextGoal[0])} · не будет ${K(e.nextGoal[1])} · ${l} ${K(e.nextGoal[2])}. Ожидаемый итоговый тотал ≈${e.expTotal}.`})),e.bookLines?.total?t("li",{},t("span",{text:`Тотал ${e.bookLines.total.line}: Fonbet ${e.bookLines.total.odds.map(Z).join(" / ")}, честно ${e.bookLines.total.fair.map(f).join(" / ")}`}),Math.abs(e.bookLines.total.gap)>=5?t(`small${e.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${dt(e.bookLines.total.gap)} п.п. к «больше»`}):null):null),z("Тотал — честные кэфы",e.total,"over","under",F=>`больше ${F.line}`,F=>`меньше ${F.line}`),z("Фора — честные кэфы",e.handicap,"home","away",F=>`${o} ${y(F.line)}`,F=>`${l} ${y(-F.line)}`),t("div.hint",{style:"margin-top:8px",text:`Счёт, время${e.sport==="football"?" и удаления":""} — лайв Fonbet${e.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${e.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function vt(e,o,l,f){let b=e.bookLines;if(!b)return null;let x=y=>y>0?`+${y}`:`${y}`,k=(y,z,N,F)=>t("li",{},t("span",{text:`${y}: Fonbet ${z.map(Z).join(" / ")}, честно ${N.map(S=>S?Z(S):"—").join(" / ")}`}),f&&Math.abs(F)>=5?t(`small${F>0?".pos":".neg"}`,{text:` ${dt(F)} п.п. к первой стороне`}):null);return t("ul.facts",{style:"margin-top:8px"},b.handicap?k(`Фора ${o} ${x(b.handicap.line)} / ${l} ${x(-b.handicap.line)}`,b.handicap.odds,b.handicap.fair,b.handicap.gap):null,b.total?k(`Тотал ${b.total.line} больше / меньше`,b.total.odds,b.total.fair,b.total.gap):null)}function mt(e){let o=e.live;if(!o)return null;if(o.kind==="goals")return ut(o);if(o.kind==="tennis")return tt(o);if(o.error)return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"})),t("div.hint",{text:o.error}));let[l,f]=o.names,b=S=>S?Z(S):"—",x=o.book&&(o.prior.source==="line"||o.prior.source==="model"),k=o.left>0?`${o.period>o.format.periods?"ОТ":`${o.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(o.left))} мин`:"конец игры",y=(S,_,E,R,U,rt)=>_.length?t("details",{"data-key":`live-${S}`,open:G.get(`live-${S}`)||!1},t("summary",{text:S}),t("ul.facts",{},_.map(pt=>t("li",{},t("span",{text:`${U(pt)} — ${b(pt[E])} · ${rt(pt)} — ${b(pt[R])}`}))))):null,z=S=>S>0?`+${S}`:`${S}`,N=o.quarter,F=N&&N.left>0?`${N.index}-я четверть (${N.score.join(":")}, осталось ≈${Math.max(1,Math.round(N.left))} мин): ${l} ${b(N.probs[0]?1/N.probs[0]:null)} · ничья ${b(N.draw?1/N.draw:null)} · ${f} ${b(N.probs[1]?1/N.probs[1]:null)}; разница ${N.expMargin>=0?l:f} ${Math.abs(N.expMargin).toFixed(1)}, тотал четверти ≈${N.projTotal}.`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${o.score.join(":")} · ${k}`})),o.names.map((S,_)=>{let E=o.probs[_],R=o.book?o.book[_]:null,U=x&&Number.isFinite(R)?(E-R)*100:0;return t("div.prob",{},t("span.name",{text:S,title:S}),t("span.odd",{text:Z(1/E),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(E*100)}%`}),Number.isFinite(R)?t("u",{style:`left:${Math.round(R*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(E),Math.abs(U)>=3?t(`small${U>0?".pos":".neg"}`,{text:`${dt(U)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (с ОТ)"}),o.book?t("span.model",{text:"шанс по цене этой конторы"}):null),vt(o,l,f,x),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Ожидаемая итоговая разница: ${o.expMargin>=0?l:f} ${Math.abs(o.expMargin).toFixed(1)} (разброс ±${o.sd}). Тотал ≈${o.projTotal} (±${o.sdTotal}).`})),F?t("li",{},t("span",{text:F})):null),y("Фора — честные кэфы",o.handicap,"home","away",S=>`${l} ${z(S.line)}`,S=>`${f} ${z(-S.line)}`),y("Тотал матча — честные кэфы",o.total,"over","under",S=>`больше ${S.line}`,S=>`меньше ${S.line}`),y("Тотал четверти — честные кэфы",o.quarterTotal,"over","under",S=>`больше ${S.line}`,S=>`меньше ${S.line}`),t("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${o.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${o.prior.note}.${x?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function ct(e){let o=e.verdict;return o?.lines?.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Итог"}),t("span.badge",{text:o.best?`перевес ${Math.round(o.best.edge*100)}%`:"без перевеса"})),t("ul.facts",{},o.lines.map(l=>t("li",{},t("span",{text:l})))),o.track?t("div.hint",{style:"margin-top:6px",text:o.track}):null,e.analysis.status!=="done"?t("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function st(e,o){let l=e.durations;if(e.sport!=="mma"||!l)return null;let f=x=>x?Z(x):"—",b=o.map(x=>x.name);return t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Честные кэфы"}),t("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),t("ul.facts",{},t("li",{},t("span",{text:`Победа: ${b[0]||"первый"} ${f(e.fair?.p1)} · ${b[1]||"второй"} ${f(e.fair?.p2)}`})),l.lines.map(x=>t("li",{},t("span",{text:`Тотал ${x.line} раунда: больше ${f(x.over)} · меньше ${f(x.under)}`}))),t("li",{},t("span",{text:`Дойдёт до решения: да ${f(l.decision.yes)} · нет ${f(l.decision.no)}`})),t("li",{},t("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),t("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function it(e){let l=((e.compare?.model||e.analysis?.result?.model||e.model)?.profiles||[]).filter(f=>f?.lines?.length);return l.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Профили"}),t("span.badge",{text:"модель Линзы"})),l.map((f,b)=>t("details",{"data-key":`profile-${b}`,open:G.get(`profile-${b}`)??b===0},t("summary",{text:f.name}),t("ul.facts",{},f.lines.map(x=>t("li",{},t("span",{text:x})))))),t("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function _t(e){let o=e.facts;if(!o?.facts?.length)return null;let l=o.facts.filter(k=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(k.text)),f=o.facts.filter(k=>!l.includes(k)&&/состав|стартов/i.test(k.text)),b=o.facts.filter(k=>!l.includes(k)&&!f.includes(k)),x=(k,y,z)=>y.length?t("details",{"data-key":`facts-${k}`,open:z||G.get(`facts-${k}`)||!1},t("summary",{text:`${k} (${y.length})`}),t("ul.facts",{},y.map(N=>t("li",{},t("span",{text:N.text}))))):null;return t("div.card",{},t("div.kicker",{},t("span",{text:"Составы, травмы, форма"}),t("span.badge",{text:o.source||o.facts[0].source||"источник"})),x("Травмы и отсутствующие",l,!0),x("Составы",f,!0),x("Форма, таблица, очные встречи",b,!l.length&&!f.length),t("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",o.url?t("a",{href:o.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let ft=e=>`${Math.round(e).toLocaleString("ru-RU")} ₽`,ht=(e,o,l,f)=>{let b=e%100,x=e%10;return b>10&&b<20?f:x===1?o:x>=2&&x<=4?l:f},kt=e=>(e.erid?["Реклама",e.legal,`erid ${e.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",e.legal].filter(Boolean).join(" · "))+" · 18+",Nt=(e,o)=>t("a.btn.ghost.small",{href:e.go?`${e.go}?s=panel`:e.url,target:"_blank",rel:"noopener sponsored"},nt("link",13),o||`Открыть у ${e.name}`),Tt=e=>e.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":e.code,title:e.bonus||"Скопировать промокод"},`Промокод ${e.code}`):null;function oe(e){let o=(e.partners||[]).filter(l=>l.url||l.code);return o.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:o.length===1?`Промокод ${o[0].name}`:"Промокоды контор"})),o.map(l=>t("div.partner",{},t("div.partner-text",{},t("b",{text:l.name}),l.bonus?t("span",{text:` — ${l.bonus}`}):null),t("div.partner-links",{},Tt(l),l.url?Nt(l):null),t("div.hint",{text:kt(l)})))):null}function re(e,o={}){if(e.status==="idle")return null;if(e.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let l=e.labels||[];if(!e.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let f=l.map((S,_)=>Math.max(...e.rows.map(E=>E.odds[_]||0))),b=Object.fromEntries((o.partners||[]).map(S=>[S.id,S])),x=S=>S.book&&S.book!==o.bookId&&!S.sharp&&b[S.book]||null,k=o.stake||1e3,y=e.rows.find(S=>S.here)||e.rows[0],N=l.map((S,_)=>{let E=y?.odds?.[_],R=e.rows.filter(U=>U!==y&&!U.sharp&&U.odds[_]).sort((U,rt)=>rt.odds[_]-U.odds[_])[0];return!E||!R||R.odds[_]<=E?null:{label:S,row:R,odd:R.odds[_],mine:E,gain:(R.odds[_]-E)*k}}).filter(Boolean).sort((S,_)=>_.gain-S.gain)[0],F=e.rows.map(x).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),l.map(S=>t("th",{text:S}))),e.rows.map(S=>{let _=x(S);return t("tr",{},t("td.name",{title:S.sharp?"Цена с мирового рынка, для сравнения":""},S.name,_?t("div.partner-links",{},_.url?Nt(_):null,Tt(_)):null),S.odds.map((E,R)=>t(`td${E&&E===f[R]&&e.rows.length>1?".best":""}`,{text:E?Z(E):"—"})))})),N&&N.gain>=1?t("div.gain",{},`На «${N.label}» у ${N.row.name} кэф ${Z(N.odd)} против ${Z(N.mine)} здесь: со ставки ${ft(k)} выигрыш больше на `,t("b",{text:ft(N.gain)}),"."):null,F.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(F.map(kt))].join(" ")}):null,e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null)}function ae(e){let o=[],l=(b,x,k)=>o.push(t("dt",{text:b}),t(`dd${k?"."+k:""}`,{text:x}));Number.isFinite(e.fair)?(l("Шанс по линии без маржи",K(e.fair,1)),l("Кэф без маржи конторы",Z(e.fairOdd)),l("Маржа конторы в этом рынке",K(e.margin,1))):l("Заложено в кэфе (с маржой)",K(1/e.odd,1)),Number.isFinite(e.model)&&(l("Оценка модели",K(e.model,1)),l("Ожидание на рубль по модели",`${dt(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&l(`Лучшая цена: ${e.best.name}`,Z(e.best.odd),e.best.odd>e.odd?"pos":"");let f=e.best?.partner&&(e.best.partner.url||e.best.partner.code)?e.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:e.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},nt("close",13))),t("div.pick-head",{},t("span.big",{text:Z(e.odd)}),t("span.what",{text:e.label,title:e.label})),t("dl.kv",{},o),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},nt("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")),f?t("div.partner",{style:"margin-top:10px"},e.best.gain>=1?t("div.gain",{},`У ${f.name} этот кэф выше: со ставки ${ft(e.stake||1e3)} выигрыш больше на `,t("b",{text:ft(e.best.gain)}),"."):null,t("div.partner-links",{},f.url?Nt(f):null,Tt(f)),t("div.hint",{text:kt(f)})):null)}function se(e){let o=(l,f)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),f.map(b=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:b.nick}),t("span",{style:"color:var(--lz-muted)",text:b.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(e.homeName,e.home),o(e.awayName,e.away)))}function Pt(e,o){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:o.home}),t("th",{text:o.away})),e.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),e.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function It(e){let o=[];if(e.pick&&o.push(ae({...e.pick,stake:e.stake})),!e.match)return o.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(B(e.match)),e.esports&&o.push(se(e.esports)),e.match.stats?.rows?.length&&o.push(Pt(e.match.stats,e.match)),e.line&&o.push(P(e.line));let l=J(e);l&&o.push(l);let f=mt(e);f&&o.push(f);let b=Y(e);b&&o.push(b);let x=ct(e);x&&o.push(x);let k=it(e);k&&o.push(k);let y=_t(e);y&&o.push(y);let z=e.analysis.status==="loading";o.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:z},nt("spark"),z?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},nt("scale"),"Сравнить цены"))),e.quota&&o.push(t("div.hint.center-text",{text:e.quota}));let N=oe(e);N&&o.push(N);let F=V(e);F&&o.push(F);let S=re(e.compare,e);return S&&o.push(S),o}function Rt(e){let o=e.margins;if(!o)return null;let l=[t("div",{},`Сегодня вы открыли ${o.n} ${ht(o.n,"матч","матча","матчей")} до начала: в основной исход ${e.bookName||"контора"} закладывает в среднем `,t("b",{text:K(o.here,1)})," маржи.")];return o.best?(l.push(t("div",{style:"margin-top:6px"},`На тех же ${o.best.n} ${ht(o.best.n,"матче","матчах","матчах")} у ${o.best.name} — `,t("b",{text:K(o.best.there,1)}),` против ${K(o.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((o.best.here-o.best.there)*100).toFixed(1)} п.п.`)),o.partner&&l.push(t("div.partner-links",{style:"margin-top:8px"},o.partner.url?Nt(o.partner):null,Tt(o.partner)),t("div.hint",{text:kt(o.partner)}))):l.push(t("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),t("div.card",{},t("div.kicker",{},t("span",{text:"Сколько маржи вы отдаёте"}),t("span.badge",{text:"сегодня"})),...l)}function ie(e){let o=e.scan,l=Rt(e);return o?.rows?.length?[l,t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),t("span.badge",{text:`средняя маржа ${K(o.average,1)}`})),t("table",{},t("tr",{},t("th",{text:o.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),o.rows.map(f=>t("tr.click",{"data-act":"scan-go","data-arg":String(f.index),title:"Показать на странице"},t("td.name",{},f.name,f.sub?t("span.sub",{text:f.sub}):null),t("td",{},f.fav,t("span.sub",{text:K(f.favPct)})),t(`td${f.low?".best":""}`,{text:K(f.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:o.note}))]:[l,t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function le(e){let o=e.express;if(!o.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${o.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},nt("trash",13),"Очистить")),o.legs.map(f=>t("div.leg",{},t("div.t",{},t("b",{text:f.label,title:f.label}),t("span",{text:f.title,title:f.title})),t("span.o",{text:Z(f.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":f.id,title:"Убрать",style:"width:24px;height:24px"},nt("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:Z(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:K(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:Z(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:K(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function Dt(e){let o=e.edges||{status:"idle"},l=z=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),z?t("span.badge",{text:z}):null);if(o.status==="loading"&&!o.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[t("div.card",{},l(),t("div.note.warn",{},nt("alert"),t("span",{text:o.error})))];let f=o.data;if(!f)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let b=z=>z==null?"—":`${z>=0?"+":"−"}${(Math.abs(z)*100).toFixed(1)}%`,x=z=>new Date(z).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),k=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(f.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(f.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:b(f.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:f.positiveWeek==null?"—":K(f.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),y=(f.signals||[]).map(z=>t("tr",{},t("td.name",{},`${z.home} — ${z.away}`,t("span.sub",{text:`${z.league} · ${x(z.start)}`})),t("td",{},z.label,t("span.sub",{text:z.book})),t("td",{text:Z(z.odds)}),t("td",{text:Z(1/z.p),title:`Честная цена по ${z.count} конторам`}),t("td.best",{text:`+${(z.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(f.full?"тариф «Макс»":"витрина"),y.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),y):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),f.note?t("div.hint",{style:"margin-top:8px"},f.note," ",i.bot?t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),k]}function Ft(e){let o=e.settings,l=(f,b,x)=>t("div.seg",{},x.map(([k,y])=>t(`button${b===k?".on":""}`,{type:"button","data-act":f,"data-arg":k,text:y})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(o.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),i.bot&&!o.licenseMask?[" ",t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function ce(e){ot=e;let o=JSON.stringify(e);if(o===D)return;D=o;for(let y of h.querySelectorAll("details[data-key]"))G.set(y.dataset.key,y.open);let l=h.scrollTop;$.textContent=e.bookName?`· ${e.bookName}`:"",p.classList.toggle("off",e.settings.overlay==="off"),w.replaceChildren(nt(e.theme==="dark"?"sun":"moon")),v.replaceChildren(nt(e.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",e.settings.overlay!=="off"),M.classList.toggle("on",e.tab==="settings"),M.dataset.arg=e.tab==="settings"?e.backTab:"settings";let f=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];d.replaceChildren(...f.map(([y,z])=>t(`button.tab${e.tab===y?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":y},z,y==="express"&&e.express.legs.length?t("span.count",{text:String(e.express.legs.length)}):null)));let b=e.tab==="settings"?Ft(e):e.tab==="scan"?ie(e):e.tab==="express"?le(e):e.tab==="edges"?Dt(e):It(e),x=e.update?t("div.card.soft.update",{},t("b",{text:`Вышла Линза ${e.update.version}`})," — ",e.update.url?t("a",{href:e.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,k=e.whatsnew?.changes?.length&&e.tab!=="settings"?t("div.card.soft.update",{},t("b",{text:`Линза обновилась до ${e.whatsnew.version}`}),t("ul.facts",{style:"margin-top:6px"},e.whatsnew.changes.flatMap(y=>y.items).slice(0,6).map(y=>t("li",{},t("span",{text:y})))),t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;h.replaceChildren(...[x,k,...b].filter(Boolean)),h.scrollTop=l,g.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function de(e){n.setAttribute("data-theme",e)}function Ot(){L.hidden=!1,a.opened?.()}function wt(){L.hidden=!0}function $t(){L.hidden?Ot():wt()}function Ut(e){e?.fab&&T(c,e.fab.left,e.fab.top),e?.panel&&T(L,e.panel.left,e.panel.top)}let s=0;function m(e){u.querySelector(".toast")?.remove();let o=t("div.toast",{text:e,role:"status"});u.appendChild(o),clearTimeout(s),s=setTimeout(()=>o.remove(),2600)}return{render:ce,setTheme:de,open:Ot,close:wt,toggle:$t,restore:Ut,toast:m,shadow:u,rect:()=>L.hidden?null:L.getBoundingClientRect(),get isOpen(){return!L.hidden},get view(){return ot}}}var nn="Расширение обновилось. Обновите эту вкладку (F5).";function xt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function et(r,a={}){if(!xt())return{ok:!1,error:nn,code:"reload"};try{return await chrome.runtime.sendMessage({type:r,...a})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(i){let n=String(i?.message||i);return/context invalidated|message port closed|receiving end does not exist/i.test(n)||!xt()?{ok:!1,error:nn,code:"reload"}:{ok:!1,error:n}}}function on(r){if(xt())try{chrome.runtime.onMessage.addListener(a=>{r(a)})}catch{}}async function ye(r){if(!xt())return{};try{return await chrome.storage.local.get(r)}catch{return{}}}function yt(r){if(xt())try{chrome.storage.local.set(r)}catch{}}var rn=(r=Date.now())=>new Date(r).toISOString().slice(0,10);function ee(r,a=Date.now()){return r&&r.day===rn(a)&&r.items&&typeof r.items=="object"?r:{day:rn(a),items:{}}}function an(r,{key:a,book:i,margin:n}){if(!a||!Number.isFinite(n)||n<=0||n>.5)return!1;let u=Math.round(n*1e4)/1e4,p=r.items[a];return p&&p.here===u&&p.book===i?!1:(r.items[a]={book:i,here:u,others:p?.others||{}},!0)}function sn(r,a,i){let n=r.items[a];if(!n)return!1;let u=!1;for(let p of i||[]){if(p.here||p.sharp||!p.odds?.length||p.odds.some(h=>!(h>1)))continue;let c=zt(p.odds);if(c.kind!=="full"||!(c.margin>0))continue;let d=Math.round(c.margin*1e4)/1e4;n.others[p.name]!==d&&(n.others[p.name]=d,u=!0)}return u}function ln(r,a){let i=Object.values(r?.items||{}).filter(c=>c.book===a);if(!i.length)return null;let n=c=>c.reduce((d,h)=>d+h,0)/c.length,p=[...new Set(i.flatMap(c=>Object.keys(c.others||{})))].map(c=>{let d=i.filter(h=>Number.isFinite(h.others?.[c]));return d.length>=2?{name:c,n:d.length,there:n(d.map(h=>h.others[c])),here:n(d.map(h=>h.here))}:null}).filter(Boolean).sort((c,d)=>c.there-d.there);return{n:i.length,here:n(i.map(c=>c.here)),best:p[0]||null,others:p}}var ro=[{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function cn(r,a){let i=String(r||"").split(".").map(Number),n=String(a||"").split(".").map(Number);for(let u=0;u<Math.max(i.length,n.length);u++){let p=(i[u]||0)-(n[u]||0);if(p)return p>0}return!1}function dn(r,a){return ro.filter(i=>cn(i.version,r)&&!cn(i.version,a))}var Ct=r=>Number.isFinite(r)?(Math.round(r*100)/100).toFixed(2):"—",un=r=>`${Math.round(r*100)}%`,ao=(r,a)=>r*a-1;function so(r){return r<.03?null:r<.06?"небольшая — примерно половина обычной":r<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function pn(r,{source:a="",reasons:i=[],risk:n=""}={}){let u=(r||[]).filter(v=>Number(v.odd)>1&&v.p>.01&&v.p<.99).map(v=>({...v,fairOdd:1/v.p,edge:ao(v.p,Number(v.odd))}));if(!u.length)return null;let c=[...u].sort((v,M)=>M.edge-v.edge)[0],d=c.edge>=.03?{...c,size:so(c.edge)}:null,h=u.filter(v=>v!==c||!d).map(v=>({...v,note:v.edge>=.03?`перевес ${un(v.edge)} к честной цене ${Ct(v.fairOdd)}`:v.edge>-.02?`честная цена (${Ct(v.fairOdd)}), перевеса нет`:`цена ниже честной (${Ct(v.fairOdd)})`})),g=[];if(d){let v=d.source||a;g.push(`Лучшая цена: ${d.label} по ${Ct(d.odd)} — перевес около ${un(d.edge)} к честной цене ${Ct(d.fairOdd)}${v?` (${v})`:""}. Сумма: ${d.size}.`),i.length&&g.push(`За: ${i.join(" ")}`),n&&g.push(`Главный риск: ${n}`)}else g.push(`Перевеса нет: все цены близки к честным или ниже${a?` (${a})`:""} — разумнее пропустить.`);let $=[...h].sort((v,M)=>M.edge-v.edge).slice(0,6),w=h.length-$.length;return h.length&&g.push(`${d?"Остальное":"По рынкам"}: ${$.map(v=>`${v.label} по ${Ct(v.odd)} — ${v.note}`).join("; ")}${w>0?`; ещё ${w} — с меньшим перевесом или без него`:""}.`),g.push("Это расчёт, а не гарантия: проиграть можно и при перевесе в цене. 18+"),{best:d,others:h,lines:g}}function Bt(r){let a=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),i=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return a(r[0])&&i(r[1])?0:i(r[0])&&a(r[1])?1:-1}var io=r=>{let a=r<0?-1:1,i=Math.abs(r),n=1/(1+.3275911*i);return a*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-i*i))},ve=r=>.5*(1+io(r/Math.SQRT2));function mn(r,a,i){if(!(Math.abs(i-Math.round(i))<1e-9)){let c=1-ve((i-r)/a);return{win:c,push:0,lose:1-c}}let u=1-ve((i+.5-r)/a),p=ve((i-.5-r)/a);return{win:u,push:Math.max(0,1-u-p),lose:p}}function lo(r,a,i){let n=mn(r,a,-i);return{home:n.win,away:n.lose,push:n.push}}function co(r,a,i){let n=mn(r,a,i);return{over:n.win,under:n.lose,push:n.push}}function fn(r,{handicap:a=null,total:i=null}={},n=["Хозяева","Гости"]){let u=r?.lines;if(!u||!Number.isFinite(u.margin)||!(u.sigma>0))return[];let p=[],c=g=>g>0?`+${g}`:`${g}`,d=(g,$)=>g/(1-$||1),h=(g,$)=>1/g/(1/g+1/$);if(a&&Number.isFinite(a.line)&&Math.abs(a.line)<60&&a.home>1&&a.away>1){let g=lo(u.margin,u.sigma,a.line);Math.abs(d(g.home,g.push)-h(a.home,a.away))<=.3&&p.push({label:`Фора ${n[0]} ${c(a.line)}`,odd:a.home,p:d(g.home,g.push),kind:"handicap",side:"home",source:"модель Линзы"}),p.length&&p.push({label:`Фора ${n[1]} ${c(-a.line)}`,odd:a.away,p:d(g.away,g.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(i&&Number.isFinite(u.total)&&u.sigmaT>0&&Number.isFinite(i.line)&&i.line>50&&i.over>1&&i.under>1){let g=co(u.total,u.sigmaT,i.line);Math.abs(d(g.over,g.push)-h(i.over,i.under))<=.3&&(p.push({label:`Тотал больше ${i.line}`,odd:i.over,p:d(g.over,g.push),kind:"total",source:"модель Линзы"}),p.push({label:`Тотал меньше ${i.line}`,odd:i.under,p:d(g.under,g.push),kind:"total",source:"модель Линзы"}))}return p}var qt={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},ke=[1];for(let r=1;r<=40;r+=1)ke[r]=ke[r-1]*r;var hn=(r,a)=>a<=0?r===0?1:0:Math.exp(-a)*a**r/ke[r];function uo(r,a){let i=a.weights.length,n=a.minutes/i,u=Math.max(0,Math.min(a.minutes,r)),p=0;for(let d=0;d<i;d+=1){let h=d*n,g=h+n,$=i/(a.periods||1),w=(d+1)%$===0&&a.stoppage?.[Math.floor(d/$)]||0;u<=h?p+=a.weights[d]:u<g&&(p+=a.weights[d]*((g-u+w)/(n+w)))}let c=a.weights.reduce((d,h)=>d+h,0);return p/c}function gn(r,a,i){let n=[];for(let u=0;u<=i;u+=1){n[u]=[];for(let p=0;p<=i;p+=1)n[u][p]=hn(u,r)*hn(p,a)}return n}function po(r,a,i,n=null){let u=gn(r,a,i),p=0,c=0,d=0,h=0;for(let g=0;g<=i;g+=1)for(let $=0;$<=i;$+=1){let w=u[g][$];g>$?p+=w:g===$?c+=w:d+=w,n!=null&&g+$>n&&(h+=w)}return{p1:p,px:c,p2:d,over:h}}function bn({p1:r,px:a,p2:i,line:n=null,pOver:u=null},p=qt.football){let c=p.total,d=(g,$)=>{let w=po(g,$,p.maxGoals,n!=null&&u!=null?n:null),v=(w.p1-r)**2+(w.p2-i)**2+(a!=null?(w.px-a)**2:0);return n!=null&&u!=null?v+=(w.over-u)**2:v+=.02*((g+$-c)/c)**2,v},h={lh:c*p.homeShare,la:c*(1-p.homeShare),e:1/0};for(let g=.4;g>=.01;g/=2){let $=h;for(let w=-4;w<=4;w+=1)for(let v=-4;v<=4;v+=1){let M=Math.max(.03,$.lh+w*g),O=Math.max(.03,$.la+v*g),L=d(M,O);L<h.e&&(h={lh:M,la:O,e:L})}}return{lh:h.lh,la:h.la}}function xn(r,a,i=qt.football){let[n,u]=r.score.map(Number),p=uo(Number(r.minute)||0,i),c=n-u,d=Math.sign(c),h=1+(i.late||0)*((Number(r.minute)||0)/i.minutes-.5),g=(Math.abs(c)>=2?.6:1)*Math.max(0,h),$=d<0?i.trail*g:d>0?i.lead*g:0,w=d>0?i.trail*g:d<0?i.lead*g:0,[v,M]=(r.red||[0,0]).map(V=>Math.min(2,Number(V)||0)),O=(V,W)=>(1+i.redOwn)**V*(1+i.redOpp)**W,L=Math.max(0,a.lh*p*(1+$)*O(v,M)),q=Math.max(0,a.la*p*(1+w)*O(M,v)),D=i.maxGoals,ot=gn(L,q,D),G=0,at=0,I=0;for(let V=0;V<=D;V+=1)for(let W=0;W<=D;W+=1){let J=n+V,X=u+W;J>X?G+=ot[V][W]:J===X?at+=ot[V][W]:I+=ot[V][W]}let C=G+at+I||1,T=V=>{let W=0,J=0;for(let X=0;X<=D;X+=1)for(let Q=0;Q<=D;Q+=1){let Y=n+u+X+Q;Y>V?W+=ot[X][Q]:Y===V&&(J+=ot[X][Q])}return{over:W,push:J,under:Math.max(0,1-W-J)}},A=V=>{let W=0,J=0;for(let X=0;X<=D;X+=1)for(let Q=0;Q<=D;Q+=1){let Y=n+X-(u+Q)+V;Y>0?W+=ot[X][Q]:Y===0&&(J+=ot[X][Q])}return{home:W,push:J,away:Math.max(0,1-W-J)}},B=L+q,P=Math.exp(-B);return{p1:G/C,px:at/C,p2:I/C,lh:L,la:q,share:p,expTotal:n+u+B,nextGoal:{home:B>0?(1-P)*(L/B):0,away:B>0?(1-P)*(q/B):0,none:P},total:T,handicap:A}}var we=(r,a)=>1/r/(1/r+1/a);function mo(r,a){let i=qt[a];if(!i||!r?.odds||r.odds.length!==3)return null;let n=zt(r.odds).fair;if(!n)return null;let u=r.total,p=u&&u.over>1&&u.under>1?we(u.over,u.under):null;return p==null?null:bn({p1:n[0],px:n[1],p2:n[2],line:u.line,pOver:p},i)}function yn(r,a,i,n=["Хозяева","Гости"]){let u=mo(r,i);if(!u)return[];let p=qt[i],c=xn({score:[0,0],minute:0},u,p),d=[],h=new Set,g=w=>w>0?`+${w}`:`${w}`,$=w=>{let v=String(w??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return v?Number(v[v.length-1]):NaN};for(let w of a||[]){if(w.kind!=="total"&&w.kind!=="handicap"||w.outcomes?.length!==2)continue;let v=`${w.title||""} ${w.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(v.replace(/осн\.?\s*время/i,"")))continue;if(w.kind==="handicap"){let I=$(w.outcomes[0].label);if(Number.isFinite(I)||(I=$(w.line)),!Number.isFinite(I)||Math.abs(I)>4||h.has(`h${I}`))continue;let C=Number(w.outcomes[0].odd),T=Number(w.outcomes[1].odd);if(!(C>1&&T>1))continue;let A=c.handicap(I),B=1-A.push||1;if(Math.abs(A.home/B-we(C,T))>.15)continue;h.add(`h${I}`),d.push({label:`Фора ${n[0]} ${g(I)}`,odd:C,p:A.home/B,kind:"handicap",side:"home",line:I,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${g(-I)}`,odd:T,p:A.away/B,kind:"handicap",side:"away",line:-I,source:"Fonbet без маржи"});continue}let M=Number(String(w.line||"").replace(",","."));if(!Number.isFinite(M)||M<=0||M>(i==="hockey"?12:9)||h.has(M))continue;let O=Bt(w.outcomes.map(I=>I.label));if(O<0)continue;let L=c.total(M),q=1-L.push||1,D=L.over/q,ot=L.under/q,G=Number(w.outcomes[O].odd),at=Number(w.outcomes[1-O].odd);!(G>1&&at>1)||Math.abs(D-we(G,at))>.2||(h.add(M),d.push({label:`Тотал больше ${M}`,odd:G,p:D,kind:"total",line:M,source:"Fonbet без маржи"},{label:`Тотал меньше ${M}`,odd:at,p:ot,kind:"total",line:M,source:"Fonbet без маржи"}))}return d}var ne=globalThis.__lzBus,$e=ne&&window.top===window?Ue(location.hostname):null;$e&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,fo($e.adapter,$e.book));async function fo(r,a){let i=await ye(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...pe,...i["lz.settings"]||{}},positions:(i["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:ho(i["lz.express"]),margins:ee(i["lz.margins"]),whatsnew:i["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},u=new WeakMap,p=new WeakMap,c=Ke(),d=en({bus:ne,brand:Vt,actions:le()});d.restore(n.positions);function h(s){let m=s.outcomes.map(l=>l.odd).join("/"),e=u.get(s);if(e?.sig===m)return e.set;let o=zt(s.outcomes.map(l=>l.odd));return u.set(s,{sig:m,set:o}),o}function g(){return n.match?n.analysis.get(n.match.key):null}function $(s){let m=g()?.result;if(!m?.model||s.scope==="list"||!n.match||!Object.values(m.shift||{}).some(b=>Math.abs(b)>=.5))return null;let{home:e,draw:o,away:l}=m.model,f=s.outcomes.length;if(s.kind==="1x2"&&s.main&&f===3)return[e,o,l];if(s.kind==="12"&&s.main&&f===2&&o<.005)return[e,l];if(s.kind==="dc"&&s.main&&f===3)return[e+o,e+l,o+l];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&f===2){let b=s.period===n.match.home?e:s.period===n.match.away?l:null;if(b!=null)return[b,1-b]}return null}function w(){let s=n.markets.filter(m=>m.scope!=="list"&&m.main&&(m.kind==="1x2"||m.kind==="12"));return s.find(m=>m.scope==="top")||s[0]||null}function v(s,m){let e=s.outcomes[m].label;return s.scope==="list"?!s.event||!s.main?e:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][m]||e:s.kind==="12"&&[s.event.home,s.event.away][m]||e:n.match?s.kind==="1x2"?[n.match.home,"Ничья",n.match.away][m]||e:s.kind==="12"&&[n.match.home,n.match.away][m]||e:e}function M(){let s=n.settings.overlay,m=[];for(let o of n.markets){if(o.outcomes.forEach((z,N)=>p.set(z.el,{market:o,index:N})),s==="off")continue;let l=h(o);if(l.kind==="partial")continue;let f=$(o),b=f||l.fair,x=0;for(let z=1;z<l.fair.length;z+=1)l.fair[z]>l.fair[x]&&(x=z);let k="accent";if(f){let z=0;for(let N=1;N<f.length;N+=1)f[N]-l.fair[N]>f[z]-l.fair[z]&&(z=N);f[z]-l.fair[z]>=.015&&(x=z,k="pos")}let y=o.scope!=="list"||o.main&&(o.kind==="1x2"||o.kind==="12");o.outcomes.forEach((z,N)=>{let F=N===x&&y;!F&&s!=="all"||m.push({el:z.el,frame:F,chip:bt(b[N]),tone:F?k:"quiet"})})}let e=O();if(e){let o=m.find(l=>l.el===e.item.el);o?o.selected=!0:m.push({el:e.item.el,frame:!1,selected:!0,chip:null})}c.set(m)}function O(){if(!n.selected)return null;let s=n.markets.find(e=>e.id===n.selected.id),m=s?.outcomes[n.selected.index];return m?.el?.isConnected?{market:s,item:m,index:n.selected.index}:null}function L(){if(n.settings.theme!=="auto")return n.settings.theme;for(let s of[document.body,document.documentElement]){let e=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!e||e[4]==="0")continue;return(.2126*e[1]+.7152*e[2]+.0722*e[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let q=0;function D(){clearTimeout(q),q=setTimeout(()=>yt({"lz.margins":n.margins}),1500)}function ot(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ee(n.margins);let s=P();s&&an(n.margins,{key:n.match.key,book:a.id,margin:s.margin})&&D()}function G(){location.href!==n.url&&(n.url=location.href,n.selected=null,c.hideTip());let s="other",m=[],e=null;try{s=r.pageType(document,location),m=r.collect(document,location),e=r.readMatch(document,location)}catch(l){console.error("[Линза] страница не прочитана",l)}s!==n.pageType&&(n.pageType=s,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=s==="match"?"match":"scan")),n.markets=m,n.match=e,ot();let o=L();o!==n.theme&&(n.theme=o),c.setTheme(n.theme),d.setTheme(n.theme),M(),ft(),C(),d.isOpen&&(ht(),Pt(),Rt(),kt(),d.render(Y()))}let at=new Set,I=null;function C(){if(r.observeTargets)for(let s of r.observeTargets(document))at.has(s)||(at.add(s),I=I||new MutationObserver(B),I.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let T=0,A=0;function B(){let s=Date.now();A||(A=s),clearTimeout(T);let m=s-A>900?0:220;T=setTimeout(()=>{A=0,!document.hidden&&G()},m)}function P(){let s=w();if(!s)return null;let m=h(s);if(m.kind!=="full")return null;let e=$(s);return{title:"Что заложено в цене",margin:m.margin,rows:s.outcomes.map((o,l)=>({name:v(s,l),odd:o.odd,fair:m.fair[l],model:e?e[l]:null})),overtime:V()}}function V(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let s=n.markets.find(e=>e.scope!=="list"&&e.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${e.title} ${e.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${e.title} ${e.period}`));if(!s)return null;let m=h(s);return m.kind!=="full"?null:{title:[s.title,s.period].filter(Boolean).join(" · "),rows:s.outcomes.map((e,o)=>({name:v(s,o)||[n.match.home,n.match.away][o],odd:e.odd,fair:m.fair[o]}))}}function W(){let s=O();if(!s)return null;let{market:m,item:e,index:o}=s,l=h(m),f=$(m),b=l.fair?l.fair[o]:null,x=m.event?`${m.event.home} — ${m.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",k=n.match?n.compare.get(n.match.key):null,y=null;if(k?.rows?.length&&m.main&&(m.kind==="1x2"||m.kind==="12")&&m.scope!=="list")for(let N of k.rows){let F=N.odds[o];F&&(!y||F>y.odd)&&(y={name:N.name,odd:F,book:N.book||""})}y&&(y.partner=y.book&&y.book!==a.id&&n.partners.data?.[y.book]||null,y.gain=Math.round((y.odd-e.odd)*(n.settings.stake||1e3)));let z=`${m.id}#${o}`;return{market:[m.title,m.period,m.line].filter(Boolean).join(" · "),label:[v(m,o),x].filter(Boolean).join(" · "),odd:e.odd,fair:b,margin:l.margin,fairOdd:b?1/b:null,model:f?f[o]:null,ev:f?Fe(f[o],e.odd):null,best:y,canAdd:Number.isFinite(b)&&!n.express.some(N=>N.id===z),inExpress:n.express.some(N=>N.id===z),note:l.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":f?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function J(){let s=ln(ee(n.margins),a.id);if(!s)return null;let m=s.best&&s.best.there<s.best.here?s.best:null,e=m&&mt().find(o=>o.name===m.name&&(o.url||o.code))||null;return{...s,best:m,partner:e}}function X(){let s=[];if(n.pageType==="match"?n.markets.forEach((l,f)=>{if(l.scope==="list")return;let b=h(l);if(b.kind!=="full")return;let x=0;for(let k=1;k<b.fair.length;k+=1)b.fair[k]>b.fair[x]&&(x=k);s.push({index:f,name:l.title,sub:[l.period,l.line].filter(Boolean).join(" · "),margin:b.margin,fav:l.outcomes[x].label,favPct:b.fair[x]})}):n.markets.forEach((l,f)=>{if(!l.event||!l.main||l.kind!=="1x2"&&l.kind!=="12")return;let b=h(l);if(b.kind!=="full")return;let x=0;for(let y=1;y<b.fair.length;y+=1)b.fair[y]>b.fair[x]&&(x=y);let k=l.kind==="1x2"?[l.event.home,"Ничья",l.event.away][x]:[l.event.home,l.event.away][x];s.push({index:f,name:`${l.event.home} — ${l.event.away}`,sub:l.event.league||l.event.time,margin:b.margin,fav:k,favPct:b.fair[x]})}),!s.length)return null;let m=new Set;for(let l=s.length-1;l>=0;l-=1){let f=`${s[l].name}|${s[l].sub}`;m.has(f)?s.splice(l,1):m.add(f)}let e=s.reduce((l,f)=>l+f.margin,0)/s.length;s.sort((l,f)=>l.margin-f.margin);let o=s.slice(0,16);return o.forEach(l=>{l.low=l.margin<=e*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:e,rows:o,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${o.length} из ${s.length}, сначала самые дешёвые.`}}function Q(){let s=n.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function Y(){let s=n.match?.key,m=s&&n.analysis.get(s)||{status:"idle",steps:[]},e=s&&n.compare.get(s)||{status:"idle"},o=n.match?.live&&r.readEsportsWidget?r.readEsportsWidget(document):null,l=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:a.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Me[n.match.sport]||""}:null,esports:o?{...o,homeName:n.match.home,awayName:n.match.away}:null,line:P(),analysis:{status:m.status,steps:m.steps||[],result:m.result||null,error:m.error||"",needKey:!!m.needKey},compare:e,consensus:s&&n.consensus.get(s)||null,model:s&&n.model.get(s)||null,live:se(s),verdict:oe(s),facts:s&&n.facts.get(s)||null,pick:W(),scan:n.tab==="scan"?X():null,margins:n.tab==="scan"?J():null,edges:n.edges,bookId:a.id,partners:mt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Te(n.express)},quota:Q(),update:n.status.update?{version:n.status.update,url:Vt.site?`${Vt.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:dn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:l.mode,proxy:l.proxy,ready:l.ready,hasKey:l.hasKey,keyMask:l.keyMask,licenseMask:l.licenseMask,plan:l.plan==="free"||!l.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[l.plan]||"Про"}»${l.until?` до ${l.until.split("-").reverse().join(".")}`:""}.`,usage:l.limit?`Сегодня разборов: ${l.used} из ${l.limit}.`:""}}}let tt=()=>{d.isOpen&&d.render(Y())};function ut(s){Object.assign(n.settings,s),yt({"lz.settings":n.settings}),G(),d.render(Y())}async function vt(s=!1){if(!s&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let m=await et("lz:partners",{force:s});m.ok&&m.data&&typeof m.data=="object"&&(n.partners.data=m.data,d.isOpen&&d.render(Y()),ct())}let mt=()=>Object.values(n.partners.data||{}).filter(s=>s&&s.id!==a.id);function ct(){if(!d.isOpen||n.tab!=="match"||!n.match)return;let s=mt().filter(m=>m.url||m.code).map(m=>m.id);s.length&&et("lz:partner-seen",{ids:s,s:"panel"})}async function st(){n.edges={...n.edges,status:"loading",error:""};let s=await et("lz:edges",{sport:n.match?.sport||""});n.edges=s.ok?{status:"done",data:s.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:s.error,at:Date.now()},tt()}async function it(){let s=await et("lz:status");s.ok&&(n.status=s.data),tt()}function _t(){let s=w(),m=s?h(s):null;return{book:a.name,match:n.match,market:s&&m?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((e,o)=>v(s,o)),odds:s.outcomes.map(e=>e.odd)}:null}}function ft(){if(!n.match||!xt())return;let s=_t();if(!s.market)return;let m=`${n.match.key}|${s.market.odds.join("/")}`;m!==ft.last&&(ft.last=m,et("lz:quote",s))}async function ht(){let s=n.match;if(!s||s.live||n.consensus.has(s.key))return;let m=_t();if(!m.market?.odds?.length)return;n.consensus.set(s.key,null);let e=await et("lz:consensus",{match:s,size:m.market.odds.length});n.consensus.set(s.key,e.ok&&e.data?.consensus?e.data:null),n.match?.key===s.key&&d.isOpen&&d.render(Y())}async function kt(){let s=n.match;if(!s?.live||!["basketball","football","hockey","tennis"].includes(s.sport))return;let m=n.live.get(s.key);if(m&&(m.pending||Date.now()-m.at<3e4))return;n.live.set(s.key,{...m||{},pending:!0});let e=await et("lz:live",{match:s});n.live.set(s.key,{at:Date.now(),data:e.ok&&e.data&&!e.data.error?e.data:null,error:e.ok?e.data?.error||"":e.error||""}),n.match?.key===s.key&&d.isOpen&&d.render(Y())}function Nt(s,m){n.fonbetRef.set(s,null),et("lz:fonbet-ref",{match:m}).then(e=>{n.fonbetRef.set(s,e.ok&&e.data?.odds?e.data:null),e.ok&&e.data?.odds&&n.match?.key===s&&d.isOpen&&d.render(Y())}).catch(()=>{})}function Tt(s,m,e){let o=n.match,l=`${s}|${[m.best,...m.others].filter(Boolean).map(b=>`${b.label}:${b.odd}`).join(",")}`;if(n.verdictSent===l)return;n.verdictSent=l;let f=[m.best,...m.others].filter(Boolean).map(b=>({label:b.label,odd:b.odd,p:b.p,kind:b.kind||"win",side:b.side||"",line:b.line??null}));et("lz:verdict",{payload:{sport:o.sport,league:o.league||"",home:o.home,away:o.away,book:a.name,source:e,options:f}}).then(b=>{b?.ok&&b.data?.track&&b.data.track!==n.verdictTrack&&(n.verdictTrack=b.data.track,d.isOpen&&d.render(Y()))}).catch(()=>{})}function oe(s){let m=n.match,e=s&&P();if(!m||!e||m.live)return null;let o=n.consensus.get(s),l=n.model.get(s),f=n.analysis.get(s)?.result,b=[m.home,m.away],x=[],k="",y=e.rows;if(o?.consensus?.length===y.length)y.forEach((_,E)=>x.push({label:_.name,odd:_.odd,p:o.consensus[E],side:y.length===3?["home","draw","away"][E]:["home","away"][E]})),k=`консенсус ${o.count} контор`;else if(!o?.consensus&&l?.sport==="hockey"&&l.regulation&&y.length===3){let _=[l.regulation.p1,l.regulation.px,l.regulation.p2];y.forEach((E,R)=>x.push({label:E.name,odd:E.odd,p:_[R],side:["home","draw","away"][R]})),k="модель Линзы"}else{let _=y.length===2?y:m.sport==="mma"&&y.length===3?[y[0],y[2]]:e.overtime?.rows||null,E=o?.consensus?.length===2?o.consensus:l?.p1?[l.p1,l.p2]:null;_&&E&&(_.forEach((R,U)=>x.push({label:b[U],odd:R.odd,p:E[U],side:["home","away"][U]})),k=o?.consensus?.length===2?`консенсус ${o.count} контор`:"модель Линзы")}let z=l?.sport==="mma"?l.durations:null;if(z)for(let _ of n.markets){if(_.scope==="list"||_.kind!=="total"||_.outcomes.length!==2)continue;let E=String(_.line||"").replace(",","."),R=E==="1.5"?z.r1+z.r2/2:E==="2.5"&&z.rounds===3?z.r1+z.r2+z.r3/2:null,U=Bt(_.outcomes.map(rt=>rt.label));R==null||U<0||x.some(rt=>rt.kind==="total"&&rt.line===E)||(x.push({label:`Больше ${E} раунда`,odd:_.outcomes[U].odd,p:1-R,kind:"total",line:E}),x.push({label:`Меньше ${E} раунда`,odd:_.outcomes[1-U].odd,p:R,kind:"total",line:E}))}if(l?.sport==="basketball"&&l.lines){let _=At=>{let lt=String(At||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return lt?Number(lt[0]):NaN},E=At=>n.markets.filter(lt=>lt.scope!=="list"&&lt.main&&lt.kind===At&&lt.outcomes.length===2&&lt.outcomes.every(Gt=>Gt.odd>1)).sort((lt,Gt)=>Math.abs(lt.outcomes[0].odd-lt.outcomes[1].odd)-Math.abs(Gt.outcomes[0].odd-Gt.outcomes[1].odd))[0]||null,R=E("handicap"),U=E("total"),rt=R?_(R.outcomes[0].label):NaN;R&&!Number.isFinite(rt)&&(rt=_(R.line));let pt=U?_(U.line):NaN;U&&!Number.isFinite(pt)&&(pt=_(U.outcomes[0].label));let ue=U?Bt(U.outcomes.map(At=>At.label)):-1;x.push(...fn(l,{handicap:R&&Number.isFinite(rt)?{line:rt,home:R.outcomes[0].odd,away:R.outcomes[1].odd}:null,total:U&&ue>=0&&Number.isFinite(pt)?{line:pt,over:U.outcomes[ue].odd,under:U.outcomes[1-ue].odd}:null},b))}if((m.sport==="football"||m.sport==="hockey")&&a.id!=="fonbet"){let _=n.fonbetRef.get(s);_===void 0?Nt(s,m):_&&x.push(...yn(_,n.markets.filter(E=>E.scope!=="list"),m.sport,b))}if(!x.length)return null;let N=[...x].sort((_,E)=>E.p*E.odd-_.p*_.odd)[0]?.side,F=(f?.factors||[]).filter(_=>N&&_.side===N).slice(0,2).map(_=>_.text),S=pn(x,{source:k,reasons:F,risk:f?.risks?.[0]||""});return S&&Tt(s,S,k),S&&{...S,track:n.verdictTrack||""}}function re(s,m,e){let o=(x,k)=>m?[k,x]:[x,k],f=P()?.rows||[],b=f.length===2&&f.every(x=>Number.isFinite(x.fair))?f.map(x=>x.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:o(s.score[0],s.score[1]),sets:s.sets.map(([x,k])=>o(x,k)),games:o(s.games[0],s.games[1]),points:o(s.points[0],s.points[1]),tiebreak:s.tiebreak,serving:s.aServes==null?null:s.aServes!==m?0:1,bestOf:s.bestOf,prior:s.prior,serve:o(s.serve.a,s.serve.b),probs:o(s.p1,s.p2),set:o(s.set.p1,1-s.set.p1),game:o(s.game.p1,1-s.game.p1),book:b,compare:s.prior.source==="line"||s.prior.source==="model",at:e}}function ae(s,m,e){let o=(k,y)=>m?[y,k]:[k,y],l=k=>m?[k[2],k[1],k[0]]:k,b=P()?.rows||[],x=b.length===3&&b.every(k=>Number.isFinite(k.fair))?b.map(k=>k.fair):null;return{kind:"goals",sport:s.sport,names:[n.match.home,n.match.away],score:o(s.score[0],s.score[1]),red:o(s.red[0],s.red[1]),minute:s.minute,period:s.period,periods:s.periods,clock:s.clock,prior:s.prior,probs:l([s.p1,s.px,s.p2]),book:x,compare:s.prior.source==="line",expTotal:s.expTotal,nextGoal:l([s.nextGoal.home,s.nextGoal.none,s.nextGoal.away]),total:s.tables.total,handicap:s.tables.handicap.map(k=>m?{line:-k.line,home:k.away,away:k.home}:k).sort((k,y)=>k.line-y.line),bookLines:s.bookLines,at:e}}function se(s){let m=s&&n.live.get(s);if(!m?.data)return m?.error?{error:m.error}:null;let e=m.data,o=!!e.flipped;if(e.kind==="goals")return ae(e,o,m.at);if(e.kind==="tennis")return re(e,o,m.at);let l=(y,z)=>o?[z,y]:[y,z],f=P(),b=f?.overtime?.rows||f?.rows||[],x=b.length===2?b.map(y=>y.fair):b.length===3&&b.every(y=>Number.isFinite(y.fair))?[b[0].fair+b[1].fair/2,b[2].fair+b[1].fair/2]:null,k=e.tables||{};return{names:[n.match.home,n.match.away],score:l(e.score[0],e.score[1]),periods:(e.periods||[]).map(([y,z])=>l(y,z)),period:e.period,elapsed:e.elapsed,left:e.left,clock:e.clock,format:e.format,probs:l(e.p1,e.p2),book:x,prior:e.prior,expMargin:o?-e.expMargin:e.expMargin,sd:e.sd,projTotal:e.projTotal,sdTotal:e.sdTotal,handicap:(k.handicap||[]).map(y=>o?{line:-y.line,home:y.away,away:y.home}:y).sort((y,z)=>y.line-z.line),total:k.total||[],quarterTotal:k.quarterTotal||[],bookLines:e.bookLines?{handicap:e.bookLines.handicap?o?{...e.bookLines.handicap,line:-e.bookLines.handicap.line,odds:[...e.bookLines.handicap.odds].reverse(),fair:[...e.bookLines.handicap.fair].reverse(),p:1-e.bookLines.handicap.p,book:1-e.bookLines.handicap.book,gap:-e.bookLines.handicap.gap}:e.bookLines.handicap:null,total:e.bookLines.total||null}:null,quarter:e.quarter?{...e.quarter,score:l(e.quarter.score[0],e.quarter.score[1]),expMargin:o?-e.quarter.expMargin:e.quarter.expMargin,probs:l(e.quarter.p1,e.quarter.p2)}:null,at:m.at}}async function Pt(){let s=n.match;if(!s||!["cs","dota","tennis","basketball","mma","hockey"].includes(s.sport)||n.model.has(s.key)||s.live&&(s.sport==="tennis"||s.sport==="basketball"||s.sport==="mma"||s.sport==="hockey"))return;n.model.set(s.key,null);let m=await et("lz:model",{match:s});n.model.set(s.key,m.ok&&m.data?.p1?m.data:null),n.match?.key===s.key&&d.isOpen&&d.render(Y())}let It=new Map;async function Rt(){let s=n.match;if(!s||!["football","hockey","basketball","cs","dota"].includes(s.sport))return;let m=s.live&&Date.now()-(It.get(s.key)||0)>60*1e3;if(n.facts.has(s.key)&&!m)return;let e=n.facts.get(s.key)||null;It.set(s.key,Date.now()),n.facts.set(s.key,e);let o=await et("lz:facts",{match:s});n.facts.set(s.key,o.ok&&o.data?.facts?.length?o.data:e),n.match?.key===s.key&&d.isOpen&&d.render(Y())}async function ie(){let s=n.match;if(!s||n.analysis.has(s.key))return;let m=await et("lz:cached",{match:s});!m.ok||!m.data||n.analysis.has(s.key)||(n.analysis.set(s.key,{status:"done",steps:[],result:m.data}),G(),tt())}function le(){return{opened(){it(),G(),ie(),ht(),Pt(),Rt(),kt(),vt(),d.render(Y()),ct()},tab(s){s==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=s||"match",s==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&st(),d.render(Y())},"edges-refresh"(){st(),d.render(Y())},theme(){ut({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ut({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){ut({overlay:s})},"set-theme"(s){ut({theme:s})},async"set-mode"(s){await et("lz:settings",{mode:s}),it()},"copy-code"(s){if(!s)return;let m=()=>d.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(s).then(m,()=>d.toast(`Промокод: ${s}`)):d.toast(`Промокод: ${s}`)},"set-stake"(s,m,e){let o=Math.round(Number(e.getElementById("lz-stake")?.value));if(!Number.isFinite(o)||o<10||o>1e7)return d.toast("Введите сумму от 10 ₽");ut({stake:o}),d.toast("Сумма сохранена")},async"save-key"(s,m,e){let o=e.getElementById("lz-key"),l=(o?.value||"").trim();if(l.length<8)return d.toast("Вставьте ключ целиком");let f=await et("lz:settings",{apiKey:l});d.toast(f.ok?"Ключ сохранён":f.error),o&&(o.value=""),it()},async"clear-key"(){await et("lz:settings",{apiKey:""}),d.toast("Ключ удалён"),it()},async"save-license"(s,m,e){let o=e.getElementById("lz-license"),l=(o?.value||"").trim();if(l.length<6)return d.toast("Вставьте ключ целиком");let f=await et("lz:settings",{licenseKey:l});d.toast(f.ok?"Ключ принят":f.error),o&&(o.value=""),it()},async"clear-license"(){await et("lz:settings",{licenseKey:""}),d.toast("Ключ удалён"),it()},savePosition(s,m){n.positions[s]=m,ye(["lz.positions"]).then(e=>{let o=e["lz.positions"]||{};o[location.hostname]=n.positions,yt({"lz.positions":o})})},async analyze(){if(!n.match)return;let s=n.match.key,m={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(s,m),tt();let e=await et("lz:analyze",{..._t(),force:!0});e.ok?n.analysis.set(s,{status:"done",steps:m.steps,result:e.data}):n.analysis.set(s,{status:"error",steps:m.steps,error:e.error,needKey:e.code==="no-access"}),it(),G(),d.render(Y())},async compare(){if(!n.match)return;let s=n.match.key;n.compare.set(s,{status:"loading"}),tt();let m=await et("lz:compare",_t());n.compare.set(s,m.ok?{status:"done",...m.data}:{status:"done",rows:[],labels:[],note:m.error}),m.ok&&sn(n.margins,s,m.data.rows)&&D(),tt()},"whatsnew-ok"(){n.whatsnew=null,yt({"lz.whatsnew":null}),tt()},"pick-clear"(){n.selected=null,M(),tt()},"leg-add"(){let s=W(),m=O();!s?.canAdd||!m||(n.express.push({id:`${m.market.id}#${m.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),yt({"lz.express":n.express}),d.toast("Добавлено в расчёт экспресса"),tt())},"leg-remove"(s){n.express=n.express.filter(m=>m.id!==s),yt({"lz.express":n.express}),tt()},"leg-clear"(){n.express=[],yt({"lz.express":n.express}),tt()},"scan-go"(s){let m=n.markets[Number(s)],e=m?.outcomes[0]?.el;e?.isConnected&&(e.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:m.id,index:0},setTimeout(M,400))}}}function Dt(s){let m=s.composedPath();for(let e=0;e<Math.min(m.length,6);e+=1){let o=m[e]instanceof Element?p.get(m[e]):null;if(o&&o.market.outcomes[o.index]?.el===m[e])return o}return null}let Ft=new Map;function ce(s){if(!s.event||!s.main||!["1x2","12"].includes(s.kind)||s.scope!=="list"||s.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!s.event,main:s.main,kind:s.kind,scope:s.scope,live:s.event?.live})),null;let m=s.event.key;if(Ft.has(m))return Ft.get(m);let e={home:s.event.home,away:s.event.away,sport:de(s),league:s.event.league||""},o=et("lz:consensus",{match:e,size:s.outcomes.length}).then(l=>((!l.ok||!l.data?.consensus)&&console.debug("[lz] рынок для списка:",l.error||l.data?.error||"нет данных"),l.ok&&l.data?.consensus?l.data:null)).catch(l=>(console.debug("[lz] рынок для списка:",String(l?.message||l)),null));return Ft.set(m,o),o.then(l=>Ft.set(m,l)),o}let de=s=>s.event?.sport||n.match?.sport||Lt(location.pathname,document.title,s.event?.league);function Ot({market:s,index:m},e=null){let o=h(s),l=$(s),f=s.event?`${s.event.home} — ${s.event.away}`:"",b=s.outcomes.map((y,z)=>{let N=o.fair?o.fair[z]:1/y.odd;return t(`div.tip-row${z===m?".hot":""}`,{},t("span",{text:v(s,z)}),t("span.odd",{text:Z(y.odd)}),t("span.pct",{text:bt(N,N<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(N*100)}%`})))}),x=o.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:bt(o.margin,1)}),l?t("span",{}," · модель: ",t("b",{text:bt(l[m],1)})):null),k=null;if(e?.consensus){let y=e.consensus.length===s.outcomes.length,z=!y&&e.consensus.length===2&&s.outcomes.length===3;if(y||z){let N=y?e.consensus[m]:null,F=N?s.outcomes[m].odd*N-1:0;k=t("div.tip-foot",{},`Рынок, ${e.count} контор${z?", с овертаймом":""}: `,t("b",{text:e.consensus.map(S=>bt(S,0)).join(" / ")}),F>.005?t("span.pos",{text:` · кэф выше рынка на ${(F*100).toFixed(1)}%`}):null)}}else e===void 0&&(k=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),f?t("div.tip-sub",{text:f}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),b.slice(0,8),x,k)}let wt=0,$t=null;ne.on("page:pointerover",s=>{if(n.settings.overlay==="off")return;let m=Dt(s),e=m?m.market.outcomes[m.index].el:null;if(e!==$t){if($t=e,clearTimeout(wt),!m)return c.hideTip();wt=setTimeout(()=>{if($t!==e||!e.isConnected)return;c.setAvoid(d.rect());let o=ce(m.market);c.showTip(e,Ot(m,o instanceof Promise?void 0:o)),o instanceof Promise&&o.then(l=>{$t===e&&e.isConnected&&c.showTip(e,Ot(m,l))})},280)}}),ne.on("page:click",s=>{let m=Dt(s);m&&(n.selected={id:m.market.id,index:m.index},n.tab==="scan"&&(n.tab="match"),M(),tt())}),on(s=>{if(s.type!=="lz:progress")return;let m=n.analysis.get(s.key);!m||m.status!=="loading"||(m.steps=[...m.steps,s.text].slice(-7),tt())});let Ut=()=>{G(),new MutationObserver(B).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||G()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&G()},600),setInterval(()=>{!document.hidden&&d.isOpen&&B()},4e3),xt()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(n.settings={...pe,...s["lz.settings"].newValue||{}},G())}),it()};document.body?Ut():document.addEventListener("DOMContentLoaded",Ut,{once:!0}),document.documentElement.setAttribute("data-lz",a.id),globalThis.__lz={state:n,view:Y,refresh:G,overlay:c,panel:d}}function ho(r){let a=Date.now()-432e5;return(Array.isArray(r)?r:[]).filter(i=>i&&i.at>a&&i.odd>1)}})();
