(()=>{var wt=r=>typeof r=="string"?r:"",Bt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:wt("https://efremen512218-lang.github.io/linza/"),telegram:wt("https://t.me/linza_odds"),bot:wt("https://t.me/linza_keys_bot")},Ie=wt("https://185-72-145-3.sslip.io"),pe={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var fe=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Ft(r){let a=String(r||"").toLowerCase();return fe.find(i=>i.hosts.some(n=>a===n||a.endsWith(`.${n}`)))||null}var St={overlay:"picks",theme:"auto",mode:"own",model:pe.model},Rt={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function nt(r){let a=String(r??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(a))return null;let i=parseFloat(a.replace(",","."));return i>=1.001&&i<=1e3?i:null}var Pt=r=>r.reduce((a,i)=>a+1/i,0);function Tt(r){let a=(r||[]).filter(n=>Number.isFinite(n)&&n>1);if(a.length<2||a.length!==(r||[]).length)return{kind:"partial",margin:null,fair:null};let i=Pt(a);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:a.map(n=>1/n/i)};if(a.length===3&&i>=1.97&&i<=2.4){let n=i/2;return{kind:"double",margin:n-1,fair:a.map(p=>Math.min(.995,1/p/n))}}return{kind:"partial",margin:null,fair:null}}function jt(r){let a=(r||[]).map(m=>m||[]).filter(m=>m.length),i=a.flat().filter(Boolean);if(i.length<2)return{sets:[],rest:i};let n=m=>m.length>=2&&m.every(Boolean)&&Tt(m.map(b=>b.odd)).kind!=="partial",p=m=>{let b=m.filter(v=>v.some(Boolean));if(!b.length)return null;let y=b.filter(n);if(y.length/b.length<.6)return null;let k=new Set(y.flat());return{sets:y,rest:i.filter(v=>!k.has(v))}},f=m=>{let b=[];for(let y=0;y<a.length;y+=m)b.push(a.slice(y,y+m).flat());return b},d=()=>{let m=[];for(let b=0;b+1<a.length;b+=2){let y=Math.max(a[b].length,a[b+1].length);for(let k=0;k<y;k+=1)m.push([a[b][k]??null,a[b+1][k]??null])}return m},u=[()=>f(1)];a.length>=2&&a.length%2===0&&u.push(d,()=>f(2)),a.length>=3&&a.length%3===0&&u.push(()=>f(3)),a.length>1&&u.push(()=>[a.flat()]);for(let m of u){let b=p(m());if(b)return b}return{sets:[],rest:i}}function Dt(r,a=1.13){let i=u=>{let m=Pt(u.map(b=>b.odd));return m>=.995&&m<=a?!0:u.length===3&&m>=1.99&&m<=a*2},n=u=>Math.abs(u*4-Math.round(u*4))<1e-9,p=[],f=[],d=0;for(;d<r.length;){let u=r.slice(d,d+3),m=r.slice(d,d+2);u.length===3&&i(u)?(p.push(u),d+=3):m.length===2&&i(m)?(p.push(m),d+=2):r[d+2]&&n(r[d+1].odd)&&i([r[d],r[d+2]])?(p.push([r[d],r[d+2]]),f.push(r[d+1]),d+=3):(f.push(r[d]),d+=1)}return{sets:p,rest:f}}function It(r){let a=(r||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!a.length)return null;let i=a.reduce((p,f)=>p*f.odd,1),n=a.reduce((p,f)=>p*f.fair,1);return{legs:a.length,odd:i,chance:n,fairOdd:1/n,margin:1-i*n}}function Wt(r,a){return r*a-1}function I(r){return Number.isFinite(r)?r>=100?r.toFixed(0):r>=10?r.toFixed(1):r.toFixed(2):"—"}function ot(r,a=0){if(!Number.isFinite(r))return"—";let i=r*100;return i>0&&i<1&&a===0?"<1%":`${i.toFixed(a)}%`}function Lt(r){return String(r??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zа-я0-9]/g,"")}var me=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Zt(r){return String(r??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").split(/[^a-zа-я0-9]+/).filter(a=>a.length>=2&&!me.has(a))}function bt(r,a){let i=Lt(r),n=Lt(a);if(i.length<2||n.length<2)return 0;if(i===n)return 1;let p=i.length<=n.length?i:n,f=p===i?n:i;if(p.length>=4&&f.includes(p))return .85;let d=Zt(r),u=Zt(a);if(d.length&&u.length){let y=d.filter(k=>u.some(v=>v===k||k.length>=5&&v.startsWith(k.slice(0,5)))).length/Math.max(d.length,u.length);if(y>=.5)return .6+.3*y}let m=0;for(;m<i.length&&m<n.length&&i[m]===n[m];)m+=1;return m>=5?Math.min(.8,.45+m*.04):0}function he(r){let a=String(r??"").toLowerCase(),i=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(a)&&i.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(a)&&i.push("women"),/\(рез|\(р\)|резерв|reserve/.test(a)&&i.push("reserve"),/люб/.test(a)&&i.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(a)&&i.push("cyber"),i.join("+")}function ct(r,a){let i=f=>{let d=Lt(f),u=he(f);return d.length<2?"":u?`${d}~${u}`:d},n=i(r),p=i(a);return!n||!p?"":[n,p].sort().join("|")}var M=r=>(r?.textContent||"").replace(/[ \s]+/g," ").trim(),Ct=r=>r.offsetParent===null&&r.tagName!=="BODY";function ge(r){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(r||"").trim())}function xt(r,a){let i=String(r||"").toLowerCase();return/двойной шанс/.test(i)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(i)?"other":/фор[аы]|гандикап/.test(i)?"handicap":/тотал/.test(i)?"total":/обе забьют/.test(i)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(i)?a===3?"1x2":a===2?"12":"other":"other"}var be=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function ft(...r){let a=r.filter(Boolean).join(" ");for(let[i,n]of be)if(i.test(a))return n;return""}function Nt(r){if(!r)return null;let a=nt(M(r));if(a)return a;let i=M(r).split(" ");return nt(i[i.length-1])}var xe=0;function dt({scope:r,title:a,period:i="",line:n="",kind:p,outcomes:f,event:d=null,anchor:u=null,eventKey:m=""}){let b=f.length;return{id:`${r}|${m}|${a}|${i}|${n}|${f.map(y=>y.label).join("/")}`,serial:xe+=1,scope:r,title:a,period:i,line:n,kind:p||xt(a,b),main:ge(i),outcomes:f,event:d,anchor:u||f[0]?.el||null}}var B=(r,a)=>[...r.querySelectorAll(a)];function Ht(r){return(String(r||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function At(r){return r.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":r.querySelector(".card")?"list":"other"}var Kt={win:"В",loose:"П",lose:"П",draw:"Н"};function Vt(r){return B(r,".competitor-form__value").map(a=>Kt[[...a.classList].find(i=>Kt[i])]||M(a).slice(0,1)).filter(Boolean).join("")}function ye(r){let a=r.querySelector(".marketbook-header--live");if(a){let n=B(a,".game-scoring__item").map(d=>M(d)),p=B(a,".game-periods .period").map(d=>{let u=B(d,"span");return{label:M(d.querySelector("i")),home:M(u[0]),away:M(u[1])}}).filter(d=>d.home!==""&&d.away!==""),f=B(a,".game-specials > div").map(d=>{let u=B(d,"span"),m=d.querySelector("i"),b=m?.classList.contains("yellow-card")?"жёлтые":m?.classList.contains("red-card")?"красные":m?.classList.contains("penalty-card")?"угловые":"";return b?{kind:b,home:M(u[0]),away:M(u[1])}:null}).filter(Boolean);return{state:M(a.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:p,extras:f}}let i=r.querySelector(".match-card");if(i&&!i.querySelector(".match-card__timer--prematch")){let n=M(i.querySelector(".match-card__main-score")).replace(/\s/g,""),p=B(i,".match-card__score").map(d=>M(d)).filter(d=>/^\d{1,2}$/.test(d)),f=B(r,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(d=>M(d)).filter(d=>/\d\s*:\s*\d/.test(d)).slice(0,5);return{state:M(i.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:f.map((d,u)=>({label:`${u+1} карта`,raw:d})),extras:[]}}return null}function Ut(r,a){if(At(r)!=="match")return null;let i=B(r,".breadcrumbs .breadcrumbs__item").map(b=>M(b)).filter(Boolean),n=M(r.querySelector(".event-breadcrumbs")),p=B(r,".marketbook-header--prematch .competitor-name").map(b=>M(b));if(p.length<2&&(p=B(r,".marketbook-header--live .competitors-desc__name").map(b=>M(b))),p.length<2&&(p=B(r,".match-card .match-card__team-name").map(b=>M(b))),p.length<2||!p[0]||!p[1])return null;let f=ft(i[1]&&/киберспорт/i.test(i[0])?i[1]:"",i[0],n),d=/киберспорт/i.test(i[0]||"")?i.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():i.slice(1).join(", "),u=[M(r.querySelector(".prematch-date")),M(r.querySelector(".prematch-time"))].filter(Boolean).join(" ")||M(r.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),m=ye(r);return{book:"Winline",id:Ht(a?.pathname),key:ct(p[0],p[1]),home:p[0],away:p[1],sport:f,league:d,start:m?"":u,live:m,form:{home:Vt(r.querySelector(".competitor-form--left")||r.createElement("div")),away:Vt(r.querySelector(".competitor-form--right")||r.createElement("div"))},stats:_e(Me(r),p[0],p[1]),url:a?.href||""}}function ve(r,a){let i=[];for(let n of B(r,".bet-line")){if(Ct(n))continue;let p=M(n.querySelector(".bet-line__market-name")),f=M(n.querySelector(".bet-line__period")),d=B(n,".odd-btn"),u=d.map((b,y)=>{let k=M(b.querySelector(".odd-btn__label")),v=B(b,"span").map(z=>nt(M(z))).find(Boolean)||null;return v?{el:b,odd:v,label:k||Ot(d.length,y,p),locked:!1}:null});if(u.length<2||u.some(b=>!b))continue;let m=M(n.querySelector(".coef-btn")).replace(/\s+/g," ");i.push(dt({scope:"top",title:p,period:f,line:m,outcomes:u,anchor:n,eventKey:a}))}return i}function Ot(r,a,i){return/тотал/i.test(i)?["Меньше","Больше"][a]||"":r===3?["П1","Х","П2"][a]:r===2?["1","2"][a]:String(a+1)}function we(r,a){let i=[];for(let n of B(r,".market")){let p=B(n,".market__row");if(!p.length)continue;let f=M(n.querySelector(".market-title")),d=p.map(m=>{let b=M(m.querySelector(".market__row-text"));return B(m,".market-row-btn").map(y=>{let k=nt(M(y.querySelector(".market-row-btn__coef")));if(!k||y.hasAttribute("disabled"))return null;let v=y.getAttribute("title")||M(y.querySelector(".market-row-btn__text"));return{el:y,odd:k,label:v.replace(/\s+/g," ").trim(),rowLabel:b,locked:!1}})}),{sets:u}=jt(d);for(let m of u){let b=[...new Set(m.map(z=>z.rowLabel).filter(Boolean))],y=b.length<=1,k=y?"":(m[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=m.map(z=>({el:z.el,odd:z.odd,label:y?z.label:z.rowLabel||z.label,locked:!1}));i.push(dt({scope:"board",title:f,period:y&&b[0]||"",line:k,kind:xt(f,v.length),outcomes:v,anchor:n,eventKey:a}))}}return i}var ke=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function ze(r){let a=B(r,".card__competitors .name .name, .half__names .name").map(n=>M(n));if(a.length<2)return null;let i=r.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Ht(i),key:ct(a[0],a[1]),home:a[0],away:a[1],href:i,live:/card--live/.test(r.className)||!!r.querySelector(".card__body-live"),time:M(r.querySelector(".header-left__time, .footer__time")),league:M(r.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:r}}function Xt(r){let a=[];for(let i of B(r,".card")){if(Ct(i))continue;let n=ze(i);if(n){for(let p of B(i,".card__body")){let f=M(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let d of B(p,".card__market")){let u=B(d,".coefficient-button");if(u.length<2)continue;let m=(ke.find(([y])=>y.test(u[0].className))||[])[1]||"other",b=u.map((y,k)=>{let v=/--is-blank/.test(y.className)?null:Nt(y);return v?{el:y,odd:v,label:m==="total"?["Меньше","Больше"][k]:Ot(u.length,k,""),locked:/coefficient-button_locked/.test(y.className)}:null});b.some(y=>!y)||a.push(dt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[m]||"Рынок",period:/^матч$/i.test(f)?"":f,line:M(d.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:m,outcomes:b,event:n,anchor:i,eventKey:n.key}))}}for(let p of B(i,".half__coef-buttons")){let f=B(p,".coef-buttons__button"),d=f.map((u,m)=>{let b=Nt(u.querySelector(".button__coef-title")||u);return b?{el:u,odd:b,label:Ot(f.length,m,""),locked:!1}:null});d.length<2||d.some(u=>!u)||a.push(dt({scope:"list",title:d.length===3?"Исход":"Победитель",kind:d.length===3?"1x2":"12",outcomes:d,event:n,anchor:i,eventKey:n.key}))}}}return a}function $e(r){if(!r?.body)return null;let a=m=>/^\d{1,3}\s?%$/.test(m),i=B(r,"h4").map(m=>{let b=[...m.nextElementSibling?.children||[]],y=M(b[0]),k=M(b[b.length-1]);return a(y)&&a(k)?{label:M(m),home:y.replace(/\s/g,""),away:k.replace(/\s/g,"")}:null}).filter(Boolean);if(!i.length)return null;let n=(r.body.innerText||r.body.textContent||"").replace(/\s+/g," "),p=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(m=>Number(m[1])),d=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(m=>m[1].replace(/\s/g,""));return{names:M(r.querySelector("h3")).split(/\s+vs\s+/i).map(m=>m.trim()).filter(Boolean),rows:i,samples:p.slice(0,2),form:d.length>=2?{home:d[0],away:d[1]}:null}}function _e(r,a,i){if(!r||r.names.length<2)return r;let n=bt(r.names[0],a)+bt(r.names[1],i);return bt(r.names[0],i)+bt(r.names[1],a)<=n?r:{names:[r.names[1],r.names[0]],rows:r.rows.map(f=>({label:f.label,home:f.away,away:f.home})),samples:r.samples.slice().reverse(),form:r.form?{home:r.form.away,away:r.form.home}:null}}function Me(r){let a=r.querySelector("iframe.stats__iframe");if(!a)return null;try{return $e(a.contentDocument)}catch{return null}}function Se(r){let a=["one","two"].map(f=>r.querySelector(`.event-live-center__team-widget--${f}`));if(!a[0]||!a[1])return null;let i=f=>{let d=f;try{d=f.querySelector("iframe")?.contentDocument?.body||f}catch{d=f}let u=B(d,'[class*="player"]').filter(b=>!B(b,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(b.className)),m=[];for(let b of u){let y=M(b).split(" ").filter(Boolean),k=y.find(z=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(z)&&/[A-Za-z]/.test(z));if(!k||m.some(z=>z.nick===k))continue;let v=y.filter(z=>/^\d{1,3}$/.test(z)).map(Number);m.push({nick:k,numbers:v.slice(0,4)})}return m.slice(0,5)},n=i(a[0]),p=i(a[1]);return n.length<3||p.length<3?null:{home:n,away:p}}var Gt={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:At,readMatch:Ut,readEsportsWidget:Se,observeTargets(r){try{let a=r.querySelector("iframe.stats__iframe")?.contentDocument?.body;return a?[a]:[]}catch{return[]}},collect(r,a){if(At(r)==="match"){let p=Ut(r,a)?.key||"";return[...ve(r,p),...we(r,p),...Xt(r)]}return Xt(r)}};var zt=(r,a)=>{try{return[...r.querySelectorAll(a)]}catch{return[]}};function Yt(r,a){let i=[r];if(a.shadow)for(let n of zt(r,a.shadow))n.shadowRoot&&i.push(n.shadowRoot);return i}var kt=r=>(r.defaultView?.innerWidth||0)>0,Te='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function Le(r){let a=[],i=r.ownerDocument.createTreeWalker(r,4);for(;i.nextNode();){let n=i.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&a.push(...n.split(" ")),a.length>5)return null}return a}function Ce(r,a){if(r.disabled||r.hasAttribute?.("disabled"))return null;let i=a.value&&r.querySelector(a.value)||r,n=Le(i);if(!n||!n.length||n.join(" ").length>28)return null;let p=n[n.length-1];if(!(a.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let f=nt(p);if(!f||f>500||n.slice(0,-1).some(u=>/^\d{1,3}[.,]\d{1,3}$/.test(u)))return null;let d=n.slice(0,-1).join(" ");return!a.outcome&&/[+−]|^-/.test(d)?null:{odd:f,label:d}}function Ne(r,a){let i=[],n=new Set,p=Yt(r,a).flatMap(f=>zt(f,a.outcome||Te));for(let f of p){if(n.has(f)||a.skip&&f.closest(a.skip)||f.closest("#lz-root, #lz-marks"))continue;let d=Ce(f,a);if(d){if(!a.outcome&&kt(r)){let u=f.getBoundingClientRect();if(u.width<26||u.width>320||u.height<16||u.height>90)continue}n.add(f),i.push({el:f,odd:d.odd,label:d.label,locked:!1})}}return a.outcome?i:i.filter(f=>!i.some(d=>d.el!==f.el&&d.el.contains(f.el)))}function Ae(r,a,i){if(a.row)return r.closest(a.row);let n=r.parentElement;for(let p=0;p<6&&n&&n!==n.ownerDocument.body;p+=1){let f=i(n);if(f>=2&&f<=16){if(!kt(n.ownerDocument))return n;let d=n.getBoundingClientRect();if(d.height<=130&&d.width>=120)return n}if(f>16)break;n=n.parentElement}return null}var Qt=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function Oe(r,a){let i=a.length,n=r;for(let y=0;y<7;y+=1){let k=n.parentElement;if(!k||a.some(L=>!k.contains(L.el))||k.querySelectorAll("*").length>400||[...k.querySelectorAll('button, a, td, [role="button"]')].filter(L=>!a.some(C=>C.el===L||C.el.contains(L)||L.contains(C.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(M(L))).length>i)break;n=k}let p=a[0].el,f=[],d=n.ownerDocument.createTreeWalker(n,4);for(;d.nextNode();){let y=d.currentNode;if(p.contains(y))break;let k=y.textContent.replace(/[ \s]+/g," ").trim();k.length<2||k.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(k)||/\d{1,2}:\d{2}|^\d|['′]$/.test(k)||Qt.test(k)||f.push(k)}let u=f.slice(-2),m=f.map(y=>y.split(/\s+[—–-]\s+/)).filter(y=>y.length===2).pop();if(m&&(u=m),u.length<2||u[0]===u[1])return null;let b=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:ct(u[0],u[1]),home:u[0],away:u[1],href:b,live:!1,time:"",league:"",card:n}}function Ee(r,a,i){if(!a.names)return Oe(r,i);let n=a.event&&r.closest(a.event)||r,p=[...new Set(zt(n,a.names).map(u=>M(u)).filter(Boolean))],f=p;if(p.length===1&&(f=p[0].split(/\s+[—–-]\s+/)),f.length<2||!f[0]||!f[1])return null;let d=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:ct(f[0],f[1]),home:f[0],away:f[1],href:d,live:!1,time:"",league:"",card:n}}function qe(r){let i=String(r.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!i)return null;let n=[i[1].trim(),i[2].trim()];return n.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:n}function Jt(r,a={}){function i(v,z){return a.matchUrl&&a.matchUrl.test(z?.pathname||"")||a.matchPage&&v.querySelector(a.matchPage)?"match":"list"}function n(v){let z=v.defaultView;if(!z||!kt(v))return[];let L=[];for(let C of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if(C.children.length)continue;let S=M(C);if(S.length<3||S.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(S)||/\d{1,2}[:.]\d{2}/.test(S)||Qt.test(S))continue;let R=C.getBoundingClientRect();if(!(R.top<60||R.top>450||R.width<30||parseFloat(z.getComputedStyle(C).fontSize)<15)&&(L.includes(S)||L.push(S),L.length===2))break}return L}function p(v,z){if(i(v,z)!=="match")return null;let L=a.matchNames?zt(v,a.matchNames).map(S=>M(S)).filter(Boolean):[];if(L.length===1&&(L=L[0].split(/\s+[—–-]\s+/)),L.length<2&&(L=qe(v)||[]),L.length<2&&(L=n(v)),L.length<2)return null;let C=a.matchLeague?M(v.querySelector(a.matchLeague)):"";return{book:r.name,id:(String(z?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:ct(L[0],L[1]),home:L[0],away:L[1],sport:ft(z?.pathname,C,v.title),league:C,start:"",live:null,form:{home:"",away:""},url:z?.href||""}}function f(v,z){return!v||!z?"":z.startsWith("attr:")?String(v.getAttribute(z.slice(5))||"").trim():M(v.querySelector(z))}function d(v,z){if(!kt(z))return[v];let L=v.map(S=>{let R=S.el.getBoundingClientRect();return{cell:S,top:R.top,left:R.left}}).sort((S,R)=>Math.abs(S.top-R.top)>8?S.top-R.top:S.left-R.left),C=[];for(let S of L){let R=C[C.length-1];R&&Math.abs(R.top-S.top)<=8?R.cells.push(S.cell):C.push({top:S.top,cells:[S.cell]})}return C.map(S=>S.cells)}let u=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],m=v=>(u.find(([z])=>z.test(v.join("/").toLowerCase()))||[])[1]||"other";function b(v,z){let L=i(v,z),C=L==="match"&&a.match?{...a,...a.match}:a;return y(v,z,L,C)}function y(v,z,L,C){let S=Ne(v,C);if(S.length<2)return[];let R=new Set(S.map($=>$.el)),G=$=>{let w=0;for(let T of R)$.contains(T)&&(w+=1);return w},U=new Map;for(let $ of S){let w=Ae($.el,C,G);w&&(U.has(w)||U.set(w,[]),U.get(w).push($))}let tt=L==="match"?p(v,z):null,F=[];for(let[$,w]of U){let T=L==="match"?null:Ee($,C,w),A=C.group?$.closest(C.group):null,N=f(A,C.groupTitle),W=f(A,C.groupPeriod),P=C.visualRows?d(w,v):[w],j=0;for(let X of P)for(let at of Dt(X).sets){let Z=j===0,H=at.length,st=H===3?["П1","Х","П2"]:["1","2"],it=at.map((Q,J)=>({...Q,label:Q.label||st[J]||String(J+1)})),ut=Z&&H===3?"Исход":Z?"Победитель":`Рынок ${j+1}`,et=Z?H===3?"1x2":"12":"other";N&&(ut=N,et=xt(N,H),et==="other"&&(et=m(it.map(Q=>Q.label)))),F.push(dt({scope:L==="match"?"board":"list",title:ut,period:W,kind:et,outcomes:it,event:T,anchor:$,eventKey:T?.key||tt?.key||`row${F.length}`})),j+=1}}return F}let k=v=>Yt(v,a).slice(1);return{id:r.id,name:r.name,hosts:r.hosts,generic:!0,pageType:i,readMatch:p,collect:b,observeTargets:k,readEsportsWidget:()=>null}}var te={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]'},ee={fonbet:te,pari:te,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function ne(r){let a=Ft(r);return a?a.id==="winline"?{adapter:Gt,book:a}:{adapter:Jt(a,ee[a.id]||{}),book:a}:null}var $t=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var oe=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(r,a,...i){let[n,...p]=r.split("."),f=document.createElement(n||"div");p.length&&(f.className=p.join(" "));for(let[d,u]of Object.entries(a||{}))if(!(u==null||u===!1))if(d==="class")f.className=[f.className,u].filter(Boolean).join(" ");else if(d==="style")f.style.cssText=u;else if(d==="text")f.textContent=u;else{if(d==="html")throw new Error("html запрещён");d.startsWith("data-")||d.startsWith("aria-")||d==="role"||d==="title"||d==="type"||d==="href"||d==="target"||d==="rel"||d==="placeholder"||d==="value"||d==="for"||d==="name"||d==="maxlength"||d==="autocomplete"||d==="spellcheck"||d==="tabindex"?f.setAttribute(d,u===!0?"":String(u)):d==="disabled"||d==="hidden"||d==="checked"||d==="selected"?f[d]=!!u:f[d]=u}return ae(f,i),f}function ae(r,a){for(let i of a)i==null||i===!1||(Array.isArray(i)?ae(r,i):r.appendChild(i instanceof Node?i:document.createTextNode(String(i))))}var re="http://www.w3.org/2000/svg";function D(r,a=16){let i=document.createElementNS(re,"svg");i.setAttribute("viewBox","0 0 20 20"),i.setAttribute("width",a),i.setAttribute("height",a),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.7"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("aria-hidden","true");for(let n of Re[r]||[]){let p=document.createElementNS(re,"path");p.setAttribute("d",n),i.appendChild(p)}return i}var Re={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function se(){let r=document.createElement("div");r.id="lz-marks",r.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let a=r.attachShadow({mode:"open"});a.appendChild(t("style",{text:$t+oe}));let i=t("div.layer"),n=t("div.tip");a.append(i,n);let p=new Map,f=new Set,d=0,u=null,m=null,b=new IntersectionObserver($=>{for(let w of $)w.isIntersecting?f.add(w.target):(f.delete(w.target),p.get(w.target)?.node.classList.remove("on"));k()},{rootMargin:"120px"});function y(){r.isConnected||document.documentElement.appendChild(r)}function k(){d||(d=requestAnimationFrame(()=>{d=0,L()}))}let v=($,w)=>{for(let T=w;T;T=T.parentNode||T.host)if(T===$)return!0;return!1};function z($,w){let T=w.left+w.width/2,A=w.top+w.height/2;if(T<0||A<0||T>window.innerWidth||A>window.innerHeight)return!1;let N=document.elementFromPoint(T,A);for(;N?.shadowRoot?.elementFromPoint;){let W=N.shadowRoot.elementFromPoint(T,A);if(!W||W===N)break;N=W}return!!N&&N!==$&&!v($,N)&&!v(N,$)}function L(){for(let $ of f){let w=p.get($);if(!w)continue;if(!$.isConnected){C($);continue}let T=$.getBoundingClientRect();if(T.width<6||T.height<6||z($,T)){w.node.classList.remove("on");continue}let A=Math.round(T.left),N=Math.round(T.top),W=Math.round(T.width),P=Math.round(T.height);(w.x!==A||w.y!==N)&&(w.node.style.transform=`translate3d(${A}px, ${N}px, 0)`,w.x=A,w.y=N),(w.w!==W||w.h!==P)&&(w.node.style.width=`${W}px`,w.node.style.height=`${P}px`,w.w=W,w.h=P,w.node.classList.toggle("small",P<26)),w.node.classList.add("on")}u&&R()}function C($){let w=p.get($);w&&(b.unobserve($),f.delete($),w.node.remove(),p.delete($))}function S($){y();let w=new Map;for(let T of $)T.el?.isConnected&&w.set(T.el,T);for(let T of[...p.keys()])w.has(T)||C(T);for(let[T,A]of w){let N=p.get(T);if(!N){let P=t("div.mark"),j=parseFloat(getComputedStyle(T).borderTopLeftRadius);P.style.borderRadius=`${Number.isFinite(j)&&j>0?Math.min(j,16):6}px`;let X=t("span.chip");P.appendChild(X),i.appendChild(P),N={node:P,chip:X,sig:""},p.set(T,N),b.observe(T)}let W=`${A.frame?1:0}|${A.selected?1:0}|${A.tone||""}|${A.chip||""}`;W!==N.sig&&(N.sig=W,N.node.classList.toggle("frame",!!A.frame),N.node.classList.toggle("selected",!!A.selected),N.node.classList.toggle("pos",A.tone==="pos"&&!!A.frame),N.chip.hidden=!A.chip,N.chip.textContent=A.chip||"",N.chip.className=`chip${A.tone&&A.tone!=="accent"?" "+A.tone:""}`)}k()}function R(){if(!u?.isConnected)return U();let $=u.getBoundingClientRect(),w=264,T=n.offsetHeight||140,A=$.left+$.width/2-w/2;A=Math.max(8,Math.min(A,window.innerWidth-w-8)),m&&A+w>m.left-8&&A<m.right&&(A=Math.max(8,m.left-w-10));let N=$.bottom+10;N+T>window.innerHeight-8&&(N=$.top-T-10),N<8&&(N=8),n.style.transform=`translate3d(${Math.round(A)}px, ${Math.round(N)}px, 0)`}function G($,w){y(),u=$,n.replaceChildren(w),R(),n.classList.add("on")}function U(){u=null,n.classList.remove("on")}function tt($){m=$}function F($){r.setAttribute("data-theme",$)}return window.addEventListener("scroll",k,{capture:!0,passive:!0}),window.addEventListener("resize",k,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&k()},700),{set:S,schedule:k,showTip:G,hideTip:U,setTheme:F,setAvoid:tt,get tipTarget(){return u},count:()=>p.size}}var ie=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px 60px;
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-faint);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var K=(r,a=0)=>ot(r,a),yt=r=>`${r>0?"+":r<0?"−":""}${Math.abs(r).toFixed(1)}`;function le({bus:r,actions:a,brand:i}){let n=document.createElement("div");n.id=r.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=n.attachShadow({mode:"open"});p.appendChild(t("style",{text:$t+ie}));let f=t("span.dot"),d=t("button.fab",{type:"button","data-act":"toggle",title:`${i.name}: открыть панель`,"aria-label":`${i.name}: открыть панель`},D("lens",18),t("span",{text:i.name}),f),u=t("div.tabs",{role:"tablist"}),m=t("div.body"),b=t("div.foot"),y=t("small"),k=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),z=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},D("gear")),L=t("div.head",{},t("div.brand",{},t("span.logo",{},D("lens",15)),t("span",{text:i.name}),y),t("span.grow"),v,k,z,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},D("close"))),C=t("section.panel",{hidden:!0,role:"dialog","aria-label":i.name},L,u,m,b);p.append(d,C);let S=()=>{n.isConnected||document.documentElement.appendChild(n)};S(),new MutationObserver(S).observe(document.documentElement,{childList:!0});let R="",G=null,U=new Map,tt=e=>{for(let o of e.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},F=null;r.on("ui:pointerdown",e=>{if(e.button!==0)return;let o=e.composedPath(),l=o.includes(d),c=o.includes(L)&&!o.some(x=>x?.dataset?.act);if(!l&&!c)return;let h=l?d:C,g=h.getBoundingClientRect();F={target:h,key:l?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:g.left,oy:g.top,moved:!1},r.setDragging(!0)}),r.on("drag:move",e=>{if(!F)return;let o=e.clientX-F.sx,l=e.clientY-F.sy;!F.moved&&Math.hypot(o,l)<5||(F.moved=!0,F.target.classList.add("dragging"),w(F.target,F.ox+o,F.oy+l))}),r.on("drag:end",()=>{if(F){if(r.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let e=F.target.getBoundingClientRect();a.savePosition(F.key,{left:e.left,top:e.top}),$=!0,setTimeout(()=>{$=!1},60)}F=null}});let $=!1;function w(e,o,l){let c=e.offsetWidth||120,h=e.offsetHeight||40,g=Math.max(6,Math.min(o,window.innerWidth-c-6)),x=Math.max(6,Math.min(l,window.innerHeight-Math.min(h,60)-6));e.style.left=`${Math.round(g)}px`,e.style.top=`${Math.round(x)}px`,e.style.right="auto"}r.on("ui:click",e=>{if($)return;let o=tt(e);if(!o||o.disabled)return;e.preventDefault();let l=o.dataset.act;if(l==="toggle")return ht();if(l==="close")return lt();let c=a[l];c&&c(o.dataset.arg,o,p)}),r.on("ui:keydown",e=>{if(e.key==="Escape"&&lt(),e.key==="Enter"){let o=e.composedPath()[0];o?.dataset?.enter&&a[o.dataset.enter]?.(o.value,o,p)}});let T=(e,o)=>t("span.form",{},[...String(e||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function A(e){let o=e.live,l=o?t("div.center",{},o.score?.length===2?t("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,t("span.badge.live",{text:o.state||"Лайв"})):t("div.center",{},t("span",{text:e.start||"до матча"})),c=o?.periods?.length?t("div.periods",{text:o.periods.map(g=>g.raw?`${g.label} ${g.raw}`:`${/^\d+$/.test(g.label)?`${g.label}-й отрезок`:g.label} ${g.home}:${g.away}`).join(" · ")}):null,h=o?.extras?.length?t("div.periods",{text:o.extras.map(g=>`${g.kind} ${g.home}:${g.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:e.league||e.sportName||"",title:e.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:e.home,title:e.home}),e.form?.home?T(e.form.home):null),l,t("div.team.away",{},t("b",{text:e.away,title:e.away}),e.form?.away?T(e.form.away):null)),c,h)}function N(e){let o=e.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:e.title}),Number.isFinite(e.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(e.margin,1)}`}):null),e.rows.map(l=>{let c=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:I(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},K(o&&Number.isFinite(l.model)?l.model:l.fair),c!=null&&Math.abs(c)>=.05?t(`small${c>0?".pos":".neg"}`,{text:`${yt(c)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),o?t("span.model",{text:"оценка модели"}):null))}function W(e){let o=e.analysis;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},o.steps.map((x,O)=>t(`div.step${O===o.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:x})))));if(o.status==="error")return t("div.card",{},t("div.note.warn",{},D("alert"),t("span",{text:o.error})),o.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},D("gear"),"Открыть настройки")):null);if(o.status!=="done"||!o.result)return null;let l=o.result,c={home:e.match?.home,away:e.match?.away,draw:"ничья"}[l.lean],h=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,g=new Map((l.facts||[]).map(x=>[x.id,x]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:c?`Данные сдвигают оценку в сторону: ${c}`:h?`Данные слегка склоняют в сторону: ${h.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),h?t("div.note",{style:"margin-bottom:10px"},D("info"),t("span",{text:`Модель предложила сдвиг на ${h.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(x=>t(`li.factor${x.side==="home"?".home":x.side==="away"?".away":""}`,{},t("div",{},t("p",{text:x.text}),t("div.src",{},(x.facts||[]).map(O=>g.get(O)).filter(Boolean).map(O=>t("span.tag",{text:`${O.id} · ${O.source}`,title:O.text}))))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},D("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:U.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(x=>t("li",{},t("b",{text:x.id}),t("span",{},x.text," ",t("em",{text:`— ${x.source}`})))))),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function P(e){let o=e.compare?.consensus||e.analysis?.result?.consensus||e.consensus;if(!o?.consensus||!e.line?.rows?.length)return null;let l=o.consensus.length===2&&e.line.rows.length===3;if(!l&&e.line.rows.length!==o.consensus.length)return null;let c=l?e.line.overtime:null,h=c?c.rows:l?[e.line.rows[0],e.line.rows[2]].map(x=>({...x,odd:null,fair:null})):e.line.rows,g=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${o.count} контор`})),h.map((x,O)=>{let _=o.consensus[O],E=x.odd?x.odd*_-1:0,q=Number.isFinite(x.fair)?(x.fair-_)*100:0;return t("div.prob",{},t("span.name",{text:x.name,title:x.name}),t("span.odd",{text:I(1/_),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(_*100)}%`}),t("u",{style:`left:${Math.round((x.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},K(_),E>.005?t("small.pos",{text:`кэф выше рынка ${yt(E*100)}%`}):Math.abs(q)>=2?t(`small${q>0?".neg":""}`,{text:`${yt(q)} п.п. к рынку`,title:q>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!c?null:t("span.model",{text:c?`шанс по рынку «${c.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l?c?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(I).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(I).join(" / ")}. `:""}Цены ${o.count} контор без маржи${g?`, обновлено в ${g}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}function j(e){let o=e.compare?.model||e.analysis?.result?.model;if(!o?.p1||!e.line?.rows?.length||e.line.rows.length!==2)return null;let l=[o.p1,o.p2],c=o.backtest,h=(c?.calibration||[]).filter(x=>[60,70,80].includes(x.threshold)),g=h.length?`На проверке ${c.test} сыгранных матчей: ${h.map(x=>`при уверенности ≥${x.threshold}% сбывалось ${x.hit}%`).join(", ")}`:c?`На проверке ${c.test} матчей угадано ${Math.round(c.acc*100)}%`:"Точность ещё измеряется";return t("div.card",{},t("div.kicker",{},t("span",{text:"Прогноз модели"}),t("span.badge",{text:`уверенность: ${o.confidence}`})),e.line.rows.map((x,O)=>{let _=l[O],E=Number.isFinite(x.fair)?(_-x.fair)*100:0;return t("div.prob",{},t("span.name",{text:x.name,title:x.name}),t("span.odd",{text:I(1/_),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(_*100)}%`}),t("u",{style:`left:${Math.round((x.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},K(_),Math.abs(E)>=3?t(`small${E>0?".pos":".neg"}`,{text:`${yt(E)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),o.factors?.length?t("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,4).map(x=>t("li",{},t("span",{text:x})))):null,t("div.hint",{style:"margin-top:8px",text:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} карт у менее опытной команды). ${g}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function X(e){if(e.status==="idle")return null;if(e.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let o=e.labels||[];if(!e.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let l=o.map((c,h)=>Math.max(...e.rows.map(g=>g.odds[h]||0)));return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),o.map(c=>t("th",{text:c}))),e.rows.map(c=>t("tr",{},t("td.name",{text:c.name,title:c.sharp?"Цена с мирового рынка, для сравнения":""}),c.odds.map((h,g)=>t(`td${h&&h===l[g]&&e.rows.length>1?".best":""}`,{text:h?I(h):"—"}))))),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null)}function at(e){let o=[],l=(c,h,g)=>o.push(t("dt",{text:c}),t(`dd${g?"."+g:""}`,{text:h}));return Number.isFinite(e.fair)?(l("Шанс по линии без маржи",K(e.fair,1)),l("Кэф без маржи конторы",I(e.fairOdd)),l("Маржа конторы в этом рынке",K(e.margin,1))):l("Заложено в кэфе (с маржой)",K(1/e.odd,1)),Number.isFinite(e.model)&&(l("Оценка модели",K(e.model,1)),l("Ожидание на рубль по модели",`${yt(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&l(`Лучшая цена: ${e.best.name}`,I(e.best.odd),e.best.odd>e.odd?"pos":""),t("div.card.accent",{},t("div.kicker",{},t("span",{text:e.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},D("close",13))),t("div.pick-head",{},t("span.big",{text:I(e.odd)}),t("span.what",{text:e.label,title:e.label})),t("dl.kv",{},o),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},D("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")))}function Z(e){let o=(l,c)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),c.map(h=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:h.nick}),t("span",{style:"color:var(--lz-muted)",text:h.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(e.homeName,e.home),o(e.awayName,e.away)))}function H(e,o){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:o.home}),t("th",{text:o.away})),e.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),e.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function st(e){let o=[];if(e.pick&&o.push(at(e.pick)),!e.match)return o.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(A(e.match)),e.esports&&o.push(Z(e.esports)),e.match.stats?.rows?.length&&o.push(H(e.match.stats,e.match)),e.line&&o.push(N(e.line));let l=P(e);l&&o.push(l);let c=j(e);c&&o.push(c);let h=e.analysis.status==="loading";o.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:h},D("spark"),h?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},D("scale"),"Сравнить цены"))),e.quota&&o.push(t("div.hint.center-text",{text:e.quota}));let g=W(e);g&&o.push(g);let x=X(e.compare);return x&&o.push(x),o}function it(e){let o=e.scan;return o?.rows?.length?[t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),t("span.badge",{text:`средняя маржа ${K(o.average,1)}`})),t("table",{},t("tr",{},t("th",{text:o.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),o.rows.map(l=>t("tr.click",{"data-act":"scan-go","data-arg":String(l.index),title:"Показать на странице"},t("td.name",{},l.name,l.sub?t("span.sub",{text:l.sub}):null),t("td",{},l.fav,t("span.sub",{text:K(l.favPct)})),t(`td${l.low?".best":""}`,{text:K(l.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:o.note}))]:[t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function ut(e){let o=e.express;if(!o.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${o.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},D("trash",13),"Очистить")),o.legs.map(c=>t("div.leg",{},t("div.t",{},t("b",{text:c.label,title:c.label}),t("span",{text:c.title,title:c.title})),t("span.o",{text:I(c.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":c.id,title:"Убрать",style:"width:24px;height:24px"},D("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:I(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:K(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:I(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:K(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function et(e){let o=e.edges||{status:"idle"},l=_=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),_?t("span.badge",{text:_}):null);if(o.status==="loading"&&!o.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[t("div.card",{},l(),t("div.note.warn",{},D("alert"),t("span",{text:o.error})))];let c=o.data;if(!c)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let h=_=>_==null?"—":`${_>=0?"+":"−"}${(Math.abs(_)*100).toFixed(1)}%`,g=_=>new Date(_).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),x=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(c.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(c.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:h(c.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:c.positiveWeek==null?"—":K(c.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),O=(c.signals||[]).map(_=>t("tr",{},t("td.name",{},`${_.home} — ${_.away}`,t("span.sub",{text:`${_.league} · ${g(_.start)}`})),t("td",{},_.label,t("span.sub",{text:_.book})),t("td",{text:I(_.odds)}),t("td",{text:I(1/_.p),title:`Честная цена по ${_.count} конторам`}),t("td.best",{text:`+${(_.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(c.full?"тариф «Макс»":"витрина"),O.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),O):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),c.note?t("div.hint",{style:"margin-top:8px"},c.note," ",i.bot?t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),x]}function Q(e){let o=e.settings,l=(c,h,g)=>t("div.seg",{},g.map(([x,O])=>t(`button${h===x?".on":""}`,{type:"button","data-act":c,"data-arg":x,text:O})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]]))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),i.bot&&!o.licenseMask?[" ",t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function J(e){G=e;let o=JSON.stringify(e);if(o===R)return;R=o;for(let g of m.querySelectorAll("details[data-key]"))U.set(g.dataset.key,g.open);let l=m.scrollTop;y.textContent=e.bookName?`· ${e.bookName}`:"",f.classList.toggle("off",e.settings.overlay==="off"),k.replaceChildren(D(e.theme==="dark"?"sun":"moon")),v.replaceChildren(D(e.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",e.settings.overlay!=="off"),z.classList.toggle("on",e.tab==="settings"),z.dataset.arg=e.tab==="settings"?e.backTab:"settings";let c=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];u.replaceChildren(...c.map(([g,x])=>t(`button.tab${e.tab===g?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":g},x,g==="express"&&e.express.legs.length?t("span.count",{text:String(e.express.legs.length)}):null)));let h=e.tab==="settings"?Q(e):e.tab==="scan"?it(e):e.tab==="express"?ut(e):e.tab==="edges"?et(e):st(e);m.replaceChildren(...h.filter(Boolean)),m.scrollTop=l,b.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function Mt(e){n.setAttribute("data-theme",e)}function vt(){C.hidden=!1,a.opened?.()}function lt(){C.hidden=!0}function ht(){C.hidden?vt():lt()}function pt(e){e?.fab&&w(d,e.fab.left,e.fab.top),e?.panel&&w(C,e.panel.left,e.panel.top)}let gt=0;function s(e){p.querySelector(".toast")?.remove();let o=t("div.toast",{text:e,role:"status"});p.appendChild(o),clearTimeout(gt),gt=setTimeout(()=>o.remove(),2600)}return{render:J,setTheme:Mt,open:vt,close:lt,toggle:ht,restore:pt,toast:s,shadow:p,rect:()=>C.hidden?null:C.getBoundingClientRect(),get isOpen(){return!C.hidden},get view(){return G}}}var ce="Расширение обновилось. Обновите эту вкладку (F5).";function rt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function V(r,a={}){if(!rt())return{ok:!1,error:ce,code:"reload"};try{return await chrome.runtime.sendMessage({type:r,...a})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(i){let n=String(i?.message||i);return/context invalidated|message port closed|receiving end does not exist/i.test(n)||!rt()?{ok:!1,error:ce,code:"reload"}:{ok:!1,error:n}}}function de(r){if(rt())try{chrome.runtime.onMessage.addListener(a=>{r(a)})}catch{}}async function Et(r){if(!rt())return{};try{return await chrome.storage.local.get(r)}catch{return{}}}function mt(r){if(rt())try{chrome.storage.local.set(r)}catch{}}var _t=globalThis.__lzBus,qt=_t&&window.top===window?ne(location.hostname):null;qt&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,je(qt.adapter,qt.book));async function je(r,a){let i=await Et(["lz.settings","lz.positions","lz.express"]),n={settings:{...St,...i["lz.settings"]||{}},positions:(i["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:De(i["lz.express"]),analysis:new Map,compare:new Map,consensus:new Map,edges:{status:"idle",data:null,error:"",at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,f=new WeakMap,d=se(),u=le({bus:_t,brand:Bt,actions:et()});u.restore(n.positions);function m(s){let e=s.outcomes.map(c=>c.odd).join("/"),o=p.get(s);if(o?.sig===e)return o.set;let l=Tt(s.outcomes.map(c=>c.odd));return p.set(s,{sig:e,set:l}),l}function b(){return n.match?n.analysis.get(n.match.key):null}function y(s){let e=b()?.result;if(!e?.model||s.scope==="list"||!n.match||!Object.values(e.shift||{}).some(g=>Math.abs(g)>=.5))return null;let{home:o,draw:l,away:c}=e.model,h=s.outcomes.length;if(s.kind==="1x2"&&s.main&&h===3)return[o,l,c];if(s.kind==="12"&&s.main&&h===2&&l<.005)return[o,c];if(s.kind==="dc"&&s.main&&h===3)return[o+l,o+c,l+c];if(/^победит\s*\(осн\.?\s*время\)$/i.test(s.title)&&h===2){let g=s.period===n.match.home?o:s.period===n.match.away?c:null;if(g!=null)return[g,1-g]}return null}function k(){let s=n.markets.filter(e=>e.scope!=="list"&&e.main&&(e.kind==="1x2"||e.kind==="12"));return s.find(e=>e.scope==="top")||s[0]||null}function v(s,e){let o=s.outcomes[e].label;return s.scope==="list"?!s.event||!s.main?o:s.kind==="1x2"?[s.event.home,"Ничья",s.event.away][e]||o:s.kind==="12"&&[s.event.home,s.event.away][e]||o:n.match?s.kind==="1x2"?[n.match.home,"Ничья",n.match.away][e]||o:s.kind==="12"&&[n.match.home,n.match.away][e]||o:o}function z(){let s=n.settings.overlay,e=[];for(let l of n.markets){if(l.outcomes.forEach((E,q)=>f.set(E.el,{market:l,index:q})),s==="off")continue;let c=m(l);if(c.kind==="partial")continue;let h=y(l),g=h||c.fair,x=0;for(let E=1;E<c.fair.length;E+=1)c.fair[E]>c.fair[x]&&(x=E);let O="accent";if(h){let E=0;for(let q=1;q<h.length;q+=1)h[q]-c.fair[q]>h[E]-c.fair[E]&&(E=q);h[E]-c.fair[E]>=.015&&(x=E,O="pos")}let _=l.scope!=="list"||l.main&&(l.kind==="1x2"||l.kind==="12");l.outcomes.forEach((E,q)=>{let Y=q===x&&_;!Y&&s!=="all"||e.push({el:E.el,frame:Y,chip:ot(g[q]),tone:Y?O:"quiet"})})}let o=L();if(o){let l=e.find(c=>c.el===o.item.el);l?l.selected=!0:e.push({el:o.item.el,frame:!1,selected:!0,chip:null})}d.set(e)}function L(){if(!n.selected)return null;let s=n.markets.find(o=>o.id===n.selected.id),e=s?.outcomes[n.selected.index];return e?.el?.isConnected?{market:s,item:e,index:n.selected.index}:null}function C(){if(n.settings.theme!=="auto")return n.settings.theme;for(let s of[document.body,document.documentElement]){let o=(s?getComputedStyle(s).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!o||o[4]==="0")continue;return(.2126*o[1]+.7152*o[2]+.0722*o[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function S(){location.href!==n.url&&(n.url=location.href,n.selected=null,d.hideTip());let s="other",e=[],o=null;try{s=r.pageType(document,location),e=r.collect(document,location),o=r.readMatch(document,location)}catch(c){console.error("[Линза] страница не прочитана",c)}s!==n.pageType&&(n.pageType=s,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=s==="match"?"match":"scan")),n.markets=e,n.match=o;let l=C();l!==n.theme&&(n.theme=l),d.setTheme(n.theme),u.setTheme(n.theme),z(),st(),U(),u.isOpen&&(it(),u.render(P()))}let R=new Set,G=null;function U(){if(r.observeTargets)for(let s of r.observeTargets(document))R.has(s)||(R.add(s),G=G||new MutationObserver($),G.observe(s,{childList:!0,subtree:!0,characterData:!0}))}let tt=0,F=0;function $(){let s=Date.now();F||(F=s),clearTimeout(tt);let e=s-F>900?0:220;tt=setTimeout(()=>{F=0,!document.hidden&&S()},e)}function w(){let s=k();if(!s)return null;let e=m(s);if(e.kind!=="full")return null;let o=y(s);return{title:"Что заложено в цене",margin:e.margin,rows:s.outcomes.map((l,c)=>({name:v(s,c),odd:l.odd,fair:e.fair[c],model:o?o[c]:null})),overtime:T()}}function T(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let s=n.markets.find(o=>o.scope!=="list"&&o.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|ot/i.test(`${o.title} ${o.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${o.title} ${o.period}`));if(!s)return null;let e=m(s);return e.kind!=="full"?null:{title:[s.title,s.period].filter(Boolean).join(" · "),rows:s.outcomes.map((o,l)=>({name:v(s,l)||[n.match.home,n.match.away][l],odd:o.odd,fair:e.fair[l]}))}}function A(){let s=L();if(!s)return null;let{market:e,item:o,index:l}=s,c=m(e),h=y(e),g=c.fair?c.fair[l]:null,x=e.event?`${e.event.home} — ${e.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",O=n.match?n.compare.get(n.match.key):null,_=null;if(O?.rows?.length&&e.main&&(e.kind==="1x2"||e.kind==="12")&&e.scope!=="list")for(let q of O.rows){let Y=q.odds[l];Y&&(!_||Y>_.odd)&&(_={name:q.name,odd:Y})}let E=`${e.id}#${l}`;return{market:[e.title,e.period,e.line].filter(Boolean).join(" · "),label:[v(e,l),x].filter(Boolean).join(" · "),odd:o.odd,fair:g,margin:c.margin,fairOdd:g?1/g:null,model:h?h[l]:null,ev:h?Wt(h[l],o.odd):null,best:_,canAdd:Number.isFinite(g)&&!n.express.some(q=>q.id===E),inExpress:n.express.some(q=>q.id===E),note:c.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":h?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function N(){let s=[];if(n.pageType==="match"?n.markets.forEach((c,h)=>{if(c.scope==="list")return;let g=m(c);if(g.kind!=="full")return;let x=0;for(let O=1;O<g.fair.length;O+=1)g.fair[O]>g.fair[x]&&(x=O);s.push({index:h,name:c.title,sub:[c.period,c.line].filter(Boolean).join(" · "),margin:g.margin,fav:c.outcomes[x].label,favPct:g.fair[x]})}):n.markets.forEach((c,h)=>{if(!c.event||!c.main||c.kind!=="1x2"&&c.kind!=="12")return;let g=m(c);if(g.kind!=="full")return;let x=0;for(let _=1;_<g.fair.length;_+=1)g.fair[_]>g.fair[x]&&(x=_);let O=c.kind==="1x2"?[c.event.home,"Ничья",c.event.away][x]:[c.event.home,c.event.away][x];s.push({index:h,name:`${c.event.home} — ${c.event.away}`,sub:c.event.league||c.event.time,margin:g.margin,fav:O,favPct:g.fair[x]})}),!s.length)return null;let e=new Set;for(let c=s.length-1;c>=0;c-=1){let h=`${s[c].name}|${s[c].sub}`;e.has(h)?s.splice(c,1):e.add(h)}let o=s.reduce((c,h)=>c+h.margin,0)/s.length;s.sort((c,h)=>c.margin-h.margin);let l=s.slice(0,16);return l.forEach(c=>{c.low=c.margin<=o*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:o,rows:l,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${l.length} из ${s.length}, сначала самые дешёвые.`}}function W(){let s=n.status;return s.ready?s.limit?`Разборов сегодня: ${s.used} из ${s.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function P(){let s=n.match?.key,e=s&&n.analysis.get(s)||{status:"idle",steps:[]},o=s&&n.compare.get(s)||{status:"idle"},l=n.match?.live&&r.readEsportsWidget?r.readEsportsWidget(document):null,c=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:a.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Rt[n.match.sport]||""}:null,esports:l?{...l,homeName:n.match.home,awayName:n.match.away}:null,line:w(),analysis:{status:e.status,steps:e.steps||[],result:e.result||null,error:e.error||"",needKey:!!e.needKey},compare:o,consensus:s&&n.consensus.get(s)||null,pick:A(),scan:n.tab==="scan"?N():null,edges:n.edges,express:{legs:n.express,stats:It(n.express)},quota:W(),settings:{overlay:n.settings.overlay,theme:n.settings.theme,mode:c.mode,proxy:c.proxy,ready:c.ready,hasKey:c.hasKey,keyMask:c.keyMask,licenseMask:c.licenseMask,plan:c.plan==="free"||!c.plan?"":`Тариф «${c.plan==="max"?"Макс":"Про"}»${c.until?` до ${c.until.split("-").reverse().join(".")}`:""}.`,usage:c.limit?`Сегодня разборов: ${c.used} из ${c.limit}.`:""}}}let j=()=>{u.isOpen&&u.render(P())};function X(s){Object.assign(n.settings,s),mt({"lz.settings":n.settings}),S(),u.render(P())}async function at(){n.edges={...n.edges,status:"loading",error:""};let s=await V("lz:edges",{sport:n.match?.sport||""});n.edges=s.ok?{status:"done",data:s.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:s.error,at:Date.now()},j()}async function Z(){let s=await V("lz:status");s.ok&&(n.status=s.data),j()}function H(){let s=k(),e=s?m(s):null;return{book:a.name,match:n.match,market:s&&e?.kind==="full"?{kind:s.kind,labels:s.outcomes.map((o,l)=>v(s,l)),odds:s.outcomes.map(o=>o.odd)}:null}}function st(){if(!n.match||!rt())return;let s=H();if(!s.market)return;let e=`${n.match.key}|${s.market.odds.join("/")}`;e!==st.last&&(st.last=e,V("lz:quote",s))}async function it(){let s=n.match;if(!s||s.live||n.consensus.has(s.key))return;let e=H();if(!e.market?.odds?.length)return;n.consensus.set(s.key,null);let o=await V("lz:consensus",{match:s,size:e.market.odds.length});n.consensus.set(s.key,o.ok&&o.data?.consensus?o.data:null),n.match?.key===s.key&&u.isOpen&&u.render(P())}async function ut(){let s=n.match;if(!s||n.analysis.has(s.key))return;let e=await V("lz:cached",{match:s});!e.ok||!e.data||n.analysis.has(s.key)||(n.analysis.set(s.key,{status:"done",steps:[],result:e.data}),S(),j())}function et(){return{opened(){Z(),S(),ut(),it(),u.render(P())},tab(s){s==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=s||"match",s==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&at(),u.render(P())},"edges-refresh"(){at(),u.render(P())},theme(){X({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){X({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(s){X({overlay:s})},"set-theme"(s){X({theme:s})},async"set-mode"(s){await V("lz:settings",{mode:s}),Z()},async"save-key"(s,e,o){let l=o.getElementById("lz-key"),c=(l?.value||"").trim();if(c.length<8)return u.toast("Вставьте ключ целиком");let h=await V("lz:settings",{apiKey:c});u.toast(h.ok?"Ключ сохранён":h.error),l&&(l.value=""),Z()},async"clear-key"(){await V("lz:settings",{apiKey:""}),u.toast("Ключ удалён"),Z()},async"save-license"(s,e,o){let l=o.getElementById("lz-license"),c=(l?.value||"").trim();if(c.length<6)return u.toast("Вставьте ключ целиком");let h=await V("lz:settings",{licenseKey:c});u.toast(h.ok?"Ключ принят":h.error),l&&(l.value=""),Z()},async"clear-license"(){await V("lz:settings",{licenseKey:""}),u.toast("Ключ удалён"),Z()},savePosition(s,e){n.positions[s]=e,Et(["lz.positions"]).then(o=>{let l=o["lz.positions"]||{};l[location.hostname]=n.positions,mt({"lz.positions":l})})},async analyze(){if(!n.match)return;let s=n.match.key,e={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(s,e),j();let o=await V("lz:analyze",{...H(),force:!0});o.ok?n.analysis.set(s,{status:"done",steps:e.steps,result:o.data}):n.analysis.set(s,{status:"error",steps:e.steps,error:o.error,needKey:o.code==="no-access"}),Z(),S(),u.render(P())},async compare(){if(!n.match)return;let s=n.match.key;n.compare.set(s,{status:"loading"}),j();let e=await V("lz:compare",H());n.compare.set(s,e.ok?{status:"done",...e.data}:{status:"done",rows:[],labels:[],note:e.error}),j()},"pick-clear"(){n.selected=null,z(),j()},"leg-add"(){let s=A(),e=L();!s?.canAdd||!e||(n.express.push({id:`${e.market.id}#${e.index}`,title:s.market,label:s.label,odd:s.odd,fair:s.fair,at:Date.now()}),mt({"lz.express":n.express}),u.toast("Добавлено в расчёт экспресса"),j())},"leg-remove"(s){n.express=n.express.filter(e=>e.id!==s),mt({"lz.express":n.express}),j()},"leg-clear"(){n.express=[],mt({"lz.express":n.express}),j()},"scan-go"(s){let e=n.markets[Number(s)],o=e?.outcomes[0]?.el;o?.isConnected&&(o.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:e.id,index:0},setTimeout(z,400))}}}function Q(s){let e=s.composedPath();for(let o=0;o<Math.min(e.length,6);o+=1){let l=e[o]instanceof Element?f.get(e[o]):null;if(l&&l.market.outcomes[l.index]?.el===e[o])return l}return null}let J=new Map;function Mt(s){if(!s.event||!s.main||!["1x2","12"].includes(s.kind)||s.scope!=="list"||s.event.live)return null;let e=s.event.key;if(J.has(e))return J.get(e);let o={home:s.event.home,away:s.event.away,sport:vt(s),league:s.event.league||""},l=V("lz:consensus",{match:o,size:s.outcomes.length}).then(c=>((!c.ok||!c.data?.consensus)&&console.debug("[lz] рынок для списка:",c.error||c.data?.error||"нет данных"),c.ok&&c.data?.consensus?c.data:null)).catch(c=>(console.debug("[lz] рынок для списка:",String(c?.message||c)),null));return J.set(e,l),l.then(c=>J.set(e,c)),l}let vt=s=>s.event?.sport||n.match?.sport||ft(location.pathname,document.title,s.event?.league);function lt({market:s,index:e},o=null){let l=m(s),c=y(s),h=s.event?`${s.event.home} — ${s.event.away}`:"",g=s.outcomes.map((_,E)=>{let q=l.fair?l.fair[E]:1/_.odd;return t(`div.tip-row${E===e?".hot":""}`,{},t("span",{text:v(s,E)}),t("span.odd",{text:I(_.odd)}),t("span.pct",{text:ot(q,q<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(q*100)}%`})))}),x=l.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:ot(l.margin,1)}),c?t("span",{}," · модель: ",t("b",{text:ot(c[e],1)})):null),O=null;if(o?.consensus){let _=o.consensus.length===s.outcomes.length,E=!_&&o.consensus.length===2&&s.outcomes.length===3;if(_||E){let q=_?o.consensus[e]:null,Y=q?s.outcomes[e].odd*q-1:0;O=t("div.tip-foot",{},`Рынок, ${o.count} контор${E?", с овертаймом":""}: `,t("b",{text:o.consensus.map(ue=>ot(ue,0)).join(" / ")}),Y>.005?t("span.pos",{text:` · кэф выше рынка на ${(Y*100).toFixed(1)}%`}):null)}}else o===void 0&&(O=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[s.title,s.period,s.line].filter(Boolean).join(" · ")}),h?t("div.tip-sub",{text:h}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),g.slice(0,8),x,O)}let ht=0,pt=null;_t.on("page:pointerover",s=>{if(n.settings.overlay==="off")return;let e=Q(s),o=e?e.market.outcomes[e.index].el:null;if(o!==pt){if(pt=o,clearTimeout(ht),!e)return d.hideTip();ht=setTimeout(()=>{if(pt!==o||!o.isConnected)return;d.setAvoid(u.rect());let l=Mt(e.market);d.showTip(o,lt(e,l instanceof Promise?void 0:l)),l instanceof Promise&&l.then(c=>{pt===o&&o.isConnected&&d.showTip(o,lt(e,c))})},280)}}),_t.on("page:click",s=>{let e=Q(s);e&&(n.selected={id:e.market.id,index:e.index},z(),j())}),de(s=>{if(s.type!=="lz:progress")return;let e=n.analysis.get(s.key);!e||e.status!=="loading"||(e.steps=[...e.steps,s.text].slice(-7),j())});let gt=()=>{S(),new MutationObserver($).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||S()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&S()},600),setInterval(()=>{!document.hidden&&u.isOpen&&$()},4e3),rt()&&chrome.storage.onChanged.addListener(s=>{s["lz.settings"]&&(n.settings={...St,...s["lz.settings"].newValue||{}},S())}),Z()};document.body?gt():document.addEventListener("DOMContentLoaded",gt,{once:!0}),document.documentElement.setAttribute("data-lz",a.id),globalThis.__lz={state:n,view:P,refresh:S,overlay:d,panel:u}}function De(r){let a=Date.now()-432e5;return(Array.isArray(r)?r:[]).filter(i=>i&&i.at>a&&i.odd>1)}})();
