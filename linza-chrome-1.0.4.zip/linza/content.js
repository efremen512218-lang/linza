(()=>{var Tt=a=>typeof a=="string"?a:"",Kt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Tt("https://efremen512218-lang.github.io/linza/"),telegram:Tt("https://t.me/linza_odds"),bot:Tt("https://t.me/linza_keys_bot")},Ye=Tt("https://185-72-145-3.sslip.io"),ke={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var we=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Ut(a){let s=String(a||"").toLowerCase();return we.find(i=>i.hosts.some(n=>s===n||s.endsWith(`.${n}`)))||null}var qt={overlay:"picks",theme:"auto",mode:"own",model:ke.model,stake:1e3},Vt={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function dt(a){let s=String(a??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(s))return null;let i=parseFloat(s.replace(",","."));return i>=1.001&&i<=1e3?i:null}var Xt=a=>a.reduce((s,i)=>s+1/i,0);function Ft(a){let s=(a||[]).filter(n=>Number.isFinite(n)&&n>1);if(s.length<2||s.length!==(a||[]).length)return{kind:"partial",margin:null,fair:null};let i=Xt(s);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:s.map(n=>1/n/i)};if(s.length===3&&i>=1.97&&i<=2.4){let n=i/2;return{kind:"double",margin:n-1,fair:s.map(p=>Math.min(.995,1/p/n))}}return{kind:"partial",margin:null,fair:null}}function Ht(a){let s=(a||[]).map(h=>h||[]).filter(h=>h.length),i=s.flat().filter(Boolean);if(i.length<2)return{sets:[],rest:i};let n=h=>h.length>=2&&h.every(Boolean)&&Ft(h.map(b=>b.odd)).kind!=="partial",p=h=>{let b=h.filter(v=>v.some(Boolean));if(!b.length)return null;let y=b.filter(n);if(y.length/b.length<.6)return null;let z=new Set(y.flat());return{sets:y,rest:i.filter(v=>!z.has(v))}},f=h=>{let b=[];for(let y=0;y<s.length;y+=h)b.push(s.slice(y,y+h).flat());return b},d=()=>{let h=[];for(let b=0;b+1<s.length;b+=2){let y=Math.max(s[b].length,s[b+1].length);for(let z=0;z<y;z+=1)h.push([s[b][z]??null,s[b+1][z]??null])}return h},u=[()=>f(1)];s.length>=2&&s.length%2===0&&u.push(d,()=>f(2)),s.length>=3&&s.length%3===0&&u.push(()=>f(3)),s.length>1&&u.push(()=>[s.flat()]);for(let h of u){let b=p(h());if(b)return b}return{sets:[],rest:i}}function Gt(a,s=1.13){let i=u=>{let h=Xt(u.map(b=>b.odd));return h>=.995&&h<=s?!0:u.length===3&&h>=1.99&&h<=s*2},n=u=>Math.abs(u*4-Math.round(u*4))<1e-9,p=[],f=[],d=0;for(;d<a.length;){let u=a.slice(d,d+3),h=a.slice(d,d+2);u.length===3&&i(u)?(p.push(u),d+=3):h.length===2&&i(h)?(p.push(h),d+=2):a[d+2]&&n(a[d+1].odd)&&i([a[d],a[d+2]])?(p.push([a[d],a[d+2]]),f.push(a[d+1]),d+=3):(f.push(a[d]),d+=1)}return{sets:p,rest:f}}function Yt(a){let s=(a||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!s.length)return null;let i=s.reduce((p,f)=>p*f.odd,1),n=s.reduce((p,f)=>p*f.fair,1);return{legs:s.length,odd:i,chance:n,fairOdd:1/n,margin:1-i*n}}function Jt(a,s){return a*s-1}function K(a){return Number.isFinite(a)?a>=100?a.toFixed(0):a>=10?a.toFixed(1):a.toFixed(2):"—"}function ut(a,s=0){if(!Number.isFinite(a))return"—";let i=a*100;return i>0&&i<1&&s===0?"<1%":`${i.toFixed(s)}%`}function Rt(a){return String(a??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zа-я0-9]/g,"")}var ze=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Qt(a){return String(a??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").split(/[^a-zа-я0-9]+/).filter(s=>s.length>=2&&!ze.has(s))}function zt(a,s){let i=Rt(a),n=Rt(s);if(i.length<2||n.length<2)return 0;if(i===n)return 1;let p=i.length<=n.length?i:n,f=p===i?n:i;if(p.length>=4&&f.includes(p))return .85;let d=Qt(a),u=Qt(s);if(d.length&&u.length){let y=d.filter(z=>u.some(v=>v===z||z.length>=5&&v.startsWith(z.slice(0,5)))).length/Math.max(d.length,u.length);if(y>=.5)return .6+.3*y}let h=0;for(;h<i.length&&h<n.length&&i[h]===n[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function $e(a){let s=String(a??"").toLowerCase(),i=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(s)&&i.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(s)&&i.push("women"),/\(рез|\(р\)|резерв|reserve/.test(s)&&i.push("reserve"),/люб/.test(s)&&i.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(s)&&i.push("cyber"),i.join("+")}function mt(a,s){let i=f=>{let d=Rt(f),u=$e(f);return d.length<2?"":u?`${d}~${u}`:d},n=i(a),p=i(s);return!n||!p?"":[n,p].sort().join("|")}var C=a=>(a?.textContent||"").replace(/[ \s]+/g," ").trim(),Pt=a=>a.offsetParent===null&&a.tagName!=="BODY";function _e(a){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(a||"").trim())}function $t(a,s){let i=String(a||"").toLowerCase();return/двойной шанс/.test(i)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(i)?"other":/фор[аы]|гандикап/.test(i)?"handicap":/тотал/.test(i)?"total":/обе забьют/.test(i)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(i)?s===3?"1x2":s===2?"12":"other":"other"}var Me=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function xt(...a){let s=a.filter(Boolean).join(" ");for(let[i,n]of Me)if(i.test(s))return n;return""}function jt(a){if(!a)return null;let s=dt(C(a));if(s)return s;let i=C(a).split(" ");return dt(i[i.length-1])}var Se=0;function ht({scope:a,title:s,period:i="",line:n="",kind:p,outcomes:f,event:d=null,anchor:u=null,eventKey:h=""}){let b=f.length;return{id:`${a}|${h}|${s}|${i}|${n}|${f.map(y=>y.label).join("/")}`,serial:Se+=1,scope:a,title:s,period:i,line:n,kind:p||$t(s,b),main:_e(i),outcomes:f,event:d,anchor:u||f[0]?.el||null}}var q=(a,s)=>[...a.querySelectorAll(s)];function ae(a){return(String(a||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function It(a){return a.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":a.querySelector(".card")?"list":"other"}var te={win:"В",loose:"П",lose:"П",draw:"Н"};function ee(a){return q(a,".competitor-form__value").map(s=>te[[...s.classList].find(i=>te[i])]||C(s).slice(0,1)).filter(Boolean).join("")}function Te(a){let s=a.querySelector(".marketbook-header--live");if(s){let n=q(s,".game-scoring__item").map(d=>C(d)),p=q(s,".game-periods .period").map(d=>{let u=q(d,"span");return{label:C(d.querySelector("i")),home:C(u[0]),away:C(u[1])}}).filter(d=>d.home!==""&&d.away!==""),f=q(s,".game-specials > div").map(d=>{let u=q(d,"span"),h=d.querySelector("i"),b=h?.classList.contains("yellow-card")?"жёлтые":h?.classList.contains("red-card")?"красные":h?.classList.contains("penalty-card")?"угловые":"";return b?{kind:b,home:C(u[0]),away:C(u[1])}:null}).filter(Boolean);return{state:C(s.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:p,extras:f}}let i=a.querySelector(".match-card");if(i&&!i.querySelector(".match-card__timer--prematch")){let n=C(i.querySelector(".match-card__main-score")).replace(/\s/g,""),p=q(i,".match-card__score").map(d=>C(d)).filter(d=>/^\d{1,2}$/.test(d)),f=q(a,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(d=>C(d)).filter(d=>/\d\s*:\s*\d/.test(d)).slice(0,5);return{state:C(i.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:f.map((d,u)=>({label:`${u+1} карта`,raw:d})),extras:[]}}return null}function ne(a,s){if(It(a)!=="match")return null;let i=q(a,".breadcrumbs .breadcrumbs__item").map(b=>C(b)).filter(Boolean),n=C(a.querySelector(".event-breadcrumbs")),p=q(a,".marketbook-header--prematch .competitor-name").map(b=>C(b));if(p.length<2&&(p=q(a,".marketbook-header--live .competitors-desc__name").map(b=>C(b))),p.length<2&&(p=q(a,".match-card .match-card__team-name").map(b=>C(b))),p.length<2||!p[0]||!p[1])return null;let f=xt(i[1]&&/киберспорт/i.test(i[0])?i[1]:"",i[0],n),d=/киберспорт/i.test(i[0]||"")?i.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():i.slice(1).join(", "),u=[C(a.querySelector(".prematch-date")),C(a.querySelector(".prematch-time"))].filter(Boolean).join(" ")||C(a.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),h=Te(a);return{book:"Winline",id:ae(s?.pathname),key:mt(p[0],p[1]),home:p[0],away:p[1],sport:f,league:d,start:h?"":u,live:h,form:{home:ee(a.querySelector(".competitor-form--left")||a.createElement("div")),away:ee(a.querySelector(".competitor-form--right")||a.createElement("div"))},stats:Ee(Be(a),p[0],p[1]),url:s?.href||""}}function Ce(a,s){let i=[];for(let n of q(a,".bet-line")){if(Pt(n))continue;let p=C(n.querySelector(".bet-line__market-name")),f=C(n.querySelector(".bet-line__period")),d=q(n,".odd-btn"),u=d.map((b,y)=>{let z=C(b.querySelector(".odd-btn__label")),v=q(b,"span").map(_=>dt(C(_))).find(Boolean)||null;return v?{el:b,odd:v,label:z||Dt(d.length,y,p),locked:!1}:null});if(u.length<2||u.some(b=>!b))continue;let h=C(n.querySelector(".coef-btn")).replace(/\s+/g," ");i.push(ht({scope:"top",title:p,period:f,line:h,outcomes:u,anchor:n,eventKey:s}))}return i}function Dt(a,s,i){return/тотал/i.test(i)?["Меньше","Больше"][s]||"":a===3?["П1","Х","П2"][s]:a===2?["1","2"][s]:String(s+1)}function Le(a,s){let i=[];for(let n of q(a,".market")){let p=q(n,".market__row");if(!p.length)continue;let f=C(n.querySelector(".market-title")),d=p.map(h=>{let b=C(h.querySelector(".market__row-text"));return q(h,".market-row-btn").map(y=>{let z=dt(C(y.querySelector(".market-row-btn__coef")));if(!z||y.hasAttribute("disabled"))return null;let v=y.getAttribute("title")||C(y.querySelector(".market-row-btn__text"));return{el:y,odd:z,label:v.replace(/\s+/g," ").trim(),rowLabel:b,locked:!1}})}),{sets:u}=Ht(d);for(let h of u){let b=[...new Set(h.map(_=>_.rowLabel).filter(Boolean))],y=b.length<=1,z=y?"":(h[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=h.map(_=>({el:_.el,odd:_.odd,label:y?_.label:_.rowLabel||_.label,locked:!1}));i.push(ht({scope:"board",title:f,period:y&&b[0]||"",line:z,kind:$t(f,v.length),outcomes:v,anchor:n,eventKey:s}))}}return i}var Ne=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Ae(a){let s=q(a,".card__competitors .name .name, .half__names .name").map(n=>C(n));if(s.length<2)return null;let i=a.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:ae(i),key:mt(s[0],s[1]),home:s[0],away:s[1],href:i,live:/card--live/.test(a.className)||!!a.querySelector(".card__body-live"),time:C(a.querySelector(".header-left__time, .footer__time")),league:C(a.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:a}}function oe(a){let s=[];for(let i of q(a,".card")){if(Pt(i))continue;let n=Ae(i);if(n){for(let p of q(i,".card__body")){let f=C(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let d of q(p,".card__market")){let u=q(d,".coefficient-button");if(u.length<2)continue;let h=(Ne.find(([y])=>y.test(u[0].className))||[])[1]||"other",b=u.map((y,z)=>{let v=/--is-blank/.test(y.className)?null:jt(y);return v?{el:y,odd:v,label:h==="total"?["Меньше","Больше"][z]:Dt(u.length,z,""),locked:/coefficient-button_locked/.test(y.className)}:null});b.some(y=>!y)||s.push(ht({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[h]||"Рынок",period:/^матч$/i.test(f)?"":f,line:C(d.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:h,outcomes:b,event:n,anchor:i,eventKey:n.key}))}}for(let p of q(i,".half__coef-buttons")){let f=q(p,".coef-buttons__button"),d=f.map((u,h)=>{let b=jt(u.querySelector(".button__coef-title")||u);return b?{el:u,odd:b,label:Dt(f.length,h,""),locked:!1}:null});d.length<2||d.some(u=>!u)||s.push(ht({scope:"list",title:d.length===3?"Исход":"Победитель",kind:d.length===3?"1x2":"12",outcomes:d,event:n,anchor:i,eventKey:n.key}))}}}return s}function Oe(a){if(!a?.body)return null;let s=h=>/^\d{1,3}\s?%$/.test(h),i=q(a,"h4").map(h=>{let b=[...h.nextElementSibling?.children||[]],y=C(b[0]),z=C(b[b.length-1]);return s(y)&&s(z)?{label:C(h),home:y.replace(/\s/g,""),away:z.replace(/\s/g,"")}:null}).filter(Boolean);if(!i.length)return null;let n=(a.body.innerText||a.body.textContent||"").replace(/\s+/g," "),p=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(h=>Number(h[1])),d=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(h=>h[1].replace(/\s/g,""));return{names:C(a.querySelector("h3")).split(/\s+vs\s+/i).map(h=>h.trim()).filter(Boolean),rows:i,samples:p.slice(0,2),form:d.length>=2?{home:d[0],away:d[1]}:null}}function Ee(a,s,i){if(!a||a.names.length<2)return a;let n=zt(a.names[0],s)+zt(a.names[1],i);return zt(a.names[0],i)+zt(a.names[1],s)<=n?a:{names:[a.names[1],a.names[0]],rows:a.rows.map(f=>({label:f.label,home:f.away,away:f.home})),samples:a.samples.slice().reverse(),form:a.form?{home:a.form.away,away:a.form.home}:null}}function Be(a){let s=a.querySelector("iframe.stats__iframe");if(!s)return null;try{return Oe(s.contentDocument)}catch{return null}}function qe(a){let s=["one","two"].map(f=>a.querySelector(`.event-live-center__team-widget--${f}`));if(!s[0]||!s[1])return null;let i=f=>{let d=f;try{d=f.querySelector("iframe")?.contentDocument?.body||f}catch{d=f}let u=q(d,'[class*="player"]').filter(b=>!q(b,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(b.className)),h=[];for(let b of u){let y=C(b).split(" ").filter(Boolean),z=y.find(_=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(_)&&/[A-Za-z]/.test(_));if(!z||h.some(_=>_.nick===z))continue;let v=y.filter(_=>/^\d{1,3}$/.test(_)).map(Number);h.push({nick:z,numbers:v.slice(0,4)})}return h.slice(0,5)},n=i(s[0]),p=i(s[1]);return n.length<3||p.length<3?null:{home:n,away:p}}var re={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:It,readMatch:ne,readEsportsWidget:qe,observeTargets(a){try{let s=a.querySelector("iframe.stats__iframe")?.contentDocument?.body;return s?[s]:[]}catch{return[]}},collect(a,s){if(It(a)==="match"){let p=ne(a,s)?.key||"";return[...Ce(a,p),...Le(a,p),...oe(a)]}return oe(a)}};var Lt=(a,s)=>{try{return[...a.querySelectorAll(s)]}catch{return[]}};function se(a,s){let i=[a];if(s.shadow)for(let n of Lt(a,s.shadow))n.shadowRoot&&i.push(n.shadowRoot);return i}var Ct=a=>(a.defaultView?.innerWidth||0)>0,Fe='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function Re(a){let s=[],i=a.ownerDocument.createTreeWalker(a,4);for(;i.nextNode();){let n=i.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&s.push(...n.split(" ")),s.length>5)return null}return s}function Pe(a,s){if(a.disabled||a.hasAttribute?.("disabled"))return null;let i=s.value&&a.querySelector(s.value)||a,n=Re(i);if(!n||!n.length||n.join(" ").length>28)return null;let p=n[n.length-1];if(!(s.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let f=dt(p);if(!f||f>500||n.slice(0,-1).some(u=>/^\d{1,3}[.,]\d{1,3}$/.test(u)))return null;let d=n.slice(0,-1).join(" ");return!s.outcome&&/[+−]|^-/.test(d)?null:{odd:f,label:d}}function je(a,s){let i=[],n=new Set,p=se(a,s).flatMap(f=>Lt(f,s.outcome||Fe));for(let f of p){if(n.has(f)||s.skip&&f.closest(s.skip)||f.closest("#lz-root, #lz-marks"))continue;let d=Pe(f,s);if(d){if(!s.outcome&&Ct(a)){let u=f.getBoundingClientRect();if(u.width<26||u.width>320||u.height<16||u.height>90)continue}n.add(f),i.push({el:f,odd:d.odd,label:d.label,locked:!1})}}return s.outcome?i:i.filter(f=>!i.some(d=>d.el!==f.el&&d.el.contains(f.el)))}function Ie(a,s,i){if(s.row)return a.closest(s.row);let n=a.parentElement;for(let p=0;p<6&&n&&n!==n.ownerDocument.body;p+=1){let f=i(n);if(f>=2&&f<=16){if(!Ct(n.ownerDocument))return n;let d=n.getBoundingClientRect();if(d.height<=130&&d.width>=120)return n}if(f>16)break;n=n.parentElement}return null}var ie=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function De(a,s){let i=s.length,n=a;for(let y=0;y<7;y+=1){let z=n.parentElement;if(!z||s.some(A=>!z.contains(A.el))||z.querySelectorAll("*").length>400||[...z.querySelectorAll('button, a, td, [role="button"]')].filter(A=>!s.some(O=>O.el===A||O.el.contains(A)||A.contains(O.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(C(A))).length>i)break;n=z}let p=s[0].el,f=[],d=n.ownerDocument.createTreeWalker(n,4);for(;d.nextNode();){let y=d.currentNode;if(p.contains(y))break;let z=y.textContent.replace(/[ \s]+/g," ").trim();z.length<2||z.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(z)||/\d{1,2}:\d{2}|^\d|['′]$/.test(z)||ie.test(z)||f.push(z)}let u=f.slice(-2),h=f.map(y=>y.split(/\s+[—–-]\s+/)).filter(y=>y.length===2).pop();if(h&&(u=h),u.length<2||u[0]===u[1])return null;let b=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:mt(u[0],u[1]),home:u[0],away:u[1],href:b,live:!1,time:"",league:"",card:n}}function We(a,s,i){if(!s.names)return De(a,i);let n=s.event&&a.closest(s.event)||a,p=[...new Set(Lt(n,s.names).map(u=>C(u)).filter(Boolean))],f=p;if(p.length===1&&(f=p[0].split(/\s+[—–-]\s+/)),f.length<2||!f[0]||!f[1])return null;let d=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:mt(f[0],f[1]),home:f[0],away:f[1],href:d,live:!1,time:"",league:"",card:n}}function Ze(a){let i=String(a.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!i)return null;let n=[i[1].trim(),i[2].trim()];return n.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:n}function le(a,s={}){function i(v,_){return s.matchUrl&&s.matchUrl.test(_?.pathname||"")||s.matchPage&&v.querySelector(s.matchPage)?"match":"list"}function n(v){let _=v.defaultView;if(!_||!Ct(v))return[];let A=[];for(let O of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if(O.children.length)continue;let L=C(O);if(L.length<3||L.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(L)||/\d{1,2}[:.]\d{2}/.test(L)||ie.test(L))continue;let R=O.getBoundingClientRect();if(!(R.top<60||R.top>450||R.width<30||parseFloat(_.getComputedStyle(O).fontSize)<15)&&(A.includes(L)||A.push(L),A.length===2))break}return A}function p(v,_){if(i(v,_)!=="match")return null;let A=s.matchNames?Lt(v,s.matchNames).map(L=>C(L)).filter(Boolean):[];if(A.length===1&&(A=A[0].split(/\s+[—–-]\s+/)),A.length<2&&(A=Ze(v)||[]),A.length<2&&(A=n(v)),A.length<2)return null;let O=s.matchLeague?C(v.querySelector(s.matchLeague)):"";return{book:a.name,id:(String(_?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:mt(A[0],A[1]),home:A[0],away:A[1],sport:xt(_?.pathname,O,v.title,C(v.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:O,start:"",live:/(^|\/)live(\/|$)/i.test(_?.pathname||"")?!0:null,form:{home:"",away:""},url:_?.href||""}}function f(v,_){return!v||!_?"":_.startsWith("attr:")?String(v.getAttribute(_.slice(5))||"").trim():C(v.querySelector(_))}function d(v,_){if(!Ct(_))return[v];let A=v.map(L=>{let R=L.el.getBoundingClientRect();return{cell:L,top:R.top,left:R.left}}).sort((L,R)=>Math.abs(L.top-R.top)>8?L.top-R.top:L.left-R.left),O=[];for(let L of A){let R=O[O.length-1];R&&Math.abs(R.top-L.top)<=8?R.cells.push(L.cell):O.push({top:L.top,cells:[L.cell]})}return O.map(L=>L.cells)}let u=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],h=v=>(u.find(([_])=>_.test(v.join("/").toLowerCase()))||[])[1]||"other";function b(v,_){let A=i(v,_),O=A==="match"&&s.match?{...s,...s.match}:s;return y(v,_,A,O)}function y(v,_,A,O){let L=je(v,O);if(L.length<2)return[];let R=new Set(L.map(T=>T.el)),et=T=>{let w=0;for(let N of R)T.contains(N)&&(w+=1);return w},J=new Map;for(let T of L){let w=Ie(T.el,O,et);w&&(J.has(w)||J.set(w,[]),J.get(w).push(T))}let it=A==="match"?p(v,_):null,F=[];for(let[T,w]of J){let N=A==="match"?null:We(T,O,w),B=O.group?T.closest(O.group):null,E=f(B,O.groupTitle),V=f(B,O.groupPeriod),P=O.visualRows?d(w,v):[w],W=0;for(let H of P)for(let lt of Gt(H).sets){let nt=W===0,tt=lt.length,Q=tt===3?["П1","Х","П2"]:["1","2"],ot=lt.map((rt,gt)=>({...rt,label:rt.label||Q[gt]||String(gt+1)})),ct=nt&&tt===3?"Исход":nt?"Победитель":`Рынок ${W+1}`,at=nt?tt===3?"1x2":"12":"other";E&&(ct=E,at=$t(E,tt),at==="other"&&(at=h(ot.map(rt=>rt.label)))),F.push(ht({scope:A==="match"?"board":"list",title:ct,period:V,kind:at,outcomes:ot,event:N,anchor:T,eventKey:N?.key||it?.key||`row${F.length}`})),W+=1}}return F}let z=v=>se(v,s).slice(1);return{id:a.id,name:a.name,hosts:a.hosts,generic:!0,pageType:i,readMatch:p,collect:b,observeTargets:z,readEsportsWidget:()=>null}}var ce={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]'},de={fonbet:ce,pari:ce,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function ue(a){let s=Ut(a);return s?s.id==="winline"?{adapter:re,book:s}:{adapter:le(s,de[s.id]||{}),book:s}:null}var Nt=`:host {
  --lz-accent: #6d5ef5;
  --lz-accent-strong: #5646e0;
  --lz-accent-soft: rgba(109, 94, 245, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0f9d58;
  --lz-pos-soft: rgba(15, 157, 88, 0.14);
  --lz-neg: #d93f3f;
  --lz-neg-soft: rgba(217, 63, 63, 0.12);
  --lz-warn: #b7791f;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6f8;
  --lz-surface-2: #eceef2;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #667085;
  --lz-faint: #98a1b0;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

:host([data-theme="dark"]) {
  --lz-accent: #8b7dff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(139, 125, 255, 0.18);
  --lz-accent-ink: #0f1016;
  --lz-pos: #3ecf8e;
  --lz-pos-soft: rgba(62, 207, 142, 0.16);
  --lz-neg: #ff6b6b;
  --lz-neg-soft: rgba(255, 107, 107, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #16181d;
  --lz-surface: #1e2128;
  --lz-surface-2: #272b34;
  --lz-border: #2f3440;
  --lz-text: #f1f3f6;
  --lz-muted: #a3acba;
  --lz-faint: #6f7887;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  color-scheme: dark;
}
`;var pe=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(a,s,...i){let[n,...p]=a.split("."),f=document.createElement(n||"div");p.length&&(f.className=p.join(" "));for(let[d,u]of Object.entries(s||{}))if(!(u==null||u===!1))if(d==="class")f.className=[f.className,u].filter(Boolean).join(" ");else if(d==="style")f.style.cssText=u;else if(d==="text")f.textContent=u;else{if(d==="html")throw new Error("html запрещён");d.startsWith("data-")||d.startsWith("aria-")||d==="role"||d==="title"||d==="type"||d==="href"||d==="target"||d==="rel"||d==="placeholder"||d==="value"||d==="for"||d==="name"||d==="maxlength"||d==="autocomplete"||d==="spellcheck"||d==="tabindex"?f.setAttribute(d,u===!0?"":String(u)):d==="disabled"||d==="hidden"||d==="checked"||d==="selected"?f[d]=!!u:f[d]=u}return me(f,i),f}function me(a,s){for(let i of s)i==null||i===!1||(Array.isArray(i)?me(a,i):a.appendChild(i instanceof Node?i:document.createTextNode(String(i))))}var fe="http://www.w3.org/2000/svg";function U(a,s=16){let i=document.createElementNS(fe,"svg");i.setAttribute("viewBox","0 0 20 20"),i.setAttribute("width",s),i.setAttribute("height",s),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.7"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("aria-hidden","true");for(let n of Ve[a]||[]){let p=document.createElementNS(fe,"path");p.setAttribute("d",n),i.appendChild(p)}return i}var Ve={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function he(){let a=document.createElement("div");a.id="lz-marks",a.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let s=a.attachShadow({mode:"open"});s.appendChild(t("style",{text:Nt+pe}));let i=t("div.layer"),n=t("div.tip");s.append(i,n);let p=new Map,f=new Set,d=0,u=null,h=null,b=new IntersectionObserver(T=>{for(let w of T)w.isIntersecting?f.add(w.target):(f.delete(w.target),p.get(w.target)?.node.classList.remove("on"));z()},{rootMargin:"120px"});function y(){a.isConnected||document.documentElement.appendChild(a)}function z(){d||(d=requestAnimationFrame(()=>{d=0,A()}))}let v=(T,w)=>{for(let N=w;N;N=N.parentNode||N.host)if(N===T)return!0;return!1};function _(T,w){let N=w.left+w.width/2,B=w.top+w.height/2;if(N<0||B<0||N>window.innerWidth||B>window.innerHeight)return!1;let E=document.elementFromPoint(N,B);for(;E?.shadowRoot?.elementFromPoint;){let V=E.shadowRoot.elementFromPoint(N,B);if(!V||V===E)break;E=V}return!!E&&E!==T&&!v(T,E)&&!v(E,T)}function A(){for(let T of f){let w=p.get(T);if(!w)continue;if(!T.isConnected){O(T);continue}let N=T.getBoundingClientRect();if(N.width<6||N.height<6||_(T,N)){w.node.classList.remove("on");continue}let B=Math.round(N.left),E=Math.round(N.top),V=Math.round(N.width),P=Math.round(N.height);(w.x!==B||w.y!==E)&&(w.node.style.transform=`translate3d(${B}px, ${E}px, 0)`,w.x=B,w.y=E),(w.w!==V||w.h!==P)&&(w.node.style.width=`${V}px`,w.node.style.height=`${P}px`,w.w=V,w.h=P,w.node.classList.toggle("small",P<26)),w.node.classList.add("on")}u&&R()}function O(T){let w=p.get(T);w&&(b.unobserve(T),f.delete(T),w.node.remove(),p.delete(T))}function L(T){y();let w=new Map;for(let N of T)N.el?.isConnected&&w.set(N.el,N);for(let N of[...p.keys()])w.has(N)||O(N);for(let[N,B]of w){let E=p.get(N);if(!E){let P=t("div.mark"),W=parseFloat(getComputedStyle(N).borderTopLeftRadius);P.style.borderRadius=`${Number.isFinite(W)&&W>0?Math.min(W,16):6}px`;let H=t("span.chip");P.appendChild(H),i.appendChild(P),E={node:P,chip:H,sig:""},p.set(N,E),b.observe(N)}let V=`${B.frame?1:0}|${B.selected?1:0}|${B.tone||""}|${B.chip||""}`;V!==E.sig&&(E.sig=V,E.node.classList.toggle("frame",!!B.frame),E.node.classList.toggle("selected",!!B.selected),E.node.classList.toggle("pos",B.tone==="pos"&&!!B.frame),E.chip.hidden=!B.chip,E.chip.textContent=B.chip||"",E.chip.className=`chip${B.tone&&B.tone!=="accent"?" "+B.tone:""}`)}z()}function R(){if(!u?.isConnected)return J();let T=u.getBoundingClientRect(),w=264,N=n.offsetHeight||140,B=T.left+T.width/2-w/2;B=Math.max(8,Math.min(B,window.innerWidth-w-8)),h&&B+w>h.left-8&&B<h.right&&(B=Math.max(8,h.left-w-10));let E=T.bottom+10;E+N>window.innerHeight-8&&(E=T.top-N-10),E<8&&(E=8),n.style.transform=`translate3d(${Math.round(B)}px, ${Math.round(E)}px, 0)`}function et(T,w){y(),u=T,n.replaceChildren(w),R(),n.classList.add("on")}function J(){u=null,n.classList.remove("on")}function it(T){h=T}function F(T){a.setAttribute("data-theme",T)}return window.addEventListener("scroll",z,{capture:!0,passive:!0}),window.addEventListener("resize",z,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&z()},700),{set:L,schedule:z,showTip:et,hideTip:J,setTheme:F,setAvoid:it,get tipTarget(){return u},count:()=>p.size}}var ge=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px 60px;
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-faint);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var Y=(a,s=0)=>ut(a,s),_t=a=>`${a>0?"+":a<0?"−":""}${Math.abs(a).toFixed(1)}`;function be({bus:a,actions:s,brand:i}){let n=document.createElement("div");n.id=a.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=n.attachShadow({mode:"open"});p.appendChild(t("style",{text:Nt+ge}));let f=t("span.dot"),d=t("button.fab",{type:"button","data-act":"toggle",title:`${i.name}: открыть панель`,"aria-label":`${i.name}: открыть панель`},U("lens",18),t("span",{text:i.name}),f),u=t("div.tabs",{role:"tablist"}),h=t("div.body"),b=t("div.foot"),y=t("small"),z=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),_=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},U("gear")),A=t("div.head",{},t("div.brand",{},t("span.logo",{},U("lens",15)),t("span",{text:i.name}),y),t("span.grow"),v,z,_,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},U("close"))),O=t("section.panel",{hidden:!0,role:"dialog","aria-label":i.name},A,u,h,b);p.append(d,O);let L=()=>{n.isConnected||document.documentElement.appendChild(n)};L(),new MutationObserver(L).observe(document.documentElement,{childList:!0});let R="",et=null,J=new Map,it=e=>{for(let o of e.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},F=null;a.on("ui:pointerdown",e=>{if(e.button!==0)return;let o=e.composedPath(),l=o.includes(d),g=o.includes(A)&&!o.some(x=>x?.dataset?.act);if(!l&&!g)return;let S=l?d:O,k=S.getBoundingClientRect();F={target:S,key:l?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:k.left,oy:k.top,moved:!1},a.setDragging(!0)}),a.on("drag:move",e=>{if(!F)return;let o=e.clientX-F.sx,l=e.clientY-F.sy;!F.moved&&Math.hypot(o,l)<5||(F.moved=!0,F.target.classList.add("dragging"),w(F.target,F.ox+o,F.oy+l))}),a.on("drag:end",()=>{if(F){if(a.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let e=F.target.getBoundingClientRect();s.savePosition(F.key,{left:e.left,top:e.top}),T=!0,setTimeout(()=>{T=!1},60)}F=null}});let T=!1;function w(e,o,l){let g=e.offsetWidth||120,S=e.offsetHeight||40,k=Math.max(6,Math.min(o,window.innerWidth-g-6)),x=Math.max(6,Math.min(l,window.innerHeight-Math.min(S,60)-6));e.style.left=`${Math.round(k)}px`,e.style.top=`${Math.round(x)}px`,e.style.right="auto"}a.on("ui:click",e=>{if(T)return;let o=it(e);if(!o||o.disabled)return;e.preventDefault();let l=o.dataset.act;if(l==="toggle")return kt();if(l==="close")return st();let g=s[l];g&&g(o.dataset.arg,o,p)}),a.on("ui:keydown",e=>{if(e.key==="Escape"&&st(),e.key==="Enter"){let o=e.composedPath()[0];o?.dataset?.enter&&s[o.dataset.enter]?.(o.value,o,p)}});let N=(e,o)=>t("span.form",{},[...String(e||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function B(e){let o=e.live,l=o?t("div.center",{},o.score?.length===2?t("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,t("span.badge.live",{text:o.state||"Лайв"})):t("div.center",{},t("span",{text:e.start||"до матча"})),g=o?.periods?.length?t("div.periods",{text:o.periods.map(k=>k.raw?`${k.label} ${k.raw}`:`${/^\d+$/.test(k.label)?`${k.label}-й отрезок`:k.label} ${k.home}:${k.away}`).join(" · ")}):null,S=o?.extras?.length?t("div.periods",{text:o.extras.map(k=>`${k.kind} ${k.home}:${k.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:e.league||e.sportName||"",title:e.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:e.home,title:e.home}),e.form?.home?N(e.form.home):null),l,t("div.team.away",{},t("b",{text:e.away,title:e.away}),e.form?.away?N(e.form.away):null)),g,S)}function E(e){let o=e.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:e.title}),Number.isFinite(e.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${Y(e.margin,1)}`}):null),e.rows.map(l=>{let g=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:K(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},Y(o&&Number.isFinite(l.model)?l.model:l.fair),g!=null&&Math.abs(g)>=.05?t(`small${g>0?".pos":".neg"}`,{text:`${_t(g)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),o?t("span.model",{text:"оценка модели"}):null))}function V(e){let o=e.analysis;if(o.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},o.steps.map((x,M)=>t(`div.step${M===o.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:x})))));if(o.status==="error")return t("div.card",{},t("div.note.warn",{},U("alert"),t("span",{text:o.error})),o.needKey?t("div.row",{style:"margin-top:10px"},t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},U("gear"),"Открыть настройки")):null);if(o.status!=="done"||!o.result)return null;let l=o.result,g={home:e.match?.home,away:e.match?.away,draw:"ничья"}[l.lean],S=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,k=new Map((l.facts||[]).map(x=>[x.id,x]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:g?`Данные сдвигают оценку в сторону: ${g}`:S?`Данные слегка склоняют в сторону: ${S.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),S?t("div.note",{style:"margin-bottom:10px"},U("info"),t("span",{text:`Модель предложила сдвиг на ${S.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(x=>t(`li.factor${x.side==="home"?".home":x.side==="away"?".away":""}`,{},t("div",{},t("p",{text:x.text}),t("div.src",{},(x.facts||[]).map(M=>k.get(M)).filter(Boolean).map(M=>t("span.tag",{text:`${M.id} · ${M.source}`,title:M.text}))))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},U("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,t("details",{"data-key":"facts",open:J.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(x=>t("li",{},t("b",{text:x.id}),t("span",{},x.text," ",t("em",{text:`— ${x.source}`})))))),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function P(e){let o=e.compare?.consensus||e.analysis?.result?.consensus||e.consensus;if(!o?.consensus||!e.line?.rows?.length)return null;let l=o.consensus.length===2&&e.line.rows.length===3;if(!l&&e.line.rows.length!==o.consensus.length)return null;let g=l?e.line.overtime:null,S=g?g.rows:l?[e.line.rows[0],e.line.rows[2]].map(x=>({...x,odd:null,fair:null})):e.line.rows,k=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${o.count} контор`})),S.map((x,M)=>{let $=o.consensus[M],I=x.odd?x.odd*$-1:0,j=Number.isFinite(x.fair)?(x.fair-$)*100:0;return t("div.prob",{},t("span.name",{text:x.name,title:x.name}),t("span.odd",{text:K(1/$),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round($*100)}%`}),t("u",{style:`left:${Math.round((x.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},Y($),I>.005?t("small.pos",{text:`кэф выше рынка ${_t(I*100)}%`}):Math.abs(j)>=2?t(`small${j>0?".neg":""}`,{text:`${_t(j)} п.п. к рынку`,title:j>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!g?null:t("span.model",{text:g?`шанс по рынку «${g.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l?g?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(K).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(K).join(" / ")}. `:""}Цены ${o.count} контор без маржи${k?`, обновлено в ${k}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}function W(e){let o=e.compare?.model||e.analysis?.result?.model||e.model;if(!o?.p1||!e.line?.rows?.length)return null;let l=e.line.rows.length===3&&o.overtime;if(!l&&e.line.rows.length!==2)return null;let g=l?e.line.overtime:null,S=g?g.rows:l?[e.line.rows[0],e.line.rows[2]].map(j=>({...j,fair:null})):e.line.rows,k=[o.p1,o.p2],x=o.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${o.samples} матчей у менее опытного игрока)`:o.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига; ${o.samples} игр у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} карт у менее опытной команды)`,M=o.backtest,$=(M?.calibration||[]).filter(j=>[60,70,80].includes(j.threshold)),I=$.length?`На проверке ${M.test} сыгранных матчей: ${$.map(j=>`при уверенности ≥${j.threshold}% сбывалось ${j.hit}%`).join(", ")}`:M?`На проверке ${M.test} матчей угадано ${Math.round(M.acc*100)}%`:"Точность ещё измеряется";return t("div.card",{},t("div.kicker",{},t("span",{text:l?"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:`уверенность: ${o.confidence}`})),S.map((j,D)=>{let Z=k[D],G=Number.isFinite(j.fair)?(Z-j.fair)*100:0;return t("div.prob",{},t("span.name",{text:j.name,title:j.name}),t("span.odd",{text:K(1/Z),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(Z*100)}%`}),t("u",{style:`left:${Math.round((j.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},Y(Z),Math.abs(G)>=3?t(`small${G>0?".pos":".neg"}`,{text:`${_t(G)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),o.factors?.length?t("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,4).map(j=>t("li",{},t("span",{text:j})))):null,t("div.hint",{style:"margin-top:8px",text:`${x}. ${I}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}let H=e=>`${Math.round(e).toLocaleString("ru-RU")} ₽`,lt=e=>(e.erid?["Реклама",e.legal,`erid ${e.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",e.legal].filter(Boolean).join(" · "))+" · 18+",nt=(e,o)=>t("a.btn.ghost.small",{href:e.url,target:"_blank",rel:"noopener sponsored"},U("link",13),o||`Открыть у ${e.name}`),tt=e=>e.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":e.code,title:e.bonus||"Скопировать промокод"},`Промокод ${e.code}`):null;function Q(e){let o=(e.partners||[]).filter(l=>l.url||l.code);return o.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:o.length===1?`Промокод ${o[0].name}`:"Промокоды контор"})),o.map(l=>t("div.partner",{},t("div.partner-text",{},t("b",{text:l.name}),l.bonus?t("span",{text:` — ${l.bonus}`}):null),t("div.partner-links",{},tt(l),l.url?nt(l):null),t("div.hint",{text:lt(l)})))):null}function ot(e,o={}){if(e.status==="idle")return null;if(e.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let l=e.labels||[];if(!e.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let g=l.map((D,Z)=>Math.max(...e.rows.map(G=>G.odds[Z]||0))),S=Object.fromEntries((o.partners||[]).map(D=>[D.id,D])),k=D=>D.book&&D.book!==o.bookId&&!D.sharp&&S[D.book]||null,x=o.stake||1e3,M=e.rows.find(D=>D.here)||e.rows[0],I=l.map((D,Z)=>{let G=M?.odds?.[Z],ft=e.rows.filter(wt=>wt!==M&&!wt.sharp&&wt.odds[Z]).sort((wt,ve)=>ve.odds[Z]-wt.odds[Z])[0];return!G||!ft||ft.odds[Z]<=G?null:{label:D,row:ft,odd:ft.odds[Z],mine:G,gain:(ft.odds[Z]-G)*x}}).filter(Boolean).sort((D,Z)=>Z.gain-D.gain)[0],j=e.rows.map(k).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),l.map(D=>t("th",{text:D}))),e.rows.map(D=>{let Z=k(D);return t("tr",{},t("td.name",{title:D.sharp?"Цена с мирового рынка, для сравнения":""},D.name,Z?t("div.partner-links",{},Z.url?nt(Z):null,tt(Z)):null),D.odds.map((G,ft)=>t(`td${G&&G===g[ft]&&e.rows.length>1?".best":""}`,{text:G?K(G):"—"})))})),I&&I.gain>=1?t("div.gain",{},`На «${I.label}» у ${I.row.name} кэф ${K(I.odd)} против ${K(I.mine)} здесь: со ставки ${H(x)} выигрыш больше на `,t("b",{text:H(I.gain)}),"."):null,j.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(j.map(lt))].join(" ")}):null,e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null)}function ct(e){let o=[],l=(S,k,x)=>o.push(t("dt",{text:S}),t(`dd${x?"."+x:""}`,{text:k}));Number.isFinite(e.fair)?(l("Шанс по линии без маржи",Y(e.fair,1)),l("Кэф без маржи конторы",K(e.fairOdd)),l("Маржа конторы в этом рынке",Y(e.margin,1))):l("Заложено в кэфе (с маржой)",Y(1/e.odd,1)),Number.isFinite(e.model)&&(l("Оценка модели",Y(e.model,1)),l("Ожидание на рубль по модели",`${_t(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&l(`Лучшая цена: ${e.best.name}`,K(e.best.odd),e.best.odd>e.odd?"pos":"");let g=e.best?.partner&&(e.best.partner.url||e.best.partner.code)?e.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:e.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},U("close",13))),t("div.pick-head",{},t("span.big",{text:K(e.odd)}),t("span.what",{text:e.label,title:e.label})),t("dl.kv",{},o),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},U("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")),g?t("div.partner",{style:"margin-top:10px"},e.best.gain>=1?t("div.gain",{},`У ${g.name} этот кэф выше: со ставки ${H(e.stake||1e3)} выигрыш больше на `,t("b",{text:H(e.best.gain)}),"."):null,t("div.partner-links",{},g.url?nt(g):null,tt(g)),t("div.hint",{text:lt(g)})):null)}function at(e){let o=(l,g)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),g.map(S=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:S.nick}),t("span",{style:"color:var(--lz-muted)",text:S.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(e.homeName,e.home),o(e.awayName,e.away)))}function rt(e,o){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:o.home}),t("th",{text:o.away})),e.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),e.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function gt(e){let o=[];if(e.pick&&o.push(ct({...e.pick,stake:e.stake})),!e.match)return o.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(B(e.match)),e.esports&&o.push(at(e.esports)),e.match.stats?.rows?.length&&o.push(rt(e.match.stats,e.match)),e.line&&o.push(E(e.line));let l=P(e);l&&o.push(l);let g=W(e);g&&o.push(g);let S=e.analysis.status==="loading";o.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:S},U("spark"),S?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},U("scale"),"Сравнить цены"))),e.quota&&o.push(t("div.hint.center-text",{text:e.quota}));let k=Q(e);k&&o.push(k);let x=V(e);x&&o.push(x);let M=ot(e.compare,e);return M&&o.push(M),o}function Ot(e){let o=e.scan;return o?.rows?.length?[t("div.card",{},t("div.kicker",{},t("span",{text:o.title}),t("span.badge",{text:`средняя маржа ${Y(o.average,1)}`})),t("table",{},t("tr",{},t("th",{text:o.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),o.rows.map(l=>t("tr.click",{"data-act":"scan-go","data-arg":String(l.index),title:"Показать на странице"},t("td.name",{},l.name,l.sub?t("span.sub",{text:l.sub}):null),t("td",{},l.fav,t("span.sub",{text:Y(l.favPct)})),t(`td${l.low?".best":""}`,{text:Y(l.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:o.note}))]:[t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function Mt(e){let o=e.express;if(!o.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${o.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},U("trash",13),"Очистить")),o.legs.map(g=>t("div.leg",{},t("div.t",{},t("b",{text:g.label,title:g.label}),t("span",{text:g.title,title:g.title})),t("span.o",{text:K(g.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":g.id,title:"Убрать",style:"width:24px;height:24px"},U("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:K(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:Y(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:K(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:Y(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function bt(e){let o=e.edges||{status:"idle"},l=$=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),$?t("span.badge",{text:$}):null);if(o.status==="loading"&&!o.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[t("div.card",{},l(),t("div.note.warn",{},U("alert"),t("span",{text:o.error})))];let g=o.data;if(!g)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let S=$=>$==null?"—":`${$>=0?"+":"−"}${(Math.abs($)*100).toFixed(1)}%`,k=$=>new Date($).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),x=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(g.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(g.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:S(g.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:g.positiveWeek==null?"—":Y(g.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),M=(g.signals||[]).map($=>t("tr",{},t("td.name",{},`${$.home} — ${$.away}`,t("span.sub",{text:`${$.league} · ${k($.start)}`})),t("td",{},$.label,t("span.sub",{text:$.book})),t("td",{text:K($.odds)}),t("td",{text:K(1/$.p),title:`Честная цена по ${$.count} конторам`}),t("td.best",{text:`+${($.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(g.full?"тариф «Макс»":"витрина"),M.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),M):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),g.note?t("div.hint",{style:"margin-top:8px"},g.note," ",i.bot?t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),x]}function Et(e){let o=e.settings,l=(g,S,k)=>t("div.seg",{},k.map(([x,M])=>t(`button${S===x?".on":""}`,{type:"button","data-act":g,"data-arg":x,text:M})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(o.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),i.bot&&!o.licenseMask?[" ",t("a",{href:i.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function Bt(e){et=e;let o=JSON.stringify(e);if(o===R)return;R=o;for(let k of h.querySelectorAll("details[data-key]"))J.set(k.dataset.key,k.open);let l=h.scrollTop;y.textContent=e.bookName?`· ${e.bookName}`:"",f.classList.toggle("off",e.settings.overlay==="off"),z.replaceChildren(U(e.theme==="dark"?"sun":"moon")),v.replaceChildren(U(e.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",e.settings.overlay!=="off"),_.classList.toggle("on",e.tab==="settings"),_.dataset.arg=e.tab==="settings"?e.backTab:"settings";let g=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];u.replaceChildren(...g.map(([k,x])=>t(`button.tab${e.tab===k?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":k},x,k==="express"&&e.express.legs.length?t("span.count",{text:String(e.express.legs.length)}):null)));let S=e.tab==="settings"?Et(e):e.tab==="scan"?Ot(e):e.tab==="express"?Mt(e):e.tab==="edges"?bt(e):gt(e);h.replaceChildren(...S.filter(Boolean)),h.scrollTop=l,b.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function St(e){n.setAttribute("data-theme",e)}function vt(){O.hidden=!1,s.opened?.()}function st(){O.hidden=!0}function kt(){O.hidden?vt():st()}function r(e){e?.fab&&w(d,e.fab.left,e.fab.top),e?.panel&&w(O,e.panel.left,e.panel.top)}let c=0;function m(e){p.querySelector(".toast")?.remove();let o=t("div.toast",{text:e,role:"status"});p.appendChild(o),clearTimeout(c),c=setTimeout(()=>o.remove(),2600)}return{render:Bt,setTheme:St,open:vt,close:st,toggle:kt,restore:r,toast:m,shadow:p,rect:()=>O.hidden?null:O.getBoundingClientRect(),get isOpen(){return!O.hidden},get view(){return et}}}var xe="Расширение обновилось. Обновите эту вкладку (F5).";function pt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function X(a,s={}){if(!pt())return{ok:!1,error:xe,code:"reload"};try{return await chrome.runtime.sendMessage({type:a,...s})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(i){let n=String(i?.message||i);return/context invalidated|message port closed|receiving end does not exist/i.test(n)||!pt()?{ok:!1,error:xe,code:"reload"}:{ok:!1,error:n}}}function ye(a){if(pt())try{chrome.runtime.onMessage.addListener(s=>{a(s)})}catch{}}async function Wt(a){if(!pt())return{};try{return await chrome.storage.local.get(a)}catch{return{}}}function yt(a){if(pt())try{chrome.storage.local.set(a)}catch{}}var At=globalThis.__lzBus,Zt=At&&window.top===window?ue(location.hostname):null;Zt&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,He(Zt.adapter,Zt.book));async function He(a,s){let i=await Wt(["lz.settings","lz.positions","lz.express"]),n={settings:{...qt,...i["lz.settings"]||{}},positions:(i["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Ge(i["lz.express"]),analysis:new Map,compare:new Map,consensus:new Map,model:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,f=new WeakMap,d=he(),u=be({bus:At,brand:Kt,actions:Ot()});u.restore(n.positions);function h(r){let c=r.outcomes.map(o=>o.odd).join("/"),m=p.get(r);if(m?.sig===c)return m.set;let e=Ft(r.outcomes.map(o=>o.odd));return p.set(r,{sig:c,set:e}),e}function b(){return n.match?n.analysis.get(n.match.key):null}function y(r){let c=b()?.result;if(!c?.model||r.scope==="list"||!n.match||!Object.values(c.shift||{}).some(g=>Math.abs(g)>=.5))return null;let{home:m,draw:e,away:o}=c.model,l=r.outcomes.length;if(r.kind==="1x2"&&r.main&&l===3)return[m,e,o];if(r.kind==="12"&&r.main&&l===2&&e<.005)return[m,o];if(r.kind==="dc"&&r.main&&l===3)return[m+e,m+o,e+o];if(/^победит\s*\(осн\.?\s*время\)$/i.test(r.title)&&l===2){let g=r.period===n.match.home?m:r.period===n.match.away?o:null;if(g!=null)return[g,1-g]}return null}function z(){let r=n.markets.filter(c=>c.scope!=="list"&&c.main&&(c.kind==="1x2"||c.kind==="12"));return r.find(c=>c.scope==="top")||r[0]||null}function v(r,c){let m=r.outcomes[c].label;return r.scope==="list"?!r.event||!r.main?m:r.kind==="1x2"?[r.event.home,"Ничья",r.event.away][c]||m:r.kind==="12"&&[r.event.home,r.event.away][c]||m:n.match?r.kind==="1x2"?[n.match.home,"Ничья",n.match.away][c]||m:r.kind==="12"&&[n.match.home,n.match.away][c]||m:m}function _(){let r=n.settings.overlay,c=[];for(let e of n.markets){if(e.outcomes.forEach((M,$)=>f.set(M.el,{market:e,index:$})),r==="off")continue;let o=h(e);if(o.kind==="partial")continue;let l=y(e),g=l||o.fair,S=0;for(let M=1;M<o.fair.length;M+=1)o.fair[M]>o.fair[S]&&(S=M);let k="accent";if(l){let M=0;for(let $=1;$<l.length;$+=1)l[$]-o.fair[$]>l[M]-o.fair[M]&&(M=$);l[M]-o.fair[M]>=.015&&(S=M,k="pos")}let x=e.scope!=="list"||e.main&&(e.kind==="1x2"||e.kind==="12");e.outcomes.forEach((M,$)=>{let I=$===S&&x;!I&&r!=="all"||c.push({el:M.el,frame:I,chip:ut(g[$]),tone:I?k:"quiet"})})}let m=A();if(m){let e=c.find(o=>o.el===m.item.el);e?e.selected=!0:c.push({el:m.item.el,frame:!1,selected:!0,chip:null})}d.set(c)}function A(){if(!n.selected)return null;let r=n.markets.find(m=>m.id===n.selected.id),c=r?.outcomes[n.selected.index];return c?.el?.isConnected?{market:r,item:c,index:n.selected.index}:null}function O(){if(n.settings.theme!=="auto")return n.settings.theme;for(let r of[document.body,document.documentElement]){let m=(r?getComputedStyle(r).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!m||m[4]==="0")continue;return(.2126*m[1]+.7152*m[2]+.0722*m[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function L(){location.href!==n.url&&(n.url=location.href,n.selected=null,d.hideTip());let r="other",c=[],m=null;try{r=a.pageType(document,location),c=a.collect(document,location),m=a.readMatch(document,location)}catch(o){console.error("[Линза] страница не прочитана",o)}r!==n.pageType&&(n.pageType=r,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=r==="match"?"match":"scan")),n.markets=c,n.match=m;let e=O();e!==n.theme&&(n.theme=e),d.setTheme(n.theme),u.setTheme(n.theme),_(),ct(),J(),u.isOpen&&(at(),rt(),u.render(P()))}let R=new Set,et=null;function J(){if(a.observeTargets)for(let r of a.observeTargets(document))R.has(r)||(R.add(r),et=et||new MutationObserver(T),et.observe(r,{childList:!0,subtree:!0,characterData:!0}))}let it=0,F=0;function T(){let r=Date.now();F||(F=r),clearTimeout(it);let c=r-F>900?0:220;it=setTimeout(()=>{F=0,!document.hidden&&L()},c)}function w(){let r=z();if(!r)return null;let c=h(r);if(c.kind!=="full")return null;let m=y(r);return{title:"Что заложено в цене",margin:c.margin,rows:r.outcomes.map((e,o)=>({name:v(r,o),odd:e.odd,fair:c.fair[o],model:m?m[o]:null})),overtime:N()}}function N(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let r=n.markets.find(m=>m.scope!=="list"&&m.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|ot/i.test(`${m.title} ${m.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${m.title} ${m.period}`));if(!r)return null;let c=h(r);return c.kind!=="full"?null:{title:[r.title,r.period].filter(Boolean).join(" · "),rows:r.outcomes.map((m,e)=>({name:v(r,e)||[n.match.home,n.match.away][e],odd:m.odd,fair:c.fair[e]}))}}function B(){let r=A();if(!r)return null;let{market:c,item:m,index:e}=r,o=h(c),l=y(c),g=o.fair?o.fair[e]:null,S=c.event?`${c.event.home} — ${c.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",k=n.match?n.compare.get(n.match.key):null,x=null;if(k?.rows?.length&&c.main&&(c.kind==="1x2"||c.kind==="12")&&c.scope!=="list")for(let $ of k.rows){let I=$.odds[e];I&&(!x||I>x.odd)&&(x={name:$.name,odd:I,book:$.book||""})}x&&(x.partner=x.book&&x.book!==s.id&&n.partners.data?.[x.book]||null,x.gain=Math.round((x.odd-m.odd)*(n.settings.stake||1e3)));let M=`${c.id}#${e}`;return{market:[c.title,c.period,c.line].filter(Boolean).join(" · "),label:[v(c,e),S].filter(Boolean).join(" · "),odd:m.odd,fair:g,margin:o.margin,fairOdd:g?1/g:null,model:l?l[e]:null,ev:l?Jt(l[e],m.odd):null,best:x,canAdd:Number.isFinite(g)&&!n.express.some($=>$.id===M),inExpress:n.express.some($=>$.id===M),note:o.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":l?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function E(){let r=[];if(n.pageType==="match"?n.markets.forEach((o,l)=>{if(o.scope==="list")return;let g=h(o);if(g.kind!=="full")return;let S=0;for(let k=1;k<g.fair.length;k+=1)g.fair[k]>g.fair[S]&&(S=k);r.push({index:l,name:o.title,sub:[o.period,o.line].filter(Boolean).join(" · "),margin:g.margin,fav:o.outcomes[S].label,favPct:g.fair[S]})}):n.markets.forEach((o,l)=>{if(!o.event||!o.main||o.kind!=="1x2"&&o.kind!=="12")return;let g=h(o);if(g.kind!=="full")return;let S=0;for(let x=1;x<g.fair.length;x+=1)g.fair[x]>g.fair[S]&&(S=x);let k=o.kind==="1x2"?[o.event.home,"Ничья",o.event.away][S]:[o.event.home,o.event.away][S];r.push({index:l,name:`${o.event.home} — ${o.event.away}`,sub:o.event.league||o.event.time,margin:g.margin,fav:k,favPct:g.fair[S]})}),!r.length)return null;let c=new Set;for(let o=r.length-1;o>=0;o-=1){let l=`${r[o].name}|${r[o].sub}`;c.has(l)?r.splice(o,1):c.add(l)}let m=r.reduce((o,l)=>o+l.margin,0)/r.length;r.sort((o,l)=>o.margin-l.margin);let e=r.slice(0,16);return e.forEach(o=>{o.low=o.margin<=m*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:m,rows:e,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${e.length} из ${r.length}, сначала самые дешёвые.`}}function V(){let r=n.status;return r.ready?r.limit?`Разборов сегодня: ${r.used} из ${r.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function P(){let r=n.match?.key,c=r&&n.analysis.get(r)||{status:"idle",steps:[]},m=r&&n.compare.get(r)||{status:"idle"},e=n.match?.live&&a.readEsportsWidget?a.readEsportsWidget(document):null,o=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:s.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Vt[n.match.sport]||""}:null,esports:e?{...e,homeName:n.match.home,awayName:n.match.away}:null,line:w(),analysis:{status:c.status,steps:c.steps||[],result:c.result||null,error:c.error||"",needKey:!!c.needKey},compare:m,consensus:r&&n.consensus.get(r)||null,model:r&&n.model.get(r)||null,pick:B(),scan:n.tab==="scan"?E():null,edges:n.edges,bookId:s.id,partners:nt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Yt(n.express)},quota:V(),settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:o.mode,proxy:o.proxy,ready:o.ready,hasKey:o.hasKey,keyMask:o.keyMask,licenseMask:o.licenseMask,plan:o.plan==="free"||!o.plan?"":`Тариф «${o.plan==="max"?"Макс":"Про"}»${o.until?` до ${o.until.split("-").reverse().join(".")}`:""}.`,usage:o.limit?`Сегодня разборов: ${o.used} из ${o.limit}.`:""}}}let W=()=>{u.isOpen&&u.render(P())};function H(r){Object.assign(n.settings,r),yt({"lz.settings":n.settings}),L(),u.render(P())}async function lt(r=!1){if(!r&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let c=await X("lz:partners",{force:r});c.ok&&c.data&&typeof c.data=="object"&&(n.partners.data=c.data,u.isOpen&&u.render(P()))}let nt=()=>Object.values(n.partners.data||{}).filter(r=>r&&r.id!==s.id);async function tt(){n.edges={...n.edges,status:"loading",error:""};let r=await X("lz:edges",{sport:n.match?.sport||""});n.edges=r.ok?{status:"done",data:r.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:r.error,at:Date.now()},W()}async function Q(){let r=await X("lz:status");r.ok&&(n.status=r.data),W()}function ot(){let r=z(),c=r?h(r):null;return{book:s.name,match:n.match,market:r&&c?.kind==="full"?{kind:r.kind,labels:r.outcomes.map((m,e)=>v(r,e)),odds:r.outcomes.map(m=>m.odd)}:null}}function ct(){if(!n.match||!pt())return;let r=ot();if(!r.market)return;let c=`${n.match.key}|${r.market.odds.join("/")}`;c!==ct.last&&(ct.last=c,X("lz:quote",r))}async function at(){let r=n.match;if(!r||r.live||n.consensus.has(r.key))return;let c=ot();if(!c.market?.odds?.length)return;n.consensus.set(r.key,null);let m=await X("lz:consensus",{match:r,size:c.market.odds.length});n.consensus.set(r.key,m.ok&&m.data?.consensus?m.data:null),n.match?.key===r.key&&u.isOpen&&u.render(P())}async function rt(){let r=n.match;if(!r||!["cs","dota","tennis","basketball"].includes(r.sport)||n.model.has(r.key)||r.live&&(r.sport==="tennis"||r.sport==="basketball"))return;n.model.set(r.key,null);let c=await X("lz:model",{match:r});n.model.set(r.key,c.ok&&c.data?.p1?c.data:null),n.match?.key===r.key&&u.isOpen&&u.render(P())}async function gt(){let r=n.match;if(!r||n.analysis.has(r.key))return;let c=await X("lz:cached",{match:r});!c.ok||!c.data||n.analysis.has(r.key)||(n.analysis.set(r.key,{status:"done",steps:[],result:c.data}),L(),W())}function Ot(){return{opened(){Q(),L(),gt(),at(),rt(),lt(),u.render(P())},tab(r){r==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=r||"match",r==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&tt(),u.render(P())},"edges-refresh"(){tt(),u.render(P())},theme(){H({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){H({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(r){H({overlay:r})},"set-theme"(r){H({theme:r})},async"set-mode"(r){await X("lz:settings",{mode:r}),Q()},"copy-code"(r){if(!r)return;let c=()=>u.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(r).then(c,()=>u.toast(`Промокод: ${r}`)):u.toast(`Промокод: ${r}`)},"set-stake"(r,c,m){let e=Math.round(Number(m.getElementById("lz-stake")?.value));if(!Number.isFinite(e)||e<10||e>1e7)return u.toast("Введите сумму от 10 ₽");H({stake:e}),u.toast("Сумма сохранена")},async"save-key"(r,c,m){let e=m.getElementById("lz-key"),o=(e?.value||"").trim();if(o.length<8)return u.toast("Вставьте ключ целиком");let l=await X("lz:settings",{apiKey:o});u.toast(l.ok?"Ключ сохранён":l.error),e&&(e.value=""),Q()},async"clear-key"(){await X("lz:settings",{apiKey:""}),u.toast("Ключ удалён"),Q()},async"save-license"(r,c,m){let e=m.getElementById("lz-license"),o=(e?.value||"").trim();if(o.length<6)return u.toast("Вставьте ключ целиком");let l=await X("lz:settings",{licenseKey:o});u.toast(l.ok?"Ключ принят":l.error),e&&(e.value=""),Q()},async"clear-license"(){await X("lz:settings",{licenseKey:""}),u.toast("Ключ удалён"),Q()},savePosition(r,c){n.positions[r]=c,Wt(["lz.positions"]).then(m=>{let e=m["lz.positions"]||{};e[location.hostname]=n.positions,yt({"lz.positions":e})})},async analyze(){if(!n.match)return;let r=n.match.key,c={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(r,c),W();let m=await X("lz:analyze",{...ot(),force:!0});m.ok?n.analysis.set(r,{status:"done",steps:c.steps,result:m.data}):n.analysis.set(r,{status:"error",steps:c.steps,error:m.error,needKey:m.code==="no-access"}),Q(),L(),u.render(P())},async compare(){if(!n.match)return;let r=n.match.key;n.compare.set(r,{status:"loading"}),W();let c=await X("lz:compare",ot());n.compare.set(r,c.ok?{status:"done",...c.data}:{status:"done",rows:[],labels:[],note:c.error}),W()},"pick-clear"(){n.selected=null,_(),W()},"leg-add"(){let r=B(),c=A();!r?.canAdd||!c||(n.express.push({id:`${c.market.id}#${c.index}`,title:r.market,label:r.label,odd:r.odd,fair:r.fair,at:Date.now()}),yt({"lz.express":n.express}),u.toast("Добавлено в расчёт экспресса"),W())},"leg-remove"(r){n.express=n.express.filter(c=>c.id!==r),yt({"lz.express":n.express}),W()},"leg-clear"(){n.express=[],yt({"lz.express":n.express}),W()},"scan-go"(r){let c=n.markets[Number(r)],m=c?.outcomes[0]?.el;m?.isConnected&&(m.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:c.id,index:0},setTimeout(_,400))}}}function Mt(r){let c=r.composedPath();for(let m=0;m<Math.min(c.length,6);m+=1){let e=c[m]instanceof Element?f.get(c[m]):null;if(e&&e.market.outcomes[e.index]?.el===c[m])return e}return null}let bt=new Map;function Et(r){if(!r.event||!r.main||!["1x2","12"].includes(r.kind)||r.scope!=="list"||r.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!r.event,main:r.main,kind:r.kind,scope:r.scope,live:r.event?.live})),null;let c=r.event.key;if(bt.has(c))return bt.get(c);let m={home:r.event.home,away:r.event.away,sport:Bt(r),league:r.event.league||""},e=X("lz:consensus",{match:m,size:r.outcomes.length}).then(o=>((!o.ok||!o.data?.consensus)&&console.debug("[lz] рынок для списка:",o.error||o.data?.error||"нет данных"),o.ok&&o.data?.consensus?o.data:null)).catch(o=>(console.debug("[lz] рынок для списка:",String(o?.message||o)),null));return bt.set(c,e),e.then(o=>bt.set(c,o)),e}let Bt=r=>r.event?.sport||n.match?.sport||xt(location.pathname,document.title,r.event?.league);function St({market:r,index:c},m=null){let e=h(r),o=y(r),l=r.event?`${r.event.home} — ${r.event.away}`:"",g=r.outcomes.map((x,M)=>{let $=e.fair?e.fair[M]:1/x.odd;return t(`div.tip-row${M===c?".hot":""}`,{},t("span",{text:v(r,M)}),t("span.odd",{text:K(x.odd)}),t("span.pct",{text:ut($,$<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round($*100)}%`})))}),S=e.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:ut(e.margin,1)}),o?t("span",{}," · модель: ",t("b",{text:ut(o[c],1)})):null),k=null;if(m?.consensus){let x=m.consensus.length===r.outcomes.length,M=!x&&m.consensus.length===2&&r.outcomes.length===3;if(x||M){let $=x?m.consensus[c]:null,I=$?r.outcomes[c].odd*$-1:0;k=t("div.tip-foot",{},`Рынок, ${m.count} контор${M?", с овертаймом":""}: `,t("b",{text:m.consensus.map(j=>ut(j,0)).join(" / ")}),I>.005?t("span.pos",{text:` · кэф выше рынка на ${(I*100).toFixed(1)}%`}):null)}}else m===void 0&&(k=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[r.title,r.period,r.line].filter(Boolean).join(" · ")}),l?t("div.tip-sub",{text:l}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),g.slice(0,8),S,k)}let vt=0,st=null;At.on("page:pointerover",r=>{if(n.settings.overlay==="off")return;let c=Mt(r),m=c?c.market.outcomes[c.index].el:null;if(m!==st){if(st=m,clearTimeout(vt),!c)return d.hideTip();vt=setTimeout(()=>{if(st!==m||!m.isConnected)return;d.setAvoid(u.rect());let e=Et(c.market);d.showTip(m,St(c,e instanceof Promise?void 0:e)),e instanceof Promise&&e.then(o=>{st===m&&m.isConnected&&d.showTip(m,St(c,o))})},280)}}),At.on("page:click",r=>{let c=Mt(r);c&&(n.selected={id:c.market.id,index:c.index},n.tab==="scan"&&(n.tab="match"),_(),W())}),ye(r=>{if(r.type!=="lz:progress")return;let c=n.analysis.get(r.key);!c||c.status!=="loading"||(c.steps=[...c.steps,r.text].slice(-7),W())});let kt=()=>{L(),new MutationObserver(T).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||L()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&L()},600),setInterval(()=>{!document.hidden&&u.isOpen&&T()},4e3),pt()&&chrome.storage.onChanged.addListener(r=>{r["lz.settings"]&&(n.settings={...qt,...r["lz.settings"].newValue||{}},L())}),Q()};document.body?kt():document.addEventListener("DOMContentLoaded",kt,{once:!0}),document.documentElement.setAttribute("data-lz",s.id),globalThis.__lz={state:n,view:P,refresh:L,overlay:d,panel:u}}function Ge(a){let s=Date.now()-432e5;return(Array.isArray(a)?a:[]).filter(i=>i&&i.at>s&&i.odd>1)}})();
